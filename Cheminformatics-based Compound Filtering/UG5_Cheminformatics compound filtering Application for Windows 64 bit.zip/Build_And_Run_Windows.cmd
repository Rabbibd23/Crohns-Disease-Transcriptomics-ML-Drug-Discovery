@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title FR Studio - Build Once, Open Fast
set "APP_EXE=%~dp0dist\Compound_Filtering_Studio_FR\Compound_Filtering_Studio_FR.exe"
set "APP_INTERNAL=%~dp0dist\Compound_Filtering_Studio_FR\_internal"

REM Most launches go straight to the EXE. No package checks after first build.
if exist "%APP_EXE%" if exist "%APP_INTERNAL%" goto :LAUNCH

echo ============================================================
echo          FR STUDIO - WINDOWS EXE BUILDER

echo ============================================================
echo [1/4] Finding a verified 64-bit Python 3.10-3.13 ...
set "STUDIO_PY="
REM Priority: Python 3.13 installed under this Windows user's profile.
call :TRY_PY "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
call :TRY_PY "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
call :TRY_PY "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
call :TRY_PY "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
call :TRY_PY "%ProgramFiles%\Python313\python.exe"
call :TRY_PY "%ProgramFiles%\Python312\python.exe"
call :TRY_PY "%ProgramFiles%\Python311\python.exe"
call :TRY_PY "%ProgramFiles%\Python310\python.exe"

REM Use py launcher only if its result really is Python 3 x64.
if not defined STUDIO_PY (
  where py >nul 2>nul
  if not errorlevel 1 (
    for %%V in (3.13 3.12 3.11 3.10) do (
      for /f "delims=" %%P in ('py -%%V -c "import sys; print(sys.executable)" 2^>nul') do call :TRY_PY "%%P"
    )
  )
)
REM PATH fallback checks ALL candidates; MGLTools' Python 2.7 is rejected.
if not defined STUDIO_PY (
  for /f "delims=" %%P in ('where python 2^>nul') do call :TRY_PY "%%P"
)
if not defined STUDIO_PY (
  echo [ERROR] Python 3.10-3.13 x64 was not found.
  echo [INFO] The MGLTools Python 2.7 installation is NOT compatible.
  echo [HINT] Expected installation path:
  echo        %LOCALAPPDATA%\Programs\Python\Python313\python.exe
  echo [HINT] To list installed interpreters: py -0p
  if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" (
     echo [WARNING] Python 3.13 exists but failed the x64 or version check.
  )
  pause
  exit /b 1
)
echo [OK] Compatible Python: !STUDIO_PY!
"!STUDIO_PY!" -c "import sys,platform;print('Version:',sys.version.split()[0]);print('Architecture:',platform.architecture()[0])"
if errorlevel 1 goto :FAILED

echo [2/4] Checking previously installed packages and cached environment.
echo [INFO] Only missing packages will be installed on FIRST build.
"!STUDIO_PY!" "%~dp0setup_and_build.py"
if errorlevel 1 goto :FAILED
if not exist "%APP_EXE%" goto :FAILED
if not exist "%APP_INTERNAL%" goto :FAILED
echo [3/4] EXE created and dependencies bundled.
echo [4/4] Opening application...
goto :LAUNCH

:TRY_PY
if defined STUDIO_PY exit /b 0
if not exist "%~1" exit /b 0
"%~1" -c "import sys;sys.exit(0 if ((3,10) <= sys.version_info[:2] <= (3,13) and sys.maxsize>2**32) else 1)" >nul 2>nul
if not errorlevel 1 set "STUDIO_PY=%~1"
exit /b 0

:LAUNCH
echo [FR Studio] Starting bundled Windows application; no downloads.
start "" /D "%~dp0dist\Compound_Filtering_Studio_FR" "%APP_EXE%"
exit /b 0

:FAILED
echo.
echo [ERROR] Build did not finish. Do NOT switch to Python 2.7.
echo [INFO] See build_logs\setup.log and build_logs\pyinstaller_build.log.
echo [INFO] Exact interpreter: !STUDIO_PY!
pause
exit /b 1
