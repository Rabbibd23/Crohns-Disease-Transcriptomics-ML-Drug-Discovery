@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title FR Studio - Direct Python 3.13 GUI (No EXE Needed)
set "PY313=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not exist "%PY313%" (
 echo [ERROR] Python 3.13 was not found at: %PY313%
 echo [HINT] Use Open_FR_Studio.cmd to locate other compatible Python versions.
 pause
 exit /b 1
)
"%PY313%" -c "import sys;sys.exit(0 if ((3,10)<=sys.version_info[:2]<=(3,13) and sys.maxsize>2**32) else 1)"
if errorlevel 1 (
 echo [ERROR] Incompatible Python interpreter.
 pause
 exit /b 1
)
set "STUDIO_QT_BINDING=PySide6"
echo [FR Studio] Running full GUI from Python 3.13. No build or downloads.
echo [NOTE] This shortcut uses your previously installed Python packages.
"%PY313%" -u "%~dp0Compound_Filtering_Studio_FR.py"
if errorlevel 1 (
  echo [ERROR] Application stopped. See error above.
  pause
)
