"""FR Studio Windows executable builder.

Use with Python 3.10-3.13 from the explicit Windows launcher. The build is
intended for Windows; the resulting EXE is self-contained within its _internal
folder and does not need pip/Python on the end-user machine.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import traceback
import venv

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / (".fr_runtime_py%d%d" % (sys.version_info.major, sys.version_info.minor))
RUNTIME_PYTHON = RUNTIME / "Scripts" / "python.exe"
APP = ROOT / "Compound_Filtering_Studio_FR.py"
ASSETS = ROOT / "Assets"
ICON = ASSETS / "FR_Studio.ico"
EXE = ROOT / "dist" / "Compound_Filtering_Studio_FR" / "Compound_Filtering_Studio_FR.exe"
LOGDIR = ROOT / "build_logs"
LOGFILE = LOGDIR / "setup.log"

# Distribution name, import name, version requirement. Packages are only
# downloaded when absent or their imports fail in the selected environment.
DEPS = [
    ("PySide6", "PySide6", "PySide6>=6.8,<7"),
    ("numpy", "numpy", "numpy>=1.24,<3"),
    ("pandas", "pandas", "pandas>=2.0,<3"),
    ("scipy", "scipy", "scipy>=1.10,<2"),
    ("matplotlib", "matplotlib", "matplotlib>=3.7,<4"),
    ("seaborn", "seaborn", "seaborn>=0.12,<1"),
    ("rdkit", "rdkit", "rdkit>=2023.9.1"),
    ("psutil", "psutil", "psutil>=5.9"),
    ("tqdm", "tqdm", "tqdm>=4.60"),
    ("Pillow", "PIL", "Pillow>=9"),
    ("dimorphite-dl", "dimorphite_dl", "dimorphite-dl"),
    ("PyInstaller", "PyInstaller", "pyinstaller>=6.12,<7"),
]


def log(msg):
    line = "[%s] %s" % (datetime.now().strftime("%H:%M:%S"), str(msg))
    print(line, flush=True)
    LOGDIR.mkdir(parents=True, exist_ok=True)
    with LOGFILE.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def cmd(args, *, cwd=None, capture=False):
    args = [str(x) for x in args]
    log("Running: " + " ".join(args[:4]) + (" ..." if len(args) > 4 else ""))
    if capture:
        p = subprocess.run(args, cwd=cwd, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, text=True)
        if p.returncode:
            log("Process failed. Output:\n" + (p.stdout or "")[-6000:])
            raise RuntimeError("Child command failed (exit %d)" % p.returncode)
        return p.stdout
    p = subprocess.run(args, cwd=cwd)
    if p.returncode:
        raise RuntimeError("Command failed (exit %d): %s" % (p.returncode, args[0]))
    return None


def validate_python(exe):
    code = ('import sys,platform; '
            'assert (3,10) <= sys.version_info[:2] <= (3,13), '
            '"Python 3.10-3.13 required"; '
            'assert sys.maxsize > 2**32, "64-bit Python required"; '
            'print(sys.executable,sys.version.split()[0],platform.architecture()[0])')
    return cmd([exe, "-c", code], capture=True).strip()


def check_modules(python):
    script = ("import importlib.util,json,sys\n"
              "names=json.loads(sys.argv[1]); out={}\n"
              "for name in names:\n"
              " try: out[name]=(importlib.util.find_spec(name) is not None)\n"
              " except (ImportError,ValueError,AttributeError): out[name]=False\n"
              "print(json.dumps(out))\n")
    output = subprocess.run([str(python), "-c", script,
                             json.dumps([m for _, m, _ in DEPS])],
                            capture_output=True, text=True)
    if output.returncode:
        raise RuntimeError("Dependency check failed:\n" + (output.stderr or "")[-3500:])
    return json.loads(output.stdout)


def ensure_runtime():
    if RUNTIME_PYTHON.is_file():
        try:
            info = validate_python(RUNTIME_PYTHON)
            log("Using existing cached runtime: " + info)
            return RUNTIME_PYTHON
        except Exception as exc:
            raise RuntimeError(
                "Cached runtime is broken: %s. Rename/delete the directory %s "
                "and retry. No existing runtime has been overwritten." % (exc, RUNTIME))
    log("Creating reusable runtime. Previously installed packages can be reused.")
    venv.EnvBuilder(with_pip=True, system_site_packages=True).create(str(RUNTIME))
    info = validate_python(RUNTIME_PYTHON)
    log("Runtime: " + info)
    return RUNTIME_PYTHON


def install_only_missing(python):
    found = check_modules(python)
    missing = [(name, module, spec) for name, module, spec in DEPS if not found[module]]
    for name, module, _ in DEPS:
        log(("MISSING: " if not found[module] else "CACHED:  ") + name)
    if missing:
        log("Downloading/installing missing packages only: " +
            ", ".join(item[0] for item in missing))
        cmd([python, "-m", "pip", "install", "--prefer-binary", "--only-binary=:all:"]
            + [spec for _, _, spec in missing])
    else:
        log("All packages found; no downloads or pip installs necessary.")
    final_modules = check_modules(python)
    still = [m for _, m, _ in DEPS if not final_modules[m]]
    if still:
        raise RuntimeError("Missing modules even after installation: " + ", ".join(still))
    log("Checking real imports (not just installed package names)...")
    imports = ('import PySide6,rdkit,numpy,pandas,scipy,matplotlib,seaborn,'
               'psutil,tqdm,PIL,dimorphite_dl,PyInstaller; '
               'print("FR_IMPORTS_OK")')
    try:
        output = cmd([python, "-c", imports], capture=True)
        log(output.strip())
    except Exception as exc:
        raise RuntimeError("A package was found but failed during import. "
                           "Check Python compatibility; see build_logs/setup.log. "
                           + str(exc))


def build(python, force=False):
    internal = EXE.parent / "_internal"
    if EXE.exists() and internal.is_dir() and not force:
        log("Existing compiled EXE found. Skipping installation and build.")
        return
    log("Building Windows one-folder EXE. First build may take several minutes.")
    args = [python, "-m", "PyInstaller", "--noconfirm", "--clean", "--onedir",
            "--windowed", "--name", "Compound_Filtering_Studio_FR",
            "--icon", ICON, "--add-data", "%s%sAssets" % (ASSETS, os.pathsep),
            "--exclude-module", "PyQt5", "--exclude-module", "PyQt6",
            "--exclude-module", "PySide2", "--collect-all", "rdkit",
            "--collect-all", "dimorphite_dl",
            "--hidden-import", "rdkit.Chem.FilterCatalog",
            "--hidden-import", "rdkit.Chem.MolStandardize.rdMolStandardize",
            "--hidden-import", "rdkit.Chem.Draw", APP]
    LOGDIR.mkdir(exist_ok=True)
    buildlog = LOGDIR / "pyinstaller_build.log"
    with buildlog.open("w", encoding="utf-8", errors="replace") as output:
        p = subprocess.run([str(x) for x in args], cwd=str(ROOT),
                           env=dict(os.environ, STUDIO_QT_BINDING="PySide6"),
                           stdout=output, stderr=subprocess.STDOUT)
    if p.returncode or not EXE.exists() or not internal.is_dir():
        tail = ""
        try:
            tail = "\n".join(buildlog.read_text(encoding="utf-8", errors="replace").splitlines()[-25:])
        except Exception:
            pass
        log("Last PyInstaller messages:\n" + tail)
        raise RuntimeError("EXE build failed. Full output: " + str(buildlog))
    log("EXE BUILD COMPLETE: " + str(EXE))
    log("Share the WHOLE folder: " + str(EXE.parent))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--force-rebuild", action="store_true")
    args = parser.parse_args()
    log("FR Studio Windows Builder — fixed Python selection release")
    log("Interpreter: %s; Python: %s" % (sys.executable, sys.version.split()[0]))
    if not APP.is_file() or not ICON.is_file() or not (ASSETS / "FR_Studio_Logo.png").is_file():
        raise FileNotFoundError("Application source or FR logo files missing")
    compile(APP.read_bytes(), str(APP), "exec")
    log("Application source syntax and assets verified.")
    if args.dry_run:
        log("Dry run complete. No packages installed or EXE built.")
        return
    if os.name != "nt":
        raise RuntimeError("Build requires Windows (PyInstaller is not a cross-compiler).")
    log("Selected Python: " + validate_python(sys.executable))
    if EXE.is_file() and (EXE.parent / "_internal").is_dir() and not args.force_rebuild:
        log("Existing working build folder detected; skipping setup.")
        return
    python = ensure_runtime()
    install_only_missing(python)
    build(python, force=args.force_rebuild)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log("BUILD FAILED:\n" + traceback.format_exc())
        sys.exit(1)
