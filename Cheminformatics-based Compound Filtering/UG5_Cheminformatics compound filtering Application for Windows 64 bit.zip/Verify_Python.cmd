@echo off
cd /d "%~dp0"
title FR Studio - Python Selection Diagnostics
echo [INFO] Python 3.13 known location:
set "LOCAL_PY=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if exist "%LOCAL_PY%" (
  "%LOCAL_PY%" -c "import sys,platform;print(sys.executable);print(sys.version);print(platform.architecture())"
) else (
  echo [NOT FOUND] %LOCAL_PY%
)
echo.
echo [INFO] PATH candidates; Python 2.7 from MGLTools is not usable:
where python
echo.
echo [INFO] Python launcher installations:
py -0p
echo.
pause
