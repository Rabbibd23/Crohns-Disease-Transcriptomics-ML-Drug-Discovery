@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title FR Studio - Quick CMD Launcher
set "APP_DIR=%~dp0dist\Compound_Filtering_Studio_FR"
set "APP_EXE=%APP_DIR%\Compound_Filtering_Studio_FR.exe"
if exist "%APP_EXE%" if exist "%APP_DIR%\_internal" (
  echo [FR Studio] Opening directly from compiled EXE. No Python and no downloads.
  start "" /D "%APP_DIR%" "%APP_EXE%"
  exit /b 0
)
echo [FR Studio] First launch requires one-time Windows EXE compilation.
call "%~dp0Build_And_Run_Windows.cmd"
exit /b %errorlevel%
