# Compound Filtering & Screening Studio (FR) — fixed Windows EXE builder

This release fixes **Python interpreter selection** in the first-run CMD launcher. The previous error `SyntaxError` near `print(message, flush=True)` occurs *before* application startup. That statement is valid in Python 3, so check what Python actually ran and whether the user's extracted file matches the intended script; the prior message alone does not prove the exact cause. The updated launcher explicitly selects a known 64-bit Python 3.10–3.13 interpreter and prints the exact executable and version **before** running the setup script.

## First-time use

1. Extract the entire ZIP into a regular Windows folder. Do not run it inside the ZIP.
2. Double-click **`Build_And_Run_Windows.cmd`**. This selects Python 3.13 first (if installed), verifies that it is 64-bit and reuses cached dependencies where available.
3. If any dependency is missing, the builder installs **only missing packages** in `.fr_runtime_py313` (or a corresponding directory for another supported version). Internet may be needed the first time.
4. The builder creates `dist\Compound_Filtering_Studio_FR\Compound_Filtering_Studio_FR.exe` and starts it. **The entire folder including `_internal` is the distributable application**.
5. On subsequent runs double-click **`Launch_Fast.cmd`**, or the EXE directly. No package installation or Python runtime is required to run the compiled folder.

## Troubleshooting

- **Wrong Python / SyntaxError:** Double-click `Verify_Python.cmd` to display available versions and paths. Run `Build_And_Run_Windows.cmd` again. Python 3.13 64-bit is recommended. The launcher prints the selected interpreter.
- **Cannot find Python:** Install standard 64-bit Python from https://www.python.org/downloads/windows/ with Python launcher. Python is only required on the *build PC*.
- **Build fails:** Open `build_logs\setup.log` and `build_logs\pyinstaller_build.log`. Send the last 30–50 lines of the latter when asking for help. In case the EXE builds but doesn't show the GUI, run `Run_Source_Debug.cmd` to save traceback in `build_logs\application_debug.log`.
- **Broken previously cached runtime:** This package names its cache `.fr_runtime_py313` instead of `.fr_runtime`, deliberately avoiding any incompatible cache created by the old builder.
- **Package already present:** It checks module presence and actual imports in the selected Python runtime. The first run can create a virtual environment even if packages already exist; this does not require re-downloading present modules. The resulting EXE bundles its runtime independently.
- **Building on other computers:** An already-built distributable `dist\Compound_Filtering_Studio_FR` folder does not need the builder, Python, a network connection, or pip. For distribution, copy **the full folder**, not only the `.exe` file.

## Important limitations

PyInstaller cannot produce a Windows executable in a Linux environment. This package contains a **Windows EXE builder, not an already compiled or Windows-tested EXE**. Building also depends on the actual Windows setup and any installed security software. The computational analysis, figures and GUI in `Compound_Filtering_Studio_FR.py` are preserved from the previous FR package; this patch focuses on the setup/launch mechanism, not scientific numerical validation.

Windows-only build: https://pyinstaller.org/en/stable/

Developed by FR (Md Fazlay Rabbi), Department of Zoology, University of Rajshahi, Bangladesh. Contact: rabbi.ms244@gmail.com
