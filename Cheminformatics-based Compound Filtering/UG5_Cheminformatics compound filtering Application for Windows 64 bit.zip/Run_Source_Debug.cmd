@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "RUNTIME_PY="
if exist ".fr_runtime_py313\Scripts\python.exe" set "RUNTIME_PY=%~dp0.fr_runtime_py313\Scripts\python.exe"
if not defined RUNTIME_PY if exist ".fr_runtime_py312\Scripts\python.exe" set "RUNTIME_PY=%~dp0.fr_runtime_py312\Scripts\python.exe"
if not defined RUNTIME_PY if exist ".fr_runtime_py311\Scripts\python.exe" set "RUNTIME_PY=%~dp0.fr_runtime_py311\Scripts\python.exe"
if not defined RUNTIME_PY if exist ".fr_runtime_py310\Scripts\python.exe" set "RUNTIME_PY=%~dp0.fr_runtime_py310\Scripts\python.exe"
if not defined RUNTIME_PY (
  echo [ERROR] No runtime installed yet. Run Build_And_Run_Windows.cmd first.
  pause
  exit /b 1
)
if not exist "build_logs" mkdir "build_logs"
echo [FR Studio] Running app source with console enabled for error diagnosis.
set STUDIO_QT_BINDING=PySide6
"%RUNTIME_PY%" -u "Compound_Filtering_Studio_FR.py" > "build_logs\application_debug.log" 2>&1
set "RC=%errorlevel%"
echo [FR Studio] App exit code: %RC%. See build_logs\application_debug.log.
type "build_logs\application_debug.log"
pause
exit /b %RC%
