from __future__ import annotations
# AUTOMATICALLY GENERATED TEMPORARY RUNTIME FROM THE SINGLE JUPYTER FILE
# The analysis logic and four filtering stages are embedded unchanged below.
# Use a fresh process to avoid IPython's incompatible Qt binding ImportDenier.
import sys, subprocess, importlib.util, tempfile, hashlib, pathlib, os
# -----------------------------------------------------------------------------
# BUILT-IN PART-4 REFERENCE AND COMPLETE USER MANUAL
# -----------------------------------------------------------------------------
STUDIO_SMARTS_CSV = 'name,smarts\n>2EsterGroups,"C(=O)O[C,H1].C(=O)O[C,H1].C(=O)O[C,H1]"\n2-haloPyridine,"n1c([F,Cl,Br,I])cccc1"\nacidHalide,"C(=O)[Cl,Br,I,F]"\nacyclic-C=C-O,C=[C!r]O\nacylCyanide,N#CC(=O)\nacylHydrazine,C(=O)N[NH2]\naldehyde,[CH1](=O)\nAliphatic-long-chain,[R0;D2][R0;D2][R0;D2][R0;D2]\nalkyl-halide,"[CX4][Cl,Br,I]"\namidotetrazole,c1nnnn1C=O\naniline,c1cc([NH2])ccc1\nazepane,[CH2R2]1N[CH2R2][CH2R2][CH2R2][CH2R2][CH2R2]1\nAzido-group,N=[N+]=[N-]\nAzo-group,N#N\nazocane,[CH2R2]1N[CH2R2][CH2R2][CH2R2][CH2R2][CH2R2][CH2R2]1\nbenzidine,"[cR2]1[cR2][cR2]([Nv3X3,Nv4X4])[cR2][cR2][cR2]1[cR2]2[cR2][cR2][cR2]([Nv3X3,Nv4X4])[cR2][cR2]2"\nbetaketo/anhydride,"[C,c](=O)[CX4,CR0X3,O][C,c](=O)"\nbiotin-analogue,C12C(NC(N1)=O)CSC2\nCarbo-cation/anion,"[C+,c+,C-,c-]"\ncatechol,"c1c([OH])c([OH,NH2,NH])ccc1"\ncharged-oxygen/sulfur-atoms,"[O+,o+,S+,s+]"\nchinone,"C1(=[O,N])C=CC(=[O,N])C=C1"\nchinone,"C1(=[O,N])C(=[O,N])C=CC=C1"\nconjugated-nitrile-group,C=[C!r]C#N\ncrown-ether,"[OR2,NR2]@[CR2]@[CR2]@[OR2,NR2]@[CR2]@[CR2]@[OR2,NR2]"\ncumarine,c1ccc2c(c1)ccc(=O)o2\ncyanamide,N[CH2]C#N\ncyanate/aminonitrile/thiocyanate,"[N,O,S]C#N"\ncyanohydrins,N#CC[OH]\ncycloheptane,[CR2]1[CR2][CR2][CR2][CR2][CR2][CR2]1\ncycloheptane,[CR2]1[CR2][CR2]cc[CR2][CR2]1\ncyclooctane,[CR2]1[CR2][CR2][CR2][CR2][CR2][CR2][CR2]1\ncyclooctane,[CR2]1[CR2][CR2]cc[CR2][CR2][CR2]1\ndiaminobenzene,"[cR2]1[cR2]c([N+0X3R0,nX3R0])c([N+0X3R0,nX3R0])[cR2][cR2]1"\ndiaminobenzene,"[cR2]1[cR2]c([N+0X3R0,nX3R0])[cR2]c([N+0X3R0,nX3R0])[cR2]1"\ndiaminobenzene,"[cR2]1[cR2]c([N+0X3R0,nX3R0])[cR2][cR2]c1([N+0X3R0,nX3R0])"\ndiazo-group,[N!R]=[N!R]\ndiketo-group,"[C,c](=O)[C,c](=O)"\ndisulphide,SS\nenamine,[CX2R0][NX3R0]\nester-of-HOBT,C(=O)Onnn\nfour-member-lactones,C1(=O)OCC1\nhalogenated-ring,"c1cc([Cl,Br,I,F])cc([Cl,Br,I,F])c1[Cl,Br,I,F]"\nhalogenated-ring,"c1ccc([Cl,Br,I,F])c([Cl,Br,I,F])c1[Cl,Br,I,F]"\nheavy-metal,"[Hg,Fe,As,Sb,Zn,Se,se,Te,B,Si]"\nhet-C-het-not-in-ring,"[NX3R0,NX4R0,OR0,SX2R0][CX4][NX3R0,NX4R0,OR0,SX2R0]"\nhydantoin,C1NC(=O)NC(=O)1\nhydrazine,N[NH2]\nhydroquinone,"[OH]c1ccc([OH,NH2,NH])cc1"\nhydroxamic-acid,C(=O)N[OH]\nimine,C=[N!R]\nimine,"N=[CR0][N,n,O,S]"\niodine,I\nisocyanate,N=C=O\nisolate-alkene,"[$([CH2]),$([CH][CX4]),$(C([CX4])[CX4])]=[$([CH2]),$([CH][CX4]),$(C([CX4])[CX4])]"\nketene,C=C=O\n"methylidene-1,3-dithiole",S1C=CSC1=S\nMichael-acceptor,"C=!@CC=[O,S]"\nMichael-acceptor,"[$([CH]),$(CC)]#CC(=O)[C,c]"\nMichael-acceptor,"[$([CH]),$(CC)]#CS(=O)(=O)[C,c]"\nMichael-acceptor,C=C(C=O)C=O\nMichael-acceptor,"[$([CH]),$(CC)]#CC(=O)O[C,c]"\nN-oxide,"[NX2,nX3][OX1]"\n"N-acyl-2-amino-5-mercapto-1,3,4-thiadiazole",s1c(S)nnc1NC=O\nN-C-halo,"NC[F,Cl,Br,I]"\nN-halo,"[NX3,NX4][F,Cl,Br,I]"\nN-hydroxyl-pyridine,n[OH]\nnitro-group,[N+](=O)[O-]\nN-nitroso,[#7]-N=O\noxime,"[C,c]=N[OH]"\noxime,"[C,c]=NOC=O"\nOxygen-nitrogen-single-bond,"[OR0,NR0][OR0,NR0]"\nperfluorinated-chain,[CX4](F)(F)[CX4](F)F\nperoxide,OO\nphenol-ester,c1ccccc1OC(=O)[#6]\nphenyl-carbonate,c1ccccc1OC(=O)O\nphosphor-P-phthalimide,"[cR,CR]~C(=O)NC(=O)~[cR,CR]"\nPolycyclic-aromatic-hydrocarbon,a1aa2a3a(a1)A=AA=A3=AA=A2\nPolycyclic-aromatic-hydrocarbon,a21aa3a(aa1aaaa2)aaaa3\nPolycyclic-aromatic-hydrocarbon,a31a(a2a(aa1)aaaa2)aaaa3\npolyene,[CR0]=[CR0][CR0]=[CR0]\nquaternary-nitrogen,"[s,S,c,C,n,N,o,O]~[nX3+,NX3+](~[s,S,c,C,n,N])~[s,S,c,C,n,N]"\nquaternary-nitrogen,"[s,S,c,C,n,N,o,O]~[n+,N+](~[s,S,c,C,n,N,o,O])(~[s,S,c,C,n,N,o,O])~[s,S,c,C,n,N,o,O]"\nquaternary-nitrogen,[*]=[N+]=[*]\nsaponine-derivative,O1CCCCC1OC2CCC3CCCCC3C2\nsilicon-halogen,"[Si][F,Cl,Br,I]"\nstilbene,c1ccccc1C=Cc2ccccc2\nsulfinic-acid,"[SX3](=O)[O-,OH]"\nSulfonic-acid,"[C,c]S(=O)(=O)O[C,c]"\nSulfonic-acid,"S(=O)(=O)[O-,OH]"\nsulfonyl-cyanide,S(=O)(=O)C#N\nsulfur-oxygen-single-bond,[SX2]O\nsulphate,OS(=O)(=O)[O-]\nsulphur-nitrogen-single-bond,[SX2H0][N]\nThiobenzothiazole,c12ccccc1(SC(S)=N2)\nthiobenzothiazole,c12ccccc1(SC(=S)N2)\nThiocarbonyl-group,"[C,c]=S"\nthioester,SC=O\nthiol,[S-]\nthiol,[SH]\nThree-membered-heterocycle,"*1[O,S,N]*1"\ntriflate,OS(=O)(=O)C(F)(F)F\ntriphenyl-methylsilyl,"[SiR0,CR0](c1ccccc1)(c2ccccc2)(c3ccccc3)"\ntriple-bond,C#C\n'
STUDIO_MANUAL_MD = "# Compound Filtering & Screening Studio — User Manual\n\n**Version:** 0.9 Research Candidate  \n**Developer:** Md Fazlay Rabbi  \n**Department:** Department of Zoology, University of Rajshahi, Bangladesh  \n**Email:** rabbi.ms244@gmail.com\n\n## 1. Purpose\nThis application integrates the four supplied molecular screening notebooks in their original sequence:\n\n1. **Molecular preparation:** SMILES parsing, single-fragment filtering, salt removal, metal filtering, RDKit normalization, pH-dependent ionization and duplicate removal.\n2. **Property-based filtering:** molecular descriptors, Lipinski, Pfizer, Veber, Ghose, Egan, Muegge, ESOL logS, original toxicity-alert score and the user's original REOS-like SMARTS screen.\n3. **Medicinal chemistry:** RDKit Brenk, NIH and PAINS FilterCatalogs.\n4. **Structural screen:** user-supplied unwanted SMARTS CSV, undesirable scaffolds, aggregation-associated alerts, toxicophore alerts and reactive functional groups.\n\nPart 1 passes only its *retained compound rows* to Part 2, retaining their **original input SMILES** as the downstream molecular input **automatically**; the same applies to Parts 3 and 4. You upload the compound library once. The 104-row Part-4 reference CSV is **included** in the software; no extra reference-file upload is needed.\n\n## 2. Running from VS Code or Jupyter\nOpen `Compound_Filtering_Studio_ALL_FOUR_PARTS_ONE_CELL.ipynb` in local VS Code using a local Python/Jupyter kernel. Run the single complete code cell. On first use, the notebook checks for missing packages and attempts to install them in the current kernel. Internet access and permission to install packages may be required. **No manual pip commands are necessary if installation succeeds.** Existing packages are reused. The notebook starts the PyQt5 window in its own Python process, avoiding incompatibility with a Qt binding that is already selected by Jupyter. If VS Code is connected to a *remote/headless server*, the window may open remotely or not at all; use local Windows Jupyter instead.\n\n**One-file behavior:** All computational code, PyQt5 GUI code, user-manual text and 104 SMARTS patterns are embedded inside the same notebook. No `legacy_core.py`, `filter_engine.py`, GUI `.py`, or reference CSV is required. A temporary reference CSV is created automatically when needed; the generated analysis outputs are saved in the folder you choose.\n\nA truly installation-free Windows application requires a compiled executable created on Windows. The supplied `.py` and `.ipynb` source files alone cannot eliminate the need for their Python packages on a new computer.\n\n## 3. Input CSV format\nRequired: `smiles` column; a compound name field is recommended (`compound_name`, `name`, `compound_id`, or `id` are detected). For example:\n\n```csv\ncompound_name,smiles\nCompound_A,CCO\nCompound_B,CC(=O)O\nCompound_C,Cn1c(=O)c2c(ncn2C)n(C)c1=O\n```\n\nThe application accepts common alternatives to `smiles`, such as `SMILES` and `canonical_smiles`. If names are missing, synthetic labels are generated and reported in the input metadata. Each input row is tracked by `source_row_id`. **Original-SMILES handoff policy (user specified):** The `smiles` input for Part 2, Part 3 and Part 4 is always the **original input SMILES** of each retained compound (also recorded in `input_smiles`). The program does **not** replace it with the standardized/ionized `final_smiles`. `canonical_smiles`, `ionized_smiles`, and `final_smiles`, when generated by Part 1, are retained as **separate provenance columns**. The optional `original_input_smiles` column preserves the exact originally supplied text. Import prefers an explicit `smiles` column; if missing, it looks for `original_smiles` or `input_smiles` before standardized alternatives.\n\n## 4. Workflow controls\nIn **Overview**, choose the initial compound CSV and an output base folder. Click **Run Complete Pipeline** to run all 4 stages in order. Alternatively, open **Part 1** and choose which steps to use; run Part 1, then Part 2, then Part 3, then Part 4. A Part may be started directly with a user-selected CSV. Earlier Parts are not executed or treated as passed when starting from Part 2, 3 or 4.\n\nEach Part page provides checkboxes for all available rules. **SMILES parsing is mandatory**. Remaining rules can be disabled for sensitivity analysis, but disabled filters are still listed as **Skipped** in the results. Changing options after processing a stage does not retroactively change earlier-stage results. Start a fresh run to apply a different selection to all parts.\n\n### Part 1: pH-dependent ionization\nDefault pH 7.4. If selected, Dimorphite-DL must be available and its supported protonation API usable. Molecular protonation is heuristic and multiple states may be possible. Original notebook ionization validation is retained; inspect `ionization_method`, `ionized_smiles`, `formal_charge` and source records. You may uncheck ionization if unavailable, but **must disclose** that choice in your research methods.\n\n**Important original-code behavior:** The single-fragment filter runs before salt removal; it can discard multi-fragment salts before desalting. This order is preserved as supplied and may need scientific reassessment for salt-rich databases.\n\n### Part 2: drug-likeness\nDescriptors are recalculated from the **original input SMILES** of each Part-1 survivor; canonical/ionized `final_smiles` is **not** used as the downstream input. The original rule thresholds are retained: Lipinski, Pfizer (LogP > 3 and TPSA < 75 excluded), Veber, Ghose, Egan, Muegge, ESOL LogS > -4, original toxicity-alert score and original REOS-like alerts. The toxicity score and REOS-like screen **are not clinical toxicity predictions or universally validated REOS rules**. Some SMARTS are intentionally broad; choose based on the purpose of the project.\n\n### Part 3: RDKit catalogs\nChoose any combination of Brenk, NIH and PAINS. A compound matching the chosen catalog is excluded at that step. The first matched description is exported in that step's `*_matches.csv`. Catalog source: official RDKit FilterCatalog.\n\n### Part 4: reference SMARTS and other patterns\nThe originally uploaded `Two_separeted_unwanted_substructures_cleaned.csv` is embedded directly in the notebook and materialized into a temporary runtime file automatically. The file contains **104 rows**; all 104 SMARTS patterns parsed successfully in the validation environment. **18 name values are duplicates**; the app intentionally retains all rows in their original order instead of collapsing them into a name-keyed dictionary. Each match CSV includes the source `pattern_row`, the label and the SMARTS. Other pattern groups are extracted from the exact original Part-4 notebook definitions.\n\n“Aggregator-like” patterns are only *substructure alerts*, not proof that a molecule will colloidally aggregate. Similarly, “toxicophore” and “reactive” warnings do not establish experimental toxicity.\n\n**Scientific interpretation of the requested change:** Part-1 duplicate detection can still use its original `final_smiles` rule; preserving original SMILES for Parts 2–4 can yield different structure-dependent descriptors and matches compared with screening standardized or ionized structures. Record this choice in publications.\n\n## 5. Progress, results and figures\nAll work is performed in a worker thread so the GUI can remain responsive. The footer progress bar and Live Analysis Log show steps as they finish. Long underlying molecular calculations may not expose a precise percentage; the displayed percentages indicate stage milestones, **not calibrated remaining time**.\n\nEach stage has its own folder, detailed excluded/matched-compound files, `filter_statistics.csv` and a figure gallery. The standard generated figures include:\n\n- Filtering cascade / retained count by filter\n- Per-filter exclusion impact\n- Retained vs excluded overview\n- Descriptor distributions (Part 2, as applicable)\n- Most frequent alert types (Parts 3 and 4, when matches exist)\n\nStandard plots export as **PNG and TIFF at 600 DPI**, plus vector **SVG**. Titles, axes, ticks and legends are bold and prepared for supplement readability. An optional dashboard checkbox also attempts to reproduce extra **original Part-1 to Part-4 figure functions**, including molecule illustration plots, as PNG. These can be slow, large or sensitive to empty filtered datasets; failure to draw optional figures is logged and does not invalidate saved data.\n\n## 6. Output directory and combined ZIP\nEach run creates a unique project directory with the following layout:\n\n```text\nCompound_Screening_YYYYMMDD_HHMMSS/\n  01_Preprocessing/\n      part1_filtered_compounds.csv\n      rejected_*.csv\n      filter_statistics.csv\n      figures/\n  02_Property_Filtering/\n      part2_filtered_compounds.csv\n      filter_statistics.csv\n      figures/\n  03_Brenk_NIH_PAINS/\n      part3_filtered_compounds.csv\n      *_matches.csv\n      filter_statistics.csv\n      figures/\n  04_Substructure_Screening/\n      part4_filtered_compounds.csv\n      *_matches.csv\n      filter_statistics.csv\n      figures/\n  05_Combined_Summary/\n      final_filtered_compounds.csv\n      overall_filtering_summary.csv\n      paper_ready_results_summary.txt\n      paper_ready_results_summary.md\n      analysis_manifest.json\n      Two_separeted_unwanted_substructures_cleaned.csv\n```\n\nThe same run directory is archived automatically into `Compound_Screening_YYYYMMDD_HHMMSS.zip` inside the chosen **output base** folder. Select **Final Summary** to inspect the written Results summary and open the output folder or ZIP archive.\n\n## 7. Manuscript reporting and scientific caveats\nThe Results template reports exact stage-by-stage counts, selections and final retention percentage from that run. It is **not an independently authored Discussion, validation report or experimental toxicity result**. Check filtering choices, and keep the source manifest as a supplement. Report whether ionization was enabled, exact algorithm cutoffs and RDKit/Dimorphite versions. The reference SMARTS list may include overly broad or chemically nonspecific alerts. Do not claim compounds that pass this pipeline are necessarily safe or bioavailable.\n\n## 8. Troubleshooting\n- **Missing package:** The Notebook setup cell may need internet to download it. If installation fails, copy the **complete** pip/build error. No source notebook can make dependencies available offline without packaging them.\n- **Window does not appear:** Run Jupyter locally in VS Code or a locally hosted Jupyter server with a Windows desktop. The GUI runs in its own Qt process; do not use `%gui qt` in the notebook.\n- **Ionization failure:** Check Dimorphite-DL version. You can uncheck ionization to run a clearly documented no-ionization exploratory analysis.\n- **Zero compounds remain:** This is possible with strict sequential rules. Review individual filtering counts before relaxing criteria; do not silently fabricate candidate survivors.\n- **Very slow plots:** Uncheck the optional Original Notebook Figures option and use the efficient standard plots.\n- **Memory pressure:** Large RDKit compound datasets can consume significant memory. Start with a smaller test library.\n\n## 9. Citation and contact\nAlgorithms extracted from the four user-provided notebooks are consolidated into the single Jupyter code cell. This integrated workflow includes earlier GUI/IO adaptations and should be validated against the original standalone notebooks for a full scientific equivalence claim. External reference: official RDKit FilterCatalog API: https://www.rdkit.org/docs/GettingStartedInPython.html\n\nContact: **rabbi.ms244@gmail.com**.\n"


# ================== PARTS 1–4: ORIGINAL-BASED FILTER CLASSES ==================
"""Selected ORIGINAL computation and figure functions extracted verbatim from four user notebooks.
Only top-level Colab upload/download/install code is excluded. No filtering expressions changed.
"""
import os,sys,json,zipfile,gc,time,warnings
from datetime import datetime,timedelta
from collections import defaultdict,OrderedDict
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import psutil
from tqdm import tqdm
from rdkit import Chem
from rdkit.Chem import SaltRemover, AllChem, Descriptors, Crippen, Lipinski, rdMolDescriptors, Draw
from rdkit.Chem.MolStandardize import rdMolStandardize
from rdkit.Chem.rdMolDescriptors import CalcNumRotatableBonds,CalcTPSA
try:
    import dimorphite_dl
except ImportError:
    dimorphite_dl=None


# Original source: Part 1, SequentialMolecularFilter
class SequentialMolecularFilter:
    def __init__(self, batch_size=1000):
        self.salt_remover = SaltRemover.SaltRemover()
        self.tautomer_enumerator = rdMolStandardize.TautomerEnumerator()
        self.normalizer = rdMolStandardize.Normalizer()
        self.batch_size = batch_size
        self.metals = {
            'Li', 'Na', 'K', 'Rb', 'Cs', 'Be', 'Mg', 'Ca', 'Sr', 'Ba',
            'Al', 'Ga', 'In', 'Tl', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn',
            'Zr', 'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd', 'Hf', 'Ta', 'W', 'Re',
            'Os', 'Ir', 'Pt', 'Au', 'Hg', 'Sc', 'Y', 'La', 'Ce', 'Pr', 'Nd', 'Pm', 'Sm',
            'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Tm', 'Yb', 'Lu', 'Ac', 'Th', 'Pa', 'U',
            'Np', 'Pu', 'Am', 'Cm', 'Bk', 'Cf', 'Es', 'Fm', 'Md', 'No', 'Lr'
        }
        
        # Enhanced validation rules
        self.forbidden_patterns = [
            # Reactive functional groups
            '[N+](=O)[O-]',  # Nitro groups
            'C(=O)OO',       # Peroxides
            'N=N=N',         # Azides
            'C#N',           # Nitriles (optional - can be commented out)
            '[S,P](F)(F)(F)(F)(F)',  # Highly fluorinated S/P
        ]
        
        # Allowed elements for drug-like compounds
        self.allowed_elements = {
            'H', 'C', 'N', 'O', 'F', 'P', 'S', 'Cl', 'Br', 'I', 'B', 'Si'
        }
        
        # Initialize filtering statistics
        self.filtering_stats = OrderedDict([
            ('initial', {'passed': 0, 'failed': 0, 'failure_reasons': []}),
            ('parsing', {'passed': 0, 'failed': 0, 'failure_reasons': []}),
            ('fragment_filter', {'passed': 0, 'failed': 0, 'failure_reasons': []}),
            ('salt_removal', {'passed': 0, 'failed': 0, 'failure_reasons': []}),
            ('metal_removal', {'passed': 0, 'failed': 0, 'failure_reasons': []}),
            ('normalization', {'passed': 0, 'failed': 0, 'failure_reasons': []}),
            ('ionization', {'passed': 0, 'failed': 0, 'failure_reasons': []}),
            ('duplicate_removal', {'passed': 0, 'failed': 0, 'failure_reasons': []})
        ])
        
        self.step_descriptions = {
            'initial': 'Initial Library',
            'parsing': 'SMILES Parsing',
            'fragment_filter': 'Fragment Filtering',
            'salt_removal': 'Salt Removal',
            'metal_removal': 'Metal Removal',
            'normalization': 'Normalization',
            'ionization': 'Ionization (pH 7.4)',
            'duplicate_removal': 'Duplicate Removal'
        }

    def get_memory_usage(self):
        """Get current memory usage in MB"""
        process = psutil.Process(os.getpid())
        return process.memory_info().rss / 1024 / 1024

    def parse_smiles_filter(self, df, smiles_column):
        """Step 1: Parse SMILES and filter invalid ones"""
        print(f"\n🔬 Step 1: SMILES Parsing Filter")
        
        valid_compounds = []
        failed_compounds = []
        
        with tqdm(df.iterrows(), total=len(df), desc="Parsing SMILES", ncols=100, colour='blue') as pbar:
            for idx, row in pbar:
                smiles = row[smiles_column]
                
                if pd.isna(smiles) or smiles == '':
                    failed_compounds.append({
                        'index': idx,
                        'reason': 'Empty or NaN SMILES',
                        'original_smiles': smiles
                    })
                    self.filtering_stats['parsing']['failed'] += 1
                    self.filtering_stats['parsing']['failure_reasons'].append('Empty or NaN SMILES')
                    continue
                
                try:
                    mol = Chem.MolFromSmiles(smiles)
                    if mol is None:
                        failed_compounds.append({
                            'index': idx,
                            'reason': 'Invalid SMILES structure',
                            'original_smiles': smiles
                        })
                        self.filtering_stats['parsing']['failed'] += 1
                        self.filtering_stats['parsing']['failure_reasons'].append('Invalid SMILES structure')
                        continue
                    
                    # Add parsed molecule to row data
                    row_dict = row.to_dict()
                    row_dict['mol_object'] = mol
                    row_dict['original_index'] = idx
                    valid_compounds.append(row_dict)
                    self.filtering_stats['parsing']['passed'] += 1
                    
                except Exception as e:
                    failed_compounds.append({
                        'index': idx,
                        'reason': f'Parsing error: {str(e)}',
                        'original_smiles': smiles
                    })
                    self.filtering_stats['parsing']['failed'] += 1
                    self.filtering_stats['parsing']['failure_reasons'].append(f'Parsing error: {str(e)}')
        
        valid_df = pd.DataFrame(valid_compounds)
        failed_df = pd.DataFrame(failed_compounds)
        
        print(f"   ✅ Passed: {len(valid_df):,} compounds")
        print(f"   ❌ Failed: {len(failed_df):,} compounds")
        
        return valid_df, failed_df

    def fragment_filter(self, df, smiles_column):
        """Step 2: Filter single fragment compounds"""
        print(f"\n🧬 Step 2: Fragment Filtering")
        
        valid_compounds = []
        failed_compounds = []
        
        with tqdm(df.iterrows(), total=len(df), desc="Fragment filtering", ncols=100, colour='green') as pbar:
            for idx, row in pbar:
                smiles = row[smiles_column]
                
                try:
                    fragments = smiles.split('.')
                    if len(fragments) == 1:
                        valid_compounds.append(row.to_dict())
                        self.filtering_stats['fragment_filter']['passed'] += 1
                    else:
                        failed_compounds.append({
                            'index': row.get('original_index', idx),
                            'reason': f'Multiple fragments ({len(fragments)} fragments)',
                            'original_smiles': smiles,
                            'fragment_count': len(fragments)
                        })
                        self.filtering_stats['fragment_filter']['failed'] += 1
                        self.filtering_stats['fragment_filter']['failure_reasons'].append(f'Multiple fragments ({len(fragments)})')
                        
                except Exception as e:
                    failed_compounds.append({
                        'index': row.get('original_index', idx),
                        'reason': f'Fragment analysis error: {str(e)}',
                        'original_smiles': smiles
                    })
                    self.filtering_stats['fragment_filter']['failed'] += 1
                    self.filtering_stats['fragment_filter']['failure_reasons'].append(f'Fragment analysis error')
        
        valid_df = pd.DataFrame(valid_compounds)
        failed_df = pd.DataFrame(failed_compounds)
        
        print(f"   ✅ Passed: {len(valid_df):,} compounds")
        print(f"   ❌ Failed: {len(failed_df):,} compounds")
        
        return valid_df, failed_df

    def salt_removal_filter(self, df):
        """Step 3: Salt removal filter"""
        print(f"\n🧂 Step 3: Salt Removal Filter")
        
        valid_compounds = []
        failed_compounds = []
        
        with tqdm(df.iterrows(), total=len(df), desc="Salt removal", ncols=100, colour='orange') as pbar:
            for idx, row in pbar:
                mol = row['mol_object']
                
                try:
                    original_atom_count = mol.GetNumAtoms()
                    cleaned_mol = self.salt_remover.StripMol(mol)
                    
                    if cleaned_mol is None:
                        failed_compounds.append({
                            'index': row.get('original_index', idx),
                            'reason': 'Salt removal failed - molecule became None',
                            'original_smiles': row.get('smiles', '')
                        })
                        self.filtering_stats['salt_removal']['failed'] += 1
                        self.filtering_stats['salt_removal']['failure_reasons'].append('Salt removal failed')
                        continue
                    
                    cleaned_atom_count = cleaned_mol.GetNumAtoms()
                    
                    if cleaned_atom_count == 0:
                        failed_compounds.append({
                            'index': row.get('original_index', idx),
                            'reason': 'No atoms remaining after salt removal',
                            'original_smiles': row.get('smiles', '')
                        })
                        self.filtering_stats['salt_removal']['failed'] += 1
                        self.filtering_stats['salt_removal']['failure_reasons'].append('No atoms remaining')
                        continue
                    
                    # Update molecule object and add salt removal info
                    row_dict = row.to_dict()
                    row_dict['mol_object'] = cleaned_mol
                    row_dict['salt_removed'] = cleaned_atom_count < original_atom_count
                    row_dict['atoms_removed'] = original_atom_count - cleaned_atom_count
                    
                    valid_compounds.append(row_dict)
                    self.filtering_stats['salt_removal']['passed'] += 1
                    
                except Exception as e:
                    failed_compounds.append({
                        'index': row.get('original_index', idx),
                        'reason': f'Salt removal error: {str(e)}',
                        'original_smiles': row.get('smiles', '')
                    })
                    self.filtering_stats['salt_removal']['failed'] += 1
                    self.filtering_stats['salt_removal']['failure_reasons'].append(f'Salt removal error')
        
        valid_df = pd.DataFrame(valid_compounds)
        failed_df = pd.DataFrame(failed_compounds)
        
        print(f"   ✅ Passed: {len(valid_df):,} compounds")
        print(f"   ❌ Failed: {len(failed_df):,} compounds")
        
        return valid_df, failed_df

    def metal_removal_filter(self, df):
        """Step 4: Metal removal filter"""
        print(f"\n⚗️ Step 4: Metal Removal Filter")
        
        valid_compounds = []
        failed_compounds = []
        
        with tqdm(df.iterrows(), total=len(df), desc="Metal removal", ncols=100, colour='purple') as pbar:
            for idx, row in pbar:
                mol = row['mol_object']
                
                try:
                    has_metals = any(atom.GetSymbol() in self.metals for atom in mol.GetAtoms())
                    
                    if has_metals:
                        metal_atoms = [atom.GetSymbol() for atom in mol.GetAtoms() if atom.GetSymbol() in self.metals]
                        failed_compounds.append({
                            'index': row.get('original_index', idx),
                            'reason': f'Contains metal atoms: {", ".join(set(metal_atoms))}',
                            'original_smiles': row.get('smiles', ''),
                            'metal_atoms': list(set(metal_atoms))
                        })
                        self.filtering_stats['metal_removal']['failed'] += 1
                        self.filtering_stats['metal_removal']['failure_reasons'].append(f'Contains metals: {", ".join(set(metal_atoms))}')
                        continue
                    
                    row_dict = row.to_dict()
                    row_dict['has_metals'] = False
                    valid_compounds.append(row_dict)
                    self.filtering_stats['metal_removal']['passed'] += 1
                    
                except Exception as e:
                    failed_compounds.append({
                        'index': row.get('original_index', idx),
                        'reason': f'Metal detection error: {str(e)}',
                        'original_smiles': row.get('smiles', '')
                    })
                    self.filtering_stats['metal_removal']['failed'] += 1
                    self.filtering_stats['metal_removal']['failure_reasons'].append('Metal detection error')
        
        valid_df = pd.DataFrame(valid_compounds)
        failed_df = pd.DataFrame(failed_compounds)
        
        print(f"   ✅ Passed: {len(valid_df):,} compounds")
        print(f"   ❌ Failed: {len(failed_df):,} compounds")
        
        return valid_df, failed_df

    def normalization_filter(self, df):
        """Step 5: Normalization filter"""
        print(f"\n🔄 Step 5: Normalization Filter")
        
        valid_compounds = []
        failed_compounds = []
        
        with tqdm(df.iterrows(), total=len(df), desc="Normalization", ncols=100, colour='cyan') as pbar:
            for idx, row in pbar:
                mol = row['mol_object']
                
                try:
                    normalized = self.normalizer.normalize(mol)
                    canonical_mol = self.tautomer_enumerator.Canonicalize(normalized)
                    
                    if canonical_mol is None:
                        failed_compounds.append({
                            'index': row.get('original_index', idx),
                            'reason': 'Normalization failed - molecule became None',
                            'original_smiles': row.get('smiles', '')
                        })
                        self.filtering_stats['normalization']['failed'] += 1
                        self.filtering_stats['normalization']['failure_reasons'].append('Normalization failed')
                        continue
                    
                    # Update molecule object and add canonical SMILES
                    row_dict = row.to_dict()
                    row_dict['mol_object'] = canonical_mol
                    row_dict['canonical_smiles'] = Chem.MolToSmiles(canonical_mol, canonical=True)
                    
                    valid_compounds.append(row_dict)
                    self.filtering_stats['normalization']['passed'] += 1
                    
                except Exception as e:
                    failed_compounds.append({
                        'index': row.get('original_index', idx),
                        'reason': f'Normalization error: {str(e)}',
                        'original_smiles': row.get('smiles', '')
                    })
                    self.filtering_stats['normalization']['failed'] += 1
                    self.filtering_stats['normalization']['failure_reasons'].append('Normalization error')
        
        valid_df = pd.DataFrame(valid_compounds)
        failed_df = pd.DataFrame(failed_compounds)
        
        print(f"   ✅ Passed: {len(valid_df):,} compounds")
        print(f"   ❌ Failed: {len(failed_df):,} compounds")
        
        return valid_df, failed_df

    def enhanced_ionization_filter(self, df, ph=7.4):
        """Step 6: Enhanced Ionization filter with improved validation"""
        print(f"\n⚡ Step 6: Enhanced Ionization Filter (pH {ph})")
        
        valid_compounds = []
        failed_compounds = []
        
        with tqdm(df.iterrows(), total=len(df), desc="Ionization", ncols=100, colour='yellow') as pbar:
            for idx, row in pbar:
                canonical_smiles = row['canonical_smiles']
                
                try:
                    # Enhanced ionization with multiple attempts and validation
                    ionization_successful = False
                    ionized_smiles = canonical_smiles
                    ionization_method = 'original'
                    
                    # Attempt 1: Standard dimorphite_dl ionization
                    try:
                        ionized_list = dimorphite_dl.protonate(
                            canonical_smiles, 
                            min_ph=ph, 
                            max_ph=ph, 
                            max_variants=3,  # Get multiple variants
                            pka_precision=1.0
                        )
                        
                        if ionized_list and len(ionized_list) > 0:
                            # Validate each ionized form
                            for candidate in ionized_list:
                                test_mol = Chem.MolFromSmiles(candidate)
                                if test_mol is not None:
                                    # Additional validation for ionized form
                                    if self._validate_ionized_structure(test_mol, canonical_smiles):
                                        ionized_smiles = candidate
                                        ionization_method = 'dimorphite_standard'
                                        ionization_successful = True
                                        break
                    except Exception as e:
                        pass  # Try alternative methods
                    
                    # Attempt 2: If standard failed, try with different parameters
                    if not ionization_successful:
                        try:
                            ionized_list = dimorphite_dl.protonate(
                                canonical_smiles,
                                min_ph=ph-0.5,
                                max_ph=ph+0.5,
                                max_variants=5,
                                pka_precision=0.5
                            )
                            
                            if ionized_list and len(ionized_list) > 0:
                                for candidate in ionized_list:
                                    test_mol = Chem.MolFromSmiles(candidate)
                                    if test_mol is not None:
                                        if self._validate_ionized_structure(test_mol, canonical_smiles):
                                            ionized_smiles = candidate
                                            ionization_method = 'dimorphite_extended'
                                            ionization_successful = True
                                            break
                        except Exception as e:
                            pass
                    
                    # Attempt 3: Manual ionization for common functional groups
                    if not ionization_successful:
                        try:
                            manual_ionized = self._manual_ionization_ph74(canonical_smiles)
                            if manual_ionized != canonical_smiles:
                                test_mol = Chem.MolFromSmiles(manual_ionized)
                                if test_mol is not None:
                                    if self._validate_ionized_structure(test_mol, canonical_smiles):
                                        ionized_smiles = manual_ionized
                                        ionization_method = 'manual'
                                        ionization_successful = True
                        except Exception as e:
                            pass
                    
                    # Final validation of ionized SMILES
                    ionized_mol = Chem.MolFromSmiles(ionized_smiles)
                    
                    if ionized_mol is None:
                        failed_compounds.append({
                            'index': row.get('original_index', idx),
                            'reason': 'Ionized SMILES could not be parsed',
                            'original_smiles': row.get('smiles', ''),
                            'canonical_smiles': canonical_smiles,
                            'attempted_ionized_smiles': ionized_smiles
                        })
                        self.filtering_stats['ionization']['failed'] += 1
                        self.filtering_stats['ionization']['failure_reasons'].append('Ionized SMILES parsing failed')
                        continue
                    
                    # Additional validation checks for ionized molecule
                    validation_result = self._comprehensive_ionization_validation(ionized_mol, canonical_smiles)
                    
                    if not validation_result['valid']:
                        failed_compounds.append({
                            'index': row.get('original_index', idx),
                            'reason': f'Ionization validation failed: {validation_result["reason"]}',
                            'original_smiles': row.get('smiles', ''),
                            'canonical_smiles': canonical_smiles,
                            'ionized_smiles': ionized_smiles,
                            'validation_details': validation_result
                        })
                        self.filtering_stats['ionization']['failed'] += 1
                        self.filtering_stats['ionization']['failure_reasons'].append(f'Validation failed: {validation_result["reason"]}')
                        continue
                    
                    # Calculate ionization properties
                    ionization_properties = self._calculate_ionization_properties(ionized_mol, canonical_smiles)
                    
                    # Update molecule object and add ionization info
                    row_dict = row.to_dict()
                    row_dict['mol_object'] = ionized_mol
                    row_dict['ionized_smiles'] = ionized_smiles
                    row_dict['ionization_changed'] = ionized_smiles != canonical_smiles
                    row_dict['ionization_method'] = ionization_method
                    row_dict['ionization_properties'] = ionization_properties
                    row_dict['formal_charge'] = Chem.rdmolops.GetFormalCharge(ionized_mol)
                    row_dict['final_smiles'] = Chem.MolToSmiles(ionized_mol, canonical=True)
                    
                    valid_compounds.append(row_dict)
                    self.filtering_stats['ionization']['passed'] += 1
                    
                except Exception as e:
                    failed_compounds.append({
                        'index': row.get('original_index', idx),
                        'reason': f'Ionization error: {str(e)}',
                        'original_smiles': row.get('smiles', ''),
                        'canonical_smiles': canonical_smiles
                    })
                    self.filtering_stats['ionization']['failed'] += 1
                    self.filtering_stats['ionization']['failure_reasons'].append('Ionization error')
        
        valid_df = pd.DataFrame(valid_compounds)
        failed_df = pd.DataFrame(failed_compounds)
        
        print(f"   ✅ Passed: {len(valid_df):,} compounds")
        print(f"   ❌ Failed: {len(failed_df):,} compounds")
        
        return valid_df, failed_df

    def _validate_ionized_structure(self, ionized_mol, original_smiles):
        """Validate ionized structure against original"""
        try:
            # Check if molecule is valid
            Chem.SanitizeMol(ionized_mol)
            
            # Check atom count consistency (should be same or very close)
            original_mol = Chem.MolFromSmiles(original_smiles)
            if original_mol is None:
                return False
            
            original_atoms = original_mol.GetNumAtoms()
            ionized_atoms = ionized_mol.GetNumAtoms()
            
            # Allow small differences due to protonation/deprotonation
            if abs(original_atoms - ionized_atoms) > 5:
                return False
            
            # Check for reasonable formal charge
            formal_charge = Chem.rdmolops.GetFormalCharge(ionized_mol)
            if abs(formal_charge) > 3:  # Reasonable charge limit
                return False
            
            return True
            
        except Exception:
            return False

    def _manual_ionization_ph74(self, smiles):
        """Manual ionization for common functional groups at pH 7.4"""
        try:
            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                return smiles
            
            # Create editable molecule
            em = Chem.EditableMol(mol)
            
            # Common ionization patterns at pH 7.4
            # Carboxylic acids (pKa ~4-5) -> deprotonated
            # Amines (pKa ~9-10) -> protonated
            # Phosphates (pKa ~2, 7, 12) -> partially deprotonated
            
            # This is a simplified approach - in practice, you'd want more sophisticated pKa prediction
            ionized_smiles = smiles
            
            # Basic transformations (simplified)
            transformations = [
                ('C(=O)O', 'C(=O)[O-]'),  # Carboxylic acid to carboxylate
                ('N', '[NH+]'),           # Basic nitrogen protonation (simplified)
            ]
            
            for pattern, replacement in transformations:
                if pattern in smiles:
                    # This is overly simplified - real implementation would need proper SMARTS matching
                    pass
            
            return ionized_smiles
            
        except Exception:
            return smiles

    def _comprehensive_ionization_validation(self, ionized_mol, original_smiles):
        """Comprehensive validation of ionized structure"""
        try:
            # Basic sanitization check
            Chem.SanitizeMol(ionized_mol)
            
            # Check molecular weight change (should be reasonable)
            original_mol = Chem.MolFromSmiles(original_smiles)
            if original_mol is None:
                return {'valid': False, 'reason': 'Original molecule invalid'}
            
            original_mw = Descriptors.MolWt(original_mol)
            ionized_mw = Descriptors.MolWt(ionized_mol)
            mw_diff = abs(original_mw - ionized_mw)
            
            # Allow reasonable MW difference (protons, small ions)
            if mw_diff > 50:  # Arbitrary but reasonable threshold
                return {'valid': False, 'reason': f'Excessive MW change: {mw_diff:.1f}'}
            
            # Check formal charge reasonableness
            formal_charge = Chem.rdmolops.GetFormalCharge(ionized_mol)
            if abs(formal_charge) > 4:
                return {'valid': False, 'reason': f'Excessive formal charge: {formal_charge}'}
            
            # Check for unusual valences
            for atom in ionized_mol.GetAtoms():
                if atom.GetTotalValence() > 8:
                    return {'valid': False, 'reason': f'Unusual valence: {atom.GetSymbol()}({atom.GetTotalValence()})'}
            
            # Check connectivity preservation (simplified)
            original_bonds = original_mol.GetNumBonds()
            ionized_bonds = ionized_mol.GetNumBonds()
            if abs(original_bonds - ionized_bonds) > 2:
                return {'valid': False, 'reason': 'Significant connectivity change'}
            
            return {'valid': True, 'reason': 'Passed all validation checks'}
            
        except Exception as e:
            return {'valid': False, 'reason': f'Validation error: {str(e)}'}

    def _calculate_ionization_properties(self, ionized_mol, original_smiles):
        """Calculate properties related to ionization"""
        try:
            properties = {}
            
            # Basic properties
            properties['formal_charge'] = Chem.rdmolops.GetFormalCharge(ionized_mol)
            properties['num_charged_atoms'] = sum(1 for atom in ionized_mol.GetAtoms() if atom.GetFormalCharge() != 0)
            
            # Compare with original
            original_mol = Chem.MolFromSmiles(original_smiles)
            if original_mol is not None:
                properties['mw_change'] = Descriptors.MolWt(ionized_mol) - Descriptors.MolWt(original_mol)
                properties['logp_change'] = Crippen.MolLogP(ionized_mol) - Crippen.MolLogP(original_mol)
            
            return properties
            
        except Exception:
            return {}

    def duplicate_removal_filter(self, df):
        """Step 7: Duplicate removal filter"""
        print(f"\n🔄 Step 7: Duplicate Removal Filter")
        
        # Group by final SMILES to find duplicates
        duplicate_groups = defaultdict(list)
        
        print("   Finding duplicates...")
        with tqdm(df.iterrows(), total=len(df), desc="Finding duplicates", ncols=100, colour='magenta') as pbar:
            for idx, row in pbar:
                final_smiles = row['final_smiles']
                if pd.notna(final_smiles):
                    duplicate_groups[final_smiles].append(idx)
        
        # Keep first occurrence of each unique SMILES
        unique_indices = []
        duplicate_info = []
        failed_compounds = []
        
        print("   Processing duplicate groups...")
        for smiles, indices in tqdm(duplicate_groups.items(), desc="Processing duplicates", ncols=100):
            unique_indices.append(indices[0])  # Keep first occurrence
            
            if len(indices) > 1:
                duplicate_info.append({
                    'final_smiles': smiles,
                    'duplicate_count': len(indices),
                    'kept_index': indices[0],
                    'removed_indices': indices[1:]
                })
                
                # Add removed duplicates to failed compounds
                for dup_idx in indices[1:]:
                    row = df.iloc[dup_idx]
                    failed_compounds.append({
                        'index': row.get('original_index', dup_idx),
                        'reason': f'Duplicate of compound at index {indices[0]}',
                        'original_smiles': row.get('smiles', ''),
                        'final_smiles': smiles,
                        'duplicate_group_size': len(indices)
                    })
                    self.filtering_stats['duplicate_removal']['failed'] += 1
                    self.filtering_stats['duplicate_removal']['failure_reasons'].append('Duplicate compound')
        
        # Create final valid dataframe
        valid_df = df.iloc[unique_indices].reset_index(drop=True)
        failed_df = pd.DataFrame(failed_compounds)
        
        self.filtering_stats['duplicate_removal']['passed'] = len(valid_df)
        
        print(f"   ✅ Unique compounds: {len(valid_df):,}")
        print(f"   ❌ Duplicates removed: {len(failed_df):,}")
        print(f"   📊 Duplicate groups found: {len([g for g in duplicate_groups.values() if len(g) > 1]):,}")
        
        return valid_df, failed_df, duplicate_info

    def sequential_filtering_pipeline(self, df, smiles_column='smiles'):
        """Run the complete sequential filtering pipeline with enhanced filters"""
        print(f"\n🧪 Enhanced Sequential Molecular Filtering Pipeline")
        print(f"=" * 60)
        print(f"📊 Starting with {len(df):,} compounds")
        
        # Initialize with input data
        self.filtering_stats['initial']['passed'] = len(df)
        current_df = df.copy()
        
        # Store failed compounds from each step
        all_failed_compounds = {}
        
        # Step 1: SMILES Parsing
        current_df, failed_parsing = self.parse_smiles_filter(current_df, smiles_column)
        all_failed_compounds['parsing'] = failed_parsing
        if len(current_df) == 0:
            print("❌ No compounds passed SMILES parsing. Stopping pipeline.")
            return current_df, all_failed_compounds, None
        
        # Step 2: Fragment Filtering
        current_df, failed_fragments = self.fragment_filter(current_df, smiles_column)
        all_failed_compounds['fragment_filter'] = failed_fragments
        if len(current_df) == 0:
            print("❌ No compounds passed fragment filtering. Stopping pipeline.")
            return current_df, all_failed_compounds, None
        
        # Step 3: Salt Removal
        current_df, failed_salts = self.salt_removal_filter(current_df)
        all_failed_compounds['salt_removal'] = failed_salts
        if len(current_df) == 0:
            print("❌ No compounds passed salt removal. Stopping pipeline.")
            return current_df, all_failed_compounds, None
        
        # Step 4: Metal Removal
        current_df, failed_metals = self.metal_removal_filter(current_df)
        all_failed_compounds['metal_removal'] = failed_metals
        if len(current_df) == 0:
            print("❌ No compounds passed metal removal. Stopping pipeline.")
            return current_df, all_failed_compounds, None
        
        # Step 5: Normalization
        current_df, failed_normalization = self.normalization_filter(current_df)
        all_failed_compounds['normalization'] = failed_normalization
        if len(current_df) == 0:
            print("❌ No compounds passed normalization. Stopping pipeline.")
            return current_df, all_failed_compounds, None
        
        # Step 6: Enhanced Ionization
        current_df, failed_ionization = self.enhanced_ionization_filter(current_df)
        all_failed_compounds['ionization'] = failed_ionization
        if len(current_df) == 0:
            print("❌ No compounds passed enhanced ionization. Stopping pipeline.")
            return current_df, all_failed_compounds, None
        
        # Step 7: Duplicate Removal
        current_df, failed_duplicates, duplicate_info = self.duplicate_removal_filter(current_df)
        all_failed_compounds['duplicate_removal'] = failed_duplicates
        
        print(f"\n🎉 Enhanced Sequential Filtering Complete!")
        print(f"📊 Final library size: {len(current_df):,} compounds")
        print(f"📉 Total compounds removed: {len(df) - len(current_df):,}")
        print(f"📈 Success rate: {len(current_df)/len(df)*100:.1f}%")
        
        return current_df, all_failed_compounds, duplicate_info



# Original source: Part 1, generate_sequential_filtering_visualizations
def generate_sequential_filtering_visualizations(filter_obj, output_folder):
    """Generate high-quality beautiful visualizations for sequential filtering"""
    print(f"\n🎨 Generating High-Quality Sequential Filtering Visualizations...")
    
    # Set publication-quality parameters
    plt.rcParams.update({
        'font.size': 12,
        'font.family': 'serif',
        'axes.linewidth': 1.5,
        'axes.spines.right': False,
        'axes.spines.top': False,
        'grid.alpha': 0.3,
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'savefig.bbox': 'tight',
        'savefig.facecolor': 'white'
    })
    
    # Extract data for visualization
    steps = list(filter_obj.step_descriptions.keys())
    step_names = [filter_obj.step_descriptions[step] for step in steps]
    passed_counts = [filter_obj.filtering_stats[step]['passed'] for step in steps]
    failed_counts = [filter_obj.filtering_stats[step]['failed'] for step in steps]
    
    # Calculate cumulative passed (for funnel chart)
    cumulative_passed = []
    current_count = passed_counts[0]  # Start with initial count
    cumulative_passed.append(current_count)
    
    for i in range(1, len(passed_counts)):
        current_count = passed_counts[i]
        cumulative_passed.append(current_count)
    #colors = plt.cm.viridis(np.linspace(0, 1, len(steps)))
    # Define beautiful color palettes
    colors_gradient = plt.cm.plasma(np.linspace(0.1, 0.9, len(steps)))
    colors_viridis = plt.cm.viridis(np.linspace(0.1, 0.9, len(steps)))
    colors_cool = plt.cm.coolwarm(np.linspace(0.2, 0.8, len(steps)))
    
    # 1. Enhanced Sequential Filtering Funnel Chart with Gradient
    fig, ax = plt.subplots(figsize=(18, 12))
    
    y_positions = np.arange(len(steps))[::-1]  # Reverse order for funnel effect
    max_width = max(cumulative_passed)
    
    # Create beautiful gradient bars
    bars = ax.barh(y_positions, cumulative_passed, color=colors_viridis, alpha=0.85, 
                   edgecolor='white', linewidth=2.5, height=0.7)
    
    # Add gradient effect to bars
    for i, (bar, count) in enumerate(zip(bars, cumulative_passed)):
        # Add inner shadow effect
        inner_bar = ax.barh(y_positions[i], count * 0.95, left=count * 0.025, 
                           color=colors_viridis[i], alpha=0.6, height=0.5)
        
        # Add value labels with better formatting
        width = bar.get_width()
        ax.text(width + max_width*0.015, bar.get_y() + bar.get_height()/2,
               f'{count:,}', ha='left', va='center', fontsize=14, fontweight='bold',
               bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
        
        # Add percentage retention with beautiful styling
        if i > 0:
            retention = count / cumulative_passed[0] * 100
            ax.text(width/2, bar.get_y() + bar.get_height()/2,
                   f'{retention:.1f}%', ha='center', va='center', 
                   fontsize=13, fontweight='bold', color='white',
                   bbox=dict(boxstyle="round,pad=0.2", facecolor='black', alpha=0.7))
    
    # Beautiful connecting lines with gradient
    for i in range(len(y_positions)-1):
        x1 = cumulative_passed[i]
        x2 = cumulative_passed[i+1]
        y1 = y_positions[i] - 0.35
        y2 = y_positions[i+1] + 0.35
        ax.plot([x1, x2], [y1, y2], color='gray', alpha=0.5, linewidth=2, linestyle='--')
    
    ax.set_yticks(y_positions)
    ax.set_yticklabels(step_names, fontsize=13, fontweight='bold')
    ax.set_xlabel('Number of Compounds', fontsize=16, fontweight='bold', labelpad=15)
    ax.set_title('Enhanced Sequential Molecular Filtering Funnel', 
                fontsize=20, fontweight='bold', pad=25, 
                bbox=dict(boxstyle="round,pad=0.5", facecolor='lightblue', alpha=0.3))
    ax.grid(axis='x', linestyle=':', alpha=0.4, linewidth=1)
    ax.set_facecolor('#fafafa')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, '01_enhanced_filtering_funnel_beautiful.png'),
                dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    # 2. Dual-Panel Step Analysis with Enhanced Styling
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(24, 10))
    fig.suptitle('Sequential Filtering Step Analysis - Enhanced Visualization', 
                fontsize=22, fontweight='bold', y=0.95)
    
    # Left plot: Passed compounds with gradient bars
    x_pos = np.arange(len(step_names))
    bars1 = ax1.bar(x_pos, cumulative_passed, color=colors_viridis, alpha=0.8, 
                    edgecolor='white', linewidth=2, width=0.7)
    
    # Add gradient effect and value labels
    for i, (bar, count) in enumerate(zip(bars1, cumulative_passed)):
        height = bar.get_height()
        # Add inner gradient
        ax1.bar(i, height * 0.9, bottom=height * 0.05, color=colors_viridis[i], 
               alpha=0.5, width=0.5, edgecolor='none')
        
        # Beautiful value labels
        ax1.text(bar.get_x() + bar.get_width()/2., height + height*0.05,
                f'{count:,}', ha='center', va='bottom', fontsize=11, fontweight='bold',
                bbox=dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.9))
    
    ax1.set_xticks(x_pos)
    ax1.set_xticklabels(step_names, rotation=45, ha='right', fontsize=11, fontweight='bold')
    ax1.set_ylabel('Compounds Passed', fontsize=14, fontweight='bold', labelpad=10)
    ax1.set_title('Compounds Passing Each Filter Step', fontsize=16, fontweight='bold', pad=15)
    ax1.grid(axis='y', linestyle=':', alpha=0.4)
    ax1.set_facecolor('#f8f9fa')
    
    # Right plot: Failed compounds with warm colors
    failed_at_step = failed_counts[1:]  # Exclude initial step
    step_names_failed = step_names[1:]  # Exclude initial step
    
    bars2 = ax2.bar(range(len(step_names_failed)), failed_at_step, 
                    color=colors_cool, alpha=0.8, edgecolor='white', linewidth=2, width=0.7)
    
    # Add gradient effect and value labels
    for i, (bar, count) in enumerate(zip(bars2, failed_at_step)):
        height = bar.get_height()
        if height > 0:
            # Add inner gradient
            ax2.bar(i, height * 0.9, bottom=height * 0.05, color=colors_cool[i+1], 
                   alpha=0.5, width=0.5, edgecolor='none')
            
            # Beautiful value labels
            ax2.text(bar.get_x() + bar.get_width()/2., height + height*0.05,
                    f'{count:,}', ha='center', va='bottom', fontsize=11, fontweight='bold',
                    bbox=dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.9))
    
    ax2.set_xticks(range(len(step_names_failed)))
    ax2.set_xticklabels(step_names_failed, rotation=45, ha='right', fontsize=11, fontweight='bold')
    ax2.set_ylabel('Compounds Failed', fontsize=14, fontweight='bold', labelpad=10)
    ax2.set_title('Compounds Failing at Each Filter Step', fontsize=16, fontweight='bold', pad=15)
    ax2.grid(axis='y', linestyle=':', alpha=0.4)
    ax2.set_facecolor('#f8f9fa')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, '02_step_analysis_enhanced.png'),
                dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    # 3. Beautiful Success Rate Curve with Area Fill
    fig, ax = plt.subplots(figsize=(16, 10))
    
    success_rates = [count/cumulative_passed[0]*100 for count in cumulative_passed]
    x_positions = np.arange(len(step_names))
    
    # Create beautiful curve with gradient fill
    line = ax.plot(x_positions, success_rates, 'o-', linewidth=4, markersize=12, 
                   color='#2E86AB', markerfacecolor='#A23B72', markeredgecolor='white', 
                   markeredgewidth=3, alpha=0.9)
    
    # Add gradient area fill
    ax.fill_between(x_positions, success_rates, alpha=0.3, 
                   color='#2E86AB', interpolate=True)
    
    # Add secondary fill for visual depth
    ax.fill_between(x_positions, success_rates, alpha=0.1, 
                   color='#A23B72', interpolate=True)
    
    # Beautiful value labels with custom styling
    for i, (x, y) in enumerate(zip(x_positions, success_rates)):
        ax.text(x, y + 2, f'{y:.1f}%', ha='center', va='bottom', 
               fontsize=12, fontweight='bold',
               bbox=dict(boxstyle="round,pad=0.3", facecolor='white', 
                        edgecolor='#2E86AB', alpha=0.9))
        
        # Add connecting lines from points to labels
        ax.plot([x, x], [y, y + 1.5], color='gray', alpha=0.5, linewidth=1)
    
    ax.set_xticks(x_positions)
    ax.set_xticklabels(step_names, rotation=45, ha='right', fontsize=12, fontweight='bold')
    ax.set_ylabel('Success Rate (%)', fontsize=16, fontweight='bold', labelpad=15)
    ax.set_title('Cumulative Success Rate Through Enhanced Filtering Pipeline', 
                fontsize=18, fontweight='bold', pad=25,
                bbox=dict(boxstyle="round,pad=0.5", facecolor='lightgreen', alpha=0.3))
    ax.grid(True, linestyle=':', alpha=0.4, linewidth=1)
    ax.set_ylim(0, 105)
    ax.set_facecolor("#fafafa")
    
    # Add trend annotation
    if len(success_rates) > 1:
        trend = success_rates[-1] - success_rates[0]
        ax.annotate(f'Overall Change: {trend:.1f}%', 
                   xy=(len(step_names)-1, success_rates[-1]), 
                   xytext=(len(step_names)-2, success_rates[-1] + 10),
                   arrowprops=dict(arrowstyle='->', color='red', lw=2),
                   fontsize=12, fontweight='bold',
                   bbox=dict(boxstyle="round,pad=0.3", facecolor='yellow', alpha=0.7))
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, '03_success_rate_beautiful.png'),
                dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    # 4. Impact Analysis with 3D-like Effect
    fig, ax = plt.subplots(figsize=(16, 10))
    
    # Calculate compounds lost at each step
    compounds_lost = []
    for i in range(1, len(cumulative_passed)):
        lost = cumulative_passed[i-1] - cumulative_passed[i]
        compounds_lost.append(lost)
    
    step_names_impact = step_names[1:]  # Exclude initial step
    
    # Create 3D-like bars with shadow effect
    x_pos = np.arange(len(step_names_impact))
    
    # Shadow bars (offset)
    shadow_bars = ax.bar(x_pos + 0.05, compounds_lost, color='gray', alpha=0.3, 
                        width=0.8, zorder=1)
    
    # Main bars with gradient
    main_bars = ax.bar(x_pos, compounds_lost, color=colors_cool[:len(compounds_lost)], 
                      alpha=0.85, edgecolor='white', linewidth=2, width=0.8, zorder=2)
    
    # Add inner gradient bars
    for i, (bar, count) in enumerate(zip(main_bars, compounds_lost)):
        if count > 0:
            height = bar.get_height()
            # Inner gradient
            ax.bar(i, height * 0.8, bottom=height * 0.1, 
                  color=colors_cool[i], alpha=0.5, width=0.6, zorder=3)
            
            # Beautiful value labels
            ax.text(bar.get_x() + bar.get_width()/2., height + height*0.02,
                   f'{count:,}', ha='center', va='bottom', fontsize=12, fontweight='bold',
                   bbox=dict(boxstyle="round,pad=0.3", facecolor='white', 
                            edgecolor=colors_cool[i], alpha=0.9))
    
    ax.set_xticks(x_pos)
    ax.set_xticklabels(step_names_impact, rotation=45, ha='right', fontsize=12, fontweight='bold')
    ax.set_ylabel('Compounds Lost', fontsize=16, fontweight='bold', labelpad=15)
    ax.set_title('Impact Analysis: Compounds Lost at Each Enhanced Filter Step', 
                fontsize=18, fontweight='bold', pad=25,
                bbox=dict(boxstyle="round,pad=0.5", facecolor='lightyellow', alpha=0.3))
    ax.grid(axis='y', linestyle=':', alpha=0.4, linewidth=1)
    ax.set_facecolor('#f8f9fa')
    
    # Add impact ranking
    if compounds_lost:
        max_impact_idx = compounds_lost.index(max(compounds_lost))
        ax.annotate(f'Highest Impact:\n{step_names_impact[max_impact_idx]}', 
                   xy=(max_impact_idx, max(compounds_lost)), 
                   xytext=(max_impact_idx + 1, max(compounds_lost) * 1.2),
                   arrowprops=dict(arrowstyle='->', color='red', lw=3),
                   fontsize=12, fontweight='bold',
                   bbox=dict(boxstyle="round,pad=0.4", facecolor='red', alpha=0.2))
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, '04_impact_analysis_3d.png'),
                dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    # 5. Comprehensive Dashboard with Modern Design
    fig = plt.figure(figsize=(24, 16))
    fig.patch.set_facecolor('#f8f9fa')
    gs = fig.add_gridspec(4, 4, hspace=0.3, wspace=0.3, 
                         left=0.05, right=0.95, top=0.92, bottom=0.08)
    
    # Main title with beautiful styling
    fig.suptitle('Enhanced Sequential Molecular Filtering Dashboard', 
                fontsize=24, fontweight='bold', y=0.96,
                bbox=dict(boxstyle="round,pad=0.8", facecolor='lightblue', alpha=0.3))
    
    # Top section: Funnel chart (spanning 3 columns)
    ax1 = fig.add_subplot(gs[0:2, :3])
    bars = ax1.barh(range(len(step_names)), cumulative_passed, 
                    color=colors_gradient, alpha=0.8, edgecolor='white', linewidth=2)
    
    for i, (bar, count) in enumerate(zip(bars, cumulative_passed)):
        width = bar.get_width()
        ax1.text(width + max(cumulative_passed)*0.02, bar.get_y() + bar.get_height()/2,
                f'{count:,}', ha='left', va='center', fontsize=11, fontweight='bold',
                bbox=dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.9))
    
    ax1.set_yticks(range(len(step_names)))
    ax1.set_yticklabels(step_names, fontsize=11, fontweight='bold')
    ax1.set_title('Filtering Funnel', fontsize=16, fontweight='bold', pad=15)
    ax1.grid(axis='x', alpha=0.3, linestyle=':')
    ax1.set_facecolor('#fafafa')
    
    # Top right: Success rate gauge-style
    ax2 = fig.add_subplot(gs[0:2, 3])
    final_success_rate = cumulative_passed[-1] / cumulative_passed[0] * 100
    
    # Create a gauge-like visualization
    theta = np.linspace(0, np.pi, 100)
    r = np.ones_like(theta)
    
    # Background arc
    ax2.plot(theta, r, color='lightgray', linewidth=20, alpha=0.3)
    
    # Success rate arc
    success_theta = theta[:int(final_success_rate)]
    ax2.plot(success_theta, r[:len(success_theta)], color='green', linewidth=20, alpha=0.8)
    
    # Add percentage text
    ax2.text(np.pi/2, 0.5, f'{final_success_rate:.1f}%', ha='center', va='center', 
            fontsize=20, fontweight='bold',
            bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.9))
    
    ax2.set_xlim(0, np.pi)
    ax2.set_ylim(0, 1.2)
    ax2.set_title('Overall Success Rate', fontsize=14, fontweight='bold')
    ax2.axis('off')
    
    # Middle section: Step impact
    ax3 = fig.add_subplot(gs[2, :])
    bars = ax3.bar(range(len(step_names_impact)), compounds_lost, 
                   color=colors_cool[:len(compounds_lost)], alpha=0.8, 
                   edgecolor='white', linewidth=2)
    
    for i, (bar, count) in enumerate(zip(bars, compounds_lost)):
        height = bar.get_height()
        if height > 0:
            ax3.text(bar.get_x() + bar.get_width()/2., height + height*0.02,
                    f'{count:,}', ha='center', va='bottom', fontsize=10, fontweight='bold',
                    bbox=dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.9))
    
    ax3.set_xticks(range(len(step_names_impact)))
    ax3.set_xticklabels(step_names_impact, rotation=45, ha='right', fontsize=10, fontweight='bold')
    ax3.set_title('Compounds Lost at Each Step', fontsize=14, fontweight='bold')
    ax3.grid(axis='y', alpha=0.3, linestyle=':')
    ax3.set_facecolor('#fafafa')
    
    # Bottom section: Summary statistics with beautiful table
    ax4 = fig.add_subplot(gs[3, :])
    ax4.axis('off')
    
    # Create enhanced summary table
    summary_data = [
        ['Initial Compounds', f"{cumulative_passed[0]:,}", '🧪'],
        ['Final Compounds', f"{cumulative_passed[-1]:,}", '✅'],
        ['Total Removed', f"{cumulative_passed[0] - cumulative_passed[-1]:,}", '❌'],
        ['Overall Success Rate', f"{final_success_rate:.1f}%", '📈'],
        ['Most Impactful Filter', step_names_impact[compounds_lost.index(max(compounds_lost))], '🎯'],
        ['Max Compounds Lost', f"{max(compounds_lost):,}", '📉']
    ]
    
    # Create table with custom styling
    table = ax4.table(cellText=[[row[1], row[2]] for row in summary_data], 
                     rowLabels=[row[0] for row in summary_data],
                     cellLoc='center', loc='center',
                     colWidths=[0.15, 0.1])
    
    table.auto_set_font_size(False)
    table.set_fontsize(12)
    table.scale(1.2, 2.5)
    
    # Style the table with gradient colors
    colors_table = ['#e8f4fd', '#d1ecf1', '#ffeaa7', '#fab1a0', '#fd79a8', '#fdcb6e']
    for i in range(len(summary_data)):
        table[(i, 0)].set_facecolor(colors_table[i])
        table[(i, 1)].set_facecolor(colors_table[i])
        table[(i, -1)].set_facecolor('#f8f9fa')
        table[(i, -1)].set_text_props(weight='bold')
    
    plt.savefig(os.path.join(output_folder, '05_comprehensive_dashboard_modern.png'),
                dpi=300, bbox_inches='tight', facecolor='#f8f9fa', edgecolor='none')
    plt.close()
    
    # 6. Circular/Radial Filtering Visualization (New!)
    fig, ax = plt.subplots(figsize=(14, 14), subplot_kw=dict(projection='polar'))
    
    # Create radial bar chart
    theta = np.linspace(0, 2*np.pi, len(step_names), endpoint=False)
    radii = [count/max(cumulative_passed) for count in cumulative_passed]
    width = 2*np.pi / len(step_names) * 0.8
    
    bars = ax.bar(theta, radii, width=width, color=colors_gradient, alpha=0.8, 
                 edgecolor='white', linewidth=2)
    
    # Add labels
    for angle, radius, name, count in zip(theta, radii, step_names, cumulative_passed):
        ax.text(angle, radius + 0.1, f'{count:,}', ha='center', va='center', 
               fontsize=10, fontweight='bold', rotation=np.degrees(angle)-90 if angle > np.pi/2 and angle < 3*np.pi/2 else np.degrees(angle)+90)
        ax.text(angle, -0.15, name, ha='center', va='center', 
               fontsize=9, fontweight='bold', rotation=np.degrees(angle)-90 if angle > np.pi/2 and angle < 3*np.pi/2 else np.degrees(angle)+90)
    
    ax.set_ylim(0, 1.2)
    ax.set_title('Radial Filtering Visualization\nCircular View of Sequential Steps', 
                fontsize=16, fontweight='bold', pad=30,
                bbox=dict(boxstyle="round,pad=0.5", facecolor='lightcyan', alpha=0.3))
    ax.grid(True, alpha=0.3)
    
    plt.savefig(os.path.join(output_folder, '06_radial_filtering_visualization.png'),
                dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    # 7. Sankey-style Flow Diagram (Simplified)
    fig, ax = plt.subplots(figsize=(20, 12))
    
    # Create flow visualization
    y_levels = np.arange(len(step_names))
    x_positions = [0] + [i*3 for i in range(1, len(step_names))]
    
    # Draw flow rectangles
    for i, (x, y, count, name) in enumerate(zip(x_positions, y_levels, cumulative_passed, step_names)):
        # Rectangle height proportional to compound count
        height = count / max(cumulative_passed) * 2
        
        rect = plt.Rectangle((x-0.5, y-height/2), 1, height, 
                           facecolor=colors_gradient[i], alpha=0.8, 
                           edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        
        # Add labels
        ax.text(x, y+height/2+0.2, f'{count:,}', ha='center', va='bottom', 
               fontsize=12, fontweight='bold',
               bbox=dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.9))
        ax.text(x, y-height/2-0.3, name, ha='center', va='top', 
               fontsize=10, fontweight='bold', rotation=0)
        
        # Draw connecting flows
        if i < len(x_positions) - 1:
            next_height = cumulative_passed[i+1] / max(cumulative_passed) * 2
            # Flow lines
            ax.plot([x+0.5, x_positions[i+1]-0.5], [y, y_levels[i+1]], 
                   color='gray', alpha=0.5, linewidth=3)
    
    ax.set_xlim(-1, max(x_positions)+1)
    ax.set_ylim(-2, len(step_names)+1)
    ax.set_title('Sequential Filtering Flow Diagram\nSankey-Style Visualization', 
                fontsize=18, fontweight='bold', pad=25,
                bbox=dict(boxstyle="round,pad=0.5", facecolor='lightgreen', alpha=0.3))
    ax.axis('off')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, '07_flow_diagram_sankey.png'),
                dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    print(f"✅ Generated 7 high-quality beautiful filtering visualizations")



# Original source: Part 2, DrugAnalyzerSequential
class DrugAnalyzerSequential:
    def __init__(self, dataframe):
        self.df = dataframe.copy()
        self.original_count = len(dataframe)
        self.filtering_results = {}

    def calculate_properties(self):
        """Calculate molecular properties for all compounds"""
        print("🧮 Calculating molecular properties...")

        properties = []
        invalid_smiles = 0

        for idx, smiles in enumerate(self.df['smiles']):
            try:
                mol = Chem.MolFromSmiles(str(smiles)) if pd.notna(smiles) else None

                if mol is None:
                    invalid_smiles += 1
                    prop = {key: np.nan for key in ['MW', 'LogP', 'HBD', 'HBA', 'TPSA', 'RotBonds', 'Rings', 'HeavyAtoms', 'LogS']}
                else:
                    # Calculate all molecular descriptors
                    prop = {
                        'MW': Descriptors.MolWt(mol),
                        'LogP': Crippen.MolLogP(mol),
                        'HBD': Lipinski.NumHDonors(mol),
                        'HBA': Lipinski.NumHAcceptors(mol),
                        'TPSA': Descriptors.TPSA(mol),
                        'RotBonds': Descriptors.NumRotatableBonds(mol),
                        'Rings': rdMolDescriptors.CalcNumRings(mol),
                        'HeavyAtoms': mol.GetNumHeavyAtoms(),
                        'LogS': self.calculate_logS(mol)  # Improved LogS calculation
                    }

            except Exception as e:
                invalid_smiles += 1
                prop = {key: np.nan for key in ['MW', 'LogP', 'HBD', 'HBA', 'TPSA', 'RotBonds', 'Rings', 'HeavyAtoms', 'LogS']}

            properties.append(prop)

            # Progress indicator
            if (idx + 1) % 100 == 0:
                print(f"  Processed {idx + 1}/{len(self.df)} compounds...")

        # Add properties to dataframe
        for key in properties[0].keys():
            self.df[key] = [prop[key] for prop in properties]

        print(f"✅ Properties calculated! ({invalid_smiles} invalid SMILES found)")
        return self.df

    def calculate_logS(self, mol):
        """Improved LogS calculation using ESOL method"""
        try:
            # ESOL (Estimated SOLubility) method
            logP = Crippen.MolLogP(mol)
            MW = Descriptors.MolWt(mol)
            RB = Descriptors.NumRotatableBonds(mol)
            AP = rdMolDescriptors.CalcNumAromaticRings(mol)

            # ESOL equation
            logS = 0.16 - 0.63*logP - 0.0062*MW + 0.066*RB - 0.74*AP
            return logS
        except:
            return np.nan

    def apply_rule_filter(self, df, rule_name, conditions):
        """Apply a set of conditions and return filtered dataframe"""
        try:
            # Combine all conditions with AND logic
            combined_mask = np.ones(len(df), dtype=bool)
            for condition in conditions:
                # Handle NaN values by treating them as failures
                condition_mask = condition.fillna(False) if hasattr(condition, 'fillna') else condition
                combined_mask = combined_mask & condition_mask

            filtered_df = df.loc[combined_mask].copy()
            passed_count = len(filtered_df)
            failed_count = len(df) - passed_count

            print(f"  {rule_name}: {passed_count} passed, {failed_count} failed")
            return filtered_df

        except Exception as e:
            print(f"  Error in {rule_name} filter: {e}")
            return df

    def apply_pfizer_rule_filter(self, df):
        """Apply Pfizer Rule filter - removes compounds with LogP > 3 AND TPSA < 75 (potentially toxic)"""
        print("Applying Pfizer Rule filter...")

        # Pfizer Rule: Filter OUT compounds with LogP > 3 AND TPSA < 75
        # These compounds are considered potentially toxic
        pfizer_toxic_mask = (df['LogP'] > 3) & (df['TPSA'] < 75)

        # Keep compounds that do NOT meet the toxic criteria
        safe_mask = ~pfizer_toxic_mask.fillna(False)
        filtered_df = df.loc[safe_mask].copy()

        passed_count = len(filtered_df)
        failed_count = len(df) - passed_count

        print(f"  Pfizer Rule: {passed_count} passed, {failed_count} failed (potentially toxic compounds removed)")
        return filtered_df

    def apply_REOS_filter(self, df):
        """Apply REOS (Rapid Elimination Of Swill) filter"""
        print("🚫 Applying REOS filter...")

        # REOS unwanted substructures
        REOS_patterns = [
            '[#7][#7]',           # Azo groups
            '[#6]=[#7][#7]',      # Hydrazones
            '[#16]=[#16]',        # Disulfides
            '[#7]=[#7]',          # Azo
            '[#6]#[#7]',          # Nitriles (optional)
            '[#7][#16]',          # N-S bonds
            '[#16]=[#8]',         # Sulfoxides
            '[#15]',              # Phosphorus
            '[#9,#17,#35,#53]',   # Halogens (optional, can be removed)
            '[#33,#51,#83]',      # Metalloids
        ]

        reos_flags = []
        for smiles in df['smiles']:
            try:
                mol = Chem.MolFromSmiles(str(smiles)) if pd.notna(smiles) else None
                passes_reos = True

                if mol is not None:
                    for pattern in REOS_patterns:
                        try:
                            if mol.HasSubstructMatch(Chem.MolFromSmarts(pattern)):
                                passes_reos = False
                                break
                        except:
                            continue
                else:
                    passes_reos = False

                reos_flags.append(passes_reos)

            except Exception as e:
                reos_flags.append(False)

        filtered_df = df.loc[reos_flags].copy()
        passed_count = len(filtered_df)
        failed_count = len(df) - passed_count

        print(f"  REOS filter: {passed_count} passed, {failed_count} failed")
        return filtered_df

    def predict_toxicity_filter(self, df):
        """Apply toxicity prediction filter"""
        print("☠️ Applying toxicity filter...")

        # Structural alerts for toxicity
        toxic_patterns = [
            '[N+](=O)[O-]',       # Nitro groups
            '[CH]=O',             # Aldehydes
            'C1OC1',              # Epoxides
            'c[NH2]',             # Aromatic amines
            'N-N',                # Hydrazines
            '[SH]',               # Thiols
            'C=C-C=O',            # α,β-unsaturated carbonyls
            '[Cl,Br,I][CH2]',     # Alkyl halides
        ]

        toxicity_scores = []
        for idx, smiles in enumerate(df['smiles']):
            try:
                mol = Chem.MolFromSmiles(str(smiles)) if pd.notna(smiles) else None
                score = 0

                if mol is not None:
                    # Check structural alerts
                    for pattern in toxic_patterns:
                        try:
                            if mol.HasSubstructMatch(Chem.MolFromSmarts(pattern)):
                                score += 1
                        except:
                            continue

                    # Additional property-based toxicity indicators
                    row_idx = df.index[idx]
                    if not pd.isna(df.loc[row_idx, 'MW']) and df.loc[row_idx, 'MW'] > 800:
                        score += 1
                    if not pd.isna(df.loc[row_idx, 'LogP']) and df.loc[row_idx, 'LogP'] > 6:
                        score += 1
                    if not pd.isna(df.loc[row_idx, 'TPSA']) and df.loc[row_idx, 'TPSA'] > 200:
                        score += 1

                toxicity_scores.append(score)

            except Exception as e:
                toxicity_scores.append(10)  # Assume toxic if error

        # Filter out compounds with toxicity score >= 2
        df['Toxicity_Score'] = toxicity_scores
        filtered_df = df.loc[df['Toxicity_Score'] < 2].copy()

        passed_count = len(filtered_df)
        failed_count = len(df) - passed_count

        print(f"  Toxicity filter: {passed_count} passed, {failed_count} failed")
        return filtered_df

    def analyze_sequential(self):
        """Perform sequential drug-likeness filtering"""
        print("🔬 Starting sequential drug-likeness analysis...")
        print(f"📊 Initial dataset: {self.original_count} compounds\n")

        # Calculate properties
        self.calculate_properties()

        # Remove compounds with missing critical properties
        initial_df = self.df.dropna(subset=['MW', 'LogP', 'HBD', 'HBA']).copy()
        print(f"After removing invalid compounds: {len(initial_df)} compounds\n")

        current_df = initial_df.copy()
        self.filtering_results['Initial'] = len(current_df)

        # Apply Lipinski Rule first
        print("Applying Lipinski (Rule of 5)...")
        lipinski_conditions = [
            current_df['MW'] <= 500,
            current_df['LogP'] <= 5,
            current_df['HBD'] <= 5,
            current_df['HBA'] <= 10
        ]
        current_df = self.apply_rule_filter(current_df, 'Lipinski (Rule of 5)', lipinski_conditions)
        self.filtering_results['Lipinski (Rule of 5)'] = len(current_df)

        # Apply Pfizer Rule after Lipinski
        current_df = self.apply_pfizer_rule_filter(current_df)
        self.filtering_results['Pfizer Rule'] = len(current_df)

        # Define remaining drug-likeness rules
        rules_config = {
            'Veber': {
                'TPSA': ('<=', 140),
                'RotBonds': ('<=', 10)
            },
            'Ghose': {
                'MW': ('range', 160, 480),
                'LogP': ('range', -0.4, 5.6),
                'HeavyAtoms': ('<=', 50)
            },
            'Egan': {
                'TPSA': ('<=', 131.6),
                'LogP': ('range', -1, 6)
            },
            'Muegge': {
                'MW': ('range', 200, 600),
                'LogP': ('range', -2, 5),
                'TPSA': ('<=', 150),
                'Rings': ('<=', 7),
                'HBD': ('<=', 5),
                'HBA': ('<=', 10),
                'RotBonds': ('<=', 15)
            }
        }

        # Apply remaining rules sequentially
        for rule_name, rule_conditions in rules_config.items():
            print(f"Applying {rule_name}...")

            # Build conditions for current dataframe
            conditions = []
            for prop, condition in rule_conditions.items():
                if condition[0] == '<=':
                    conditions.append(current_df[prop] <= condition[1])
                elif condition[0] == '>=':
                    conditions.append(current_df[prop] >= condition[1])
                elif condition[0] == 'range':
                    conditions.append((current_df[prop] >= condition[1]) & (current_df[prop] <= condition[2]))

            current_df = self.apply_rule_filter(current_df, rule_name, conditions)
            self.filtering_results[rule_name] = len(current_df)

        # Apply solubility filter
        print("Applying Solubility filter...")
        soluble_mask = current_df['LogS'] > -4
        current_df = current_df.loc[soluble_mask.fillna(False)].copy()
        self.filtering_results['Soluble (LogS > -4)'] = len(current_df)
        print(f"  Solubility filter: {len(current_df)} passed")

        # Apply toxicity filter
        current_df = self.predict_toxicity_filter(current_df)
        self.filtering_results['Non-Toxic'] = len(current_df)

        # Apply REOS filter
        current_df = self.apply_REOS_filter(current_df)
        self.filtering_results['REOS'] = len(current_df)

        print(f"\n✅ Sequential filtering complete!")
        print(f"📊 Final result: {len(current_df)} compounds passed all filters")
        print(f"📉 Filtering efficiency: {len(current_df)/self.original_count*100:.1f}%")

        return current_df, self.filtering_results

    def create_visualizations(self, final_df, filtering_results):
        """Create comprehensive visualizations"""
        print("\n📊 Creating visualizations...")

        # Set up the plotting area
        fig = plt.figure(figsize=(22, 18))

        # 1. Filtering cascade plot
        plt.subplot(4, 4, 1)
        steps = list(filtering_results.keys())
        counts = list(filtering_results.values())
        colors = plt.cm.viridis(np.linspace(0, 1, len(steps)))

        bars = plt.bar(range(len(steps)), counts, color=colors)
        plt.title('Sequential Filtering Results', fontsize=14, fontweight='bold')
        plt.xlabel('Filtering Step')
        plt.ylabel('Number of Compounds')
        plt.xticks(range(len(steps)), steps, rotation=45, ha='right')

        # Add value labels on bars
        for bar, count in zip(bars, counts):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(counts)*0.01,
                    str(count), ha='center', va='bottom', fontweight='bold')

        plt.tight_layout()

        # 2. Property distributions (before and after)
        properties = ['MW', 'LogP', 'HBD', 'HBA', 'TPSA', 'RotBonds']

        for i, prop in enumerate(properties):
            plt.subplot(4, 4, i+2)

            # Original data
            original_data = self.df[prop].dropna()
            final_data = final_df[prop].dropna()

            if len(original_data) > 0:
                plt.hist(original_data, bins=30, alpha=0.5, label='Original', color='lightcoral', density=True)
            if len(final_data) > 0:
                plt.hist(final_data, bins=30, alpha=0.7, label='Filtered', color='steelblue', density=True)

            plt.title(f'{prop} Distribution', fontweight='bold')
            plt.xlabel(prop)
            plt.ylabel('Density')
            plt.legend()
            plt.grid(True, alpha=0.3)

        # 3. Correlation heatmap
        plt.subplot(4, 4, 8)
        correlation_props = ['MW', 'LogP', 'HBD', 'HBA', 'TPSA', 'RotBonds', 'LogS']
        available_props = [prop for prop in correlation_props if prop in final_df.columns]

        if len(available_props) > 1 and len(final_df) > 1:
            corr_matrix = final_df[available_props].corr()
            sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0,
                       square=True, fmt='.2f', cbar_kws={'shrink': 0.8})
        plt.title('Property Correlations (Filtered Data)', fontweight='bold')

        # 4. Drug-likeness space plot
        plt.subplot(4, 4, 9)
        original_mw = self.df['MW'].dropna()
        original_logp = self.df['LogP'].dropna()
        final_mw = final_df['MW'].dropna()
        final_logp = final_df['LogP'].dropna()

        if len(original_mw) > 0 and len(original_logp) > 0:
            plt.scatter(original_mw, original_logp, alpha=0.5, s=20, color='lightcoral', label='Original')
        if len(final_mw) > 0 and len(final_logp) > 0:
            plt.scatter(final_mw, final_logp, alpha=0.8, s=30, color='steelblue', label='Filtered')

        # Add Lipinski boundaries
        plt.axvline(x=500, color='red', linestyle='--', alpha=0.7, label='MW=500')
        plt.axhline(y=5, color='red', linestyle='--', alpha=0.7, label='LogP=5')

        plt.xlabel('Molecular Weight')
        plt.ylabel('LogP')
        plt.title('Drug-likeness Space (MW vs LogP)', fontweight='bold')
        plt.legend()
        plt.grid(True, alpha=0.3)

        # 5. Pfizer Rule visualization (NEW)
        plt.subplot(4, 4, 10)
        original_logp = self.df['LogP'].dropna()
        original_tpsa = self.df['TPSA'].dropna()
        final_logp_pfizer = final_df['LogP'].dropna()
        final_tpsa_pfizer = final_df['TPSA'].dropna()

        if len(original_logp) > 0 and len(original_tpsa) > 0:
            plt.scatter(original_logp, original_tpsa, alpha=0.5, s=20, color='lightcoral', label='Original')
        if len(final_logp_pfizer) > 0 and len(final_tpsa_pfizer) > 0:
            plt.scatter(final_logp_pfizer, final_tpsa_pfizer, alpha=0.8, s=30, color='steelblue', label='Filtered')

        # Add Pfizer Rule boundaries (toxic region)
        plt.axvline(x=3, color='red', linestyle='--', alpha=0.7, label='LogP=3')
        plt.axhline(y=75, color='red', linestyle='--', alpha=0.7, label='TPSA=75')

        # Highlight toxic region
        plt.fill([3, plt.xlim()[1], plt.xlim()[1], 3], [0, 0, 75, 75],
                 color='red', alpha=0.1, label='Pfizer Toxic Zone')

        plt.xlabel('LogP')
        plt.ylabel('TPSA')
        plt.title('Pfizer Rule Space (LogP vs TPSA)', fontweight='bold')
        plt.legend()
        plt.grid(True, alpha=0.3)

        # 6. Solubility vs Permeability
        plt.subplot(4, 4, 11)
        final_logs = final_df['LogS'].dropna()
        final_tpsa = final_df['TPSA'].dropna()

        if len(final_logs) > 0 and len(final_tpsa) > 0:
            plt.scatter(final_logs, final_tpsa, alpha=0.7, s=30, color='green')

        plt.axvline(x=-4, color='red', linestyle='--', alpha=0.7, label='LogS=-4')
        plt.axhline(y=140, color='red', linestyle='--', alpha=0.7, label='TPSA=140')

        plt.xlabel('LogS (Solubility)')
        plt.ylabel('TPSA (Permeability)')
        plt.title('Solubility vs Permeability', fontweight='bold')
        plt.legend()
        plt.grid(True, alpha=0.3)

        # 7. Summary statistics
        plt.subplot(4, 4, 12)
        plt.axis('off')

        # Calculate summary stats carefully to handle empty DataFrame or NaN values
        mean_mw = final_df['MW'].mean() if len(final_df) > 0 and not final_df['MW'].dropna().empty else 'N/A'
        mean_logp = final_df['LogP'].mean() if len(final_df) > 0 and not final_df['LogP'].dropna().empty else 'N/A'
        mean_tpsa = final_df['TPSA'].mean() if len(final_df) > 0 and not final_df['TPSA'].dropna().empty else 'N/A'
        mean_logs = final_df['LogS'].mean() if len(final_df) > 0 and not final_df['LogS'].dropna().empty else 'N/A'

        # Format values only if they are numbers, otherwise keep 'N/A'
        mean_mw_str = f"{mean_mw:.1f}" if isinstance(mean_mw, (int, float)) else mean_mw
        mean_logp_str = f"{mean_logp:.2f}" if isinstance(mean_logp, (int, float)) else mean_logp
        mean_tpsa_str = f"{mean_tpsa:.1f}" if isinstance(mean_tpsa, (int, float)) else mean_tpsa
        mean_logs_str = f"{mean_logs:.2f}" if isinstance(mean_logs, (int, float)) else mean_logs

        summary_text = f"""
        FILTERING SUMMARY

        Initial compounds: {self.original_count}
        Final compounds: {len(final_df)}
        Success rate: {len(final_df)/self.original_count*100:.1f}%

        FINAL DATASET STATS
        Mean MW: {mean_mw_str}
        Mean LogP: {mean_logp_str}
        Mean TPSA: {mean_tpsa_str}
        Mean LogS: {mean_logs_str}

        DRUG-LIKENESS
        Lipinski compliant: {len(final_df)}
        Pfizer Rule passed: {len(final_df)}
        Veber compliant: {len(final_df)}
        Non-toxic: {len(final_df)}
        REOS clean: {len(final_df)}
        """

        plt.text(0.1, 0.9, summary_text, transform=plt.gca().transAxes,
                fontsize=10, verticalalignment='top', fontfamily='monospace',
                bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.8))

        # 8. Filtering efficiency pie chart
        plt.subplot(4, 4, 13)
        passed = len(final_df)
        failed = self.original_count - passed

        plt.pie([passed, failed], labels=['Passed', 'Failed'],
               colors=['lightgreen', 'lightcoral'], autopct='%1.1f%%',
               startangle=90)
        plt.title('Overall Filtering Efficiency', fontweight='bold')

        # 9. Pfizer Rule impact visualization (NEW)
        plt.subplot(4, 4, 14)
        if 'Lipinski (Rule of 5)' in filtering_results and 'Pfizer Rule' in filtering_results:
            lipinski_count = filtering_results['Lipinski (Rule of 5)']
            pfizer_count = filtering_results['Pfizer Rule']
            pfizer_removed = lipinski_count - pfizer_count

            categories = ['After Lipinski', 'Pfizer Removed', 'After Pfizer']
            values = [lipinski_count, pfizer_removed, pfizer_count]
            colors = ['lightgreen', 'red', 'darkgreen']

            bars = plt.bar(categories, values, color=colors, alpha=0.7)
            plt.title('Pfizer Rule Impact', fontweight='bold')
            plt.ylabel('Number of Compounds')
            plt.xticks(rotation=45)

            # Add value labels
            for bar, value in zip(bars, values):
                plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(values)*0.01,
                        str(value), ha='center', va='bottom', fontweight='bold')

        # 10. Rule comparison stacked bar (NEW)
        plt.subplot(4, 4, 15)
        rule_names = ['Lipinski', 'Pfizer', 'Veber', 'Ghose', 'Egan', 'Muegge']
        rule_keys = ['Lipinski (Rule of 5)', 'Pfizer Rule', 'Veber', 'Ghose', 'Egan', 'Muegge']

        passed_counts = []
        failed_counts = []

        prev_count = self.original_count
        for rule_key in rule_keys:
            if rule_key in filtering_results:
                current_count = filtering_results[rule_key]
                failed = prev_count - current_count
                passed_counts.append(current_count)
                failed_counts.append(failed)
                prev_count = current_count
            else:
                passed_counts.append(0)
                failed_counts.append(0)

        x = np.arange(len(rule_names))
        width = 0.35

        p1 = plt.bar(x, passed_counts, width, label='Passed', color='lightgreen', alpha=0.7)
        p2 = plt.bar(x, failed_counts, width, bottom=passed_counts, label='Failed', color='lightcoral', alpha=0.7)

        plt.xlabel('Drug-likeness Rules')
        plt.ylabel('Number of Compounds')
        plt.title('Rule-by-Rule Filtering Results', fontweight='bold')
        plt.xticks(x, rule_names, rotation=45)
        plt.legend()

        # 11. Property ranges comparison (NEW)
        plt.subplot(4, 4, 16)
        if len(final_df) > 0:
            props_to_compare = ['MW', 'LogP', 'TPSA']
            prop_ranges = {}

            for prop in props_to_compare:
                if prop in final_df.columns:
                    data = final_df[prop].dropna()
                    if len(data) > 0:
                        prop_ranges[prop] = [data.min(), data.max(), data.mean()]

            if prop_ranges:
                props = list(prop_ranges.keys())
                mins = [prop_ranges[prop][0] for prop in props]
                maxs = [prop_ranges[prop][1] for prop in props]
                means = [prop_ranges[prop][2] for prop in props]

                x = np.arange(len(props))
                width = 0.25

                plt.bar(x - width, mins, width, label='Min', alpha=0.7)
                plt.bar(x, means, width, label='Mean', alpha=0.7)
                plt.bar(x + width, maxs, width, label='Max', alpha=0.7)

                plt.xlabel('Properties')
                plt.ylabel('Values')
                plt.title('Final Dataset Property Ranges', fontweight='bold')
                plt.xticks(x, props)
                plt.legend()

        plt.tight_layout()
        plt.show()

        # Create a detailed filtering cascade plot
        self.create_cascade_plot(filtering_results)

    def create_cascade_plot(self, filtering_results):
        """Create a detailed cascade/waterfall plot"""
        fig, ax = plt.subplots(figsize=(16, 8))

        steps = list(filtering_results.keys())
        counts = list(filtering_results.values())

        # Calculate drops
        drops = [counts[i] - counts[i+1] if i < len(counts)-1 else 0 for i in range(len(counts))]

        # Create waterfall effect
        x_pos = range(len(steps))
        colors = ['steelblue' if i == 0 else 'orange' if 'Pfizer' in steps[i] else 'lightcoral' for i in range(len(steps))]

        bars = ax.bar(x_pos, counts, color=colors, alpha=0.7, edgecolor='black')

        # Add connecting lines
        for i in range(len(steps)-1):
            if i+1 < len(x_pos):
                ax.plot([i+0.4, i+0.6], [counts[i+1], counts[i+1]], 'k--', alpha=0.5)

        # Add labels
        for i, (bar, count, drop) in enumerate(zip(bars, counts, drops)):
            # Count label
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(counts)*0.01,
                   str(count), ha='center', va='bottom', fontweight='bold', fontsize=10)

            # Drop label
            if drop > 0:
                ax.text(bar.get_x() + bar.get_width()/2, bar.get_height()/2,
                       f'-{drop}', ha='center', va='center',
                       color='white', fontweight='bold', fontsize=9)

        ax.set_xlabel('Filtering Steps', fontsize=12, fontweight='bold')
        ax.set_ylabel('Number of Compounds', fontsize=12, fontweight='bold')
        ax.set_title('Drug-Likeness Filtering Cascade (Including Pfizer Rule)', fontsize=16, fontweight='bold')
        ax.set_xticks(x_pos)
        ax.set_xticklabels(steps, rotation=45, ha='right')
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

    def generate_summary_report(self, final_df, filtering_results):
        """Generate detailed text summary report"""
        print("\n📝 Generating summary report...")

        # Create detailed summary
        summary_lines = []
        summary_lines.append("=" * 80)
        summary_lines.append("DRUG-LIKENESS ANALYSIS SUMMARY REPORT (WITH PFIZER RULE)")
        summary_lines.append("=" * 80)
        summary_lines.append("")

        # Overview
        summary_lines.append("OVERVIEW:")
        summary_lines.append("-" * 40)
        summary_lines.append(f"Initial Dataset Size: {self.original_count} compounds")
        summary_lines.append(f"Final Dataset Size: {len(final_df)} compounds")
        summary_lines.append(f"Overall Success Rate: {len(final_df)/self.original_count*100:.2f}%")
        summary_lines.append(f"Compounds Filtered Out: {self.original_count - len(final_df)}")
        summary_lines.append("")

        # Sequential filtering results
        summary_lines.append("SEQUENTIAL FILTERING RESULTS:")
        summary_lines.append("-" * 40)
        prev_count = self.original_count
        for step, count in filtering_results.items():
            removed = prev_count - count
            retention_rate = (count / prev_count * 100) if prev_count > 0 else 0
            summary_lines.append(f"{step:<25}: {count:>6} compounds ({retention_rate:>5.1f}% retained, {removed:>5} removed)")
            prev_count = count
        summary_lines.append("")

        # Property statistics
        if len(final_df) > 0:
            summary_lines.append("FINAL DATASET MOLECULAR PROPERTIES:")
            summary_lines.append("-" * 40)
            properties = ['MW', 'LogP', 'HBD', 'HBA', 'TPSA', 'RotBonds', 'Rings', 'HeavyAtoms', 'LogS']
            for prop in properties:
                if prop in final_df.columns:
                    prop_data = final_df[prop].dropna()
                    if len(prop_data) > 0:
                        summary_lines.append(f"{prop:<12}: Mean={prop_data.mean():>7.2f}, Std={prop_data.std():>7.2f}, Min={prop_data.min():>7.2f}, Max={prop_data.max():>7.2f}")
                    else:
                        summary_lines.append(f"{prop:<12}: No valid data")
            summary_lines.append("")

        # Drug-likeness compliance
        summary_lines.append("DRUG-LIKENESS RULE COMPLIANCE:")
        summary_lines.append("-" * 40)
        if len(final_df) > 0:
            # All compounds in final_df passed all rules by definition
            summary_lines.append(f"Lipinski Rule of 5 Compliant: {len(final_df)} compounds (100.0%)")
            summary_lines.append(f"Pfizer Rule Compliant: {len(final_df)} compounds (100.0%)")
            summary_lines.append(f"Veber Rule Compliant: {len(final_df)} compounds (100.0%)")
            summary_lines.append(f"Ghose Rule Compliant: {len(final_df)} compounds (100.0%)")
            summary_lines.append(f"Egan Rule Compliant: {len(final_df)} compounds (100.0%)")
            summary_lines.append(f"Muegge Rule Compliant: {len(final_df)} compounds (100.0%)")
            summary_lines.append(f"Non-Toxic: {len(final_df)} compounds (100.0%)")
            summary_lines.append(f"REOS Clean: {len(final_df)} compounds (100.0%)")
        else:
            summary_lines.append("No compounds passed all filters")
        summary_lines.append("")

        # Detailed rule descriptions
        summary_lines.append("DRUG-LIKENESS RULES APPLIED:")
        summary_lines.append("-" * 40)
        summary_lines.append("1. Lipinski Rule of 5:")
        summary_lines.append("   - Molecular Weight ≤ 500 Da")
        summary_lines.append("   - LogP ≤ 5")
        summary_lines.append("   - Hydrogen Bond Donors ≤ 5")
        summary_lines.append("   - Hydrogen Bond Acceptors ≤ 10")
        summary_lines.append("")
        summary_lines.append("2. Pfizer Rule (Toxicity Filter):")
        summary_lines.append("   - Removes compounds with LogP > 3 AND TPSA < 75")
        summary_lines.append("   - These compounds are considered potentially toxic")
        summary_lines.append("   - Applied after Lipinski filtering")
        summary_lines.append("")
        summary_lines.append("3. Veber Rule:")
        summary_lines.append("   - Topological Polar Surface Area ≤ 140 Ų")
        summary_lines.append("   - Rotatable Bonds ≤ 10")
        summary_lines.append("")
        summary_lines.append("4. Ghose Rule:")
        summary_lines.append("   - Molecular Weight: 160-480 Da")
        summary_lines.append("   - LogP: -0.4 to 5.6")
        summary_lines.append("   - Heavy Atoms ≤ 50")
        summary_lines.append("")
        summary_lines.append("5. Egan Rule:")
        summary_lines.append("   - TPSA ≤ 131.6 Ų")
        summary_lines.append("   - LogP: -1 to 6")
        summary_lines.append("")
        summary_lines.append("6. Muegge Rule:")
        summary_lines.append("   - Molecular Weight: 200-600 Da")
        summary_lines.append("   - LogP: -2 to 5")
        summary_lines.append("   - TPSA ≤ 150 Ų")
        summary_lines.append("   - Rings ≤ 7")
        summary_lines.append("   - HBD ≤ 5, HBA ≤ 10")
        summary_lines.append("   - Rotatable Bonds ≤ 15")
        summary_lines.append("")
        summary_lines.append("7. Solubility Filter:")
        summary_lines.append("   - LogS > -4 (soluble compounds)")
        summary_lines.append("")
        summary_lines.append("8. Toxicity Filter:")
        summary_lines.append("   - Removes compounds with known toxic substructures")
        summary_lines.append("   - Filters based on structural alerts")
        summary_lines.append("")
        summary_lines.append("9. REOS Filter:")
        summary_lines.append("   - Rapid Elimination of Swill")
        summary_lines.append("   - Removes reactive and problematic substructures")
        summary_lines.append("")

        # Pfizer Rule Impact Analysis
        if 'Lipinski (Rule of 5)' in filtering_results and 'Pfizer Rule' in filtering_results:
            lipinski_count = filtering_results['Lipinski (Rule of 5)']
            pfizer_count = filtering_results['Pfizer Rule']
            pfizer_removed = lipinski_count - pfizer_count
            pfizer_impact = (pfizer_removed / lipinski_count * 100) if lipinski_count > 0 else 0

            summary_lines.append("PFIZER RULE IMPACT ANALYSIS:")
            summary_lines.append("-" * 40)
            summary_lines.append(f"Compounds after Lipinski: {lipinski_count}")
            summary_lines.append(f"Compounds removed by Pfizer Rule: {pfizer_removed}")
            summary_lines.append(f"Pfizer Rule impact: {pfizer_impact:.1f}% of Lipinski-compliant compounds")
            summary_lines.append(f"Compounds after Pfizer Rule: {pfizer_count}")
            summary_lines.append("")

        # Analysis conclusions
        summary_lines.append("ANALYSIS CONCLUSIONS:")
        summary_lines.append("-" * 40)
        if len(final_df) > 0:
            success_rate = len(final_df)/self.original_count*100
            if success_rate > 20:
                summary_lines.append("✅ GOOD: High retention rate suggests quality input dataset")
            elif success_rate > 5:
                summary_lines.append("⚠️  MODERATE: Moderate retention rate, some optimization may be needed")
            else:
                summary_lines.append("❌ LOW: Low retention rate suggests input dataset needs improvement")

            summary_lines.append(f"Final dataset contains {len(final_df)} drug-like compounds")
            summary_lines.append("All compounds passed comprehensive drug-likeness filters including Pfizer Rule")
            summary_lines.append("Ready for further drug discovery applications")
        else:
            summary_lines.append("❌ CRITICAL: No compounds passed all filters")
            summary_lines.append("Consider relaxing filter criteria or improving input dataset quality")

        summary_lines.append("")
        summary_lines.append("=" * 80)
        summary_lines.append("END OF REPORT")
        summary_lines.append("=" * 80)

        # Join all lines
        summary_text = "\n".join(summary_lines)

        return summary_text

    def save_results(self, final_df, filtering_results):
        """Save CSV and summary text files"""
        print("\n💾 Saving results...")

        # Save filtered compounds to CSV
        csv_filename = "filtered_drug_like_compounds_with_pfizer.csv"
        final_df.to_csv(csv_filename, index=False)
        print(f"✅ Saved filtered compounds to: {csv_filename}")

        # Generate and save summary report
        summary_text = self.generate_summary_report(final_df, filtering_results)
        txt_filename = "drug_analysis_summary_with_pfizer.txt"
        with open(txt_filename, 'w') as f:
            f.write(summary_text)
        print(f"✅ Saved analysis summary to: {txt_filename}")

        # Download files in Colab
        try:
            files.download(csv_filename)
            files.download(txt_filename)
            print("📥 Files downloaded successfully!")
        except Exception as e:
            print(f"⚠️  Download error: {e}")
            print("Files are saved in the current directory")

        return csv_filename, txt_filename



# Original source: Part 2, generate_and_save_all_visualizations
def generate_and_save_all_visualizations(original_df_with_properties, final_df, filtering_results, original_count):
    # 1. Filtering cascade plot
    fig1 = plt.figure(figsize=(10, 6))
    steps = list(filtering_results.keys())
    counts = list(filtering_results.values())
    colors = plt.cm.viridis(np.linspace(0, 1, len(steps)))
    bars = plt.bar(range(len(steps)), counts, color=colors)
    plt.title('Sequential Filtering Results (Including Pfizer Rule)', fontsize=14, fontweight='bold')
    plt.xlabel('Filtering Step')
    plt.ylabel('Number of Compounds')
    plt.xticks(range(len(steps)), steps, rotation=45, ha='right')
    for bar, count in zip(bars, counts):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(counts)*0.01,
                str(count), ha='center', va='bottom', fontweight='bold')
    plt.tight_layout()
    save_and_download(fig1, 'panel_filtering_cascade_with_pfizer.png')

    # 2. Property distributions (before and after)
    properties = ['MW', 'LogP', 'HBD', 'HBA', 'TPSA', 'RotBonds']
    for prop in properties:
        # Check if the property column exists in both dataframes
        if prop in original_df_with_properties.columns and prop in final_df.columns:
            fig2 = plt.figure(figsize=(8, 6))
            # Use the dataframe with calculated properties for 'Original' data
            original_data = original_df_with_properties[prop].dropna()
            final_data = final_df[prop].dropna()
            if len(original_data) > 0:
                plt.hist(original_data, bins=30, alpha=0.5, label='Original', color='lightcoral', density=True)
            if len(final_data) > 0:
                plt.hist(final_data, bins=30, alpha=0.7, label='Filtered', color='steelblue', density=True)
            plt.title(f'{prop} Distribution', fontweight='bold')
            plt.xlabel(prop)
            plt.ylabel('Density')
            plt.legend()
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            save_and_download(fig2, f'panel_hist_{prop}_with_pfizer.png')
        else:
            print(f"Warning: Property '{prop}' not found in one or both dataframes. Skipping histogram.")

    # 3. Correlation heatmap
    fig3 = plt.figure(figsize=(8, 6))
    correlation_props = ['MW', 'LogP', 'HBD', 'HBA', 'TPSA', 'RotBonds', 'LogS']
    # Ensure properties exist in final_df before trying to correlate
    available_props = [prop for prop in correlation_props if prop in final_df.columns]

    if len(available_props) > 1 and len(final_df) > 1:
        # Calculate correlations only for available and numeric properties
        corr_matrix = final_df[available_props].corr(numeric_only=True)
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0,
                   square=True, fmt='.2f', cbar_kws={'shrink': 0.8})
        plt.title('Property Correlations (Filtered Data)', fontweight='bold')
        plt.tight_layout()
        save_and_download(fig3, 'panel_correlation_heatmap_with_pfizer.png')
    else:
         print("Warning: Not enough numeric columns in final_df to plot correlation heatmap.")

    # 4. Drug-likeness space plot
    fig4 = plt.figure(figsize=(8, 6))
    # Use the dataframe with calculated properties for 'Original' data
    # Check if MW and LogP exist before plotting
    if 'MW' in original_df_with_properties.columns and 'LogP' in original_df_with_properties.columns:
        original_mw = original_df_with_properties['MW'].dropna()
        original_logp = original_df_with_properties['LogP'].dropna()
        if len(original_mw) > 0 and len(original_logp) > 0:
            plt.scatter(original_mw, original_logp, alpha=0.5, s=20, color='lightcoral', label='Original')
    else:
        print("Warning: 'MW' or 'LogP' not found in original_df_with_properties. Skipping original scatter points.")

    if 'MW' in final_df.columns and 'LogP' in final_df.columns:
        final_mw = final_df['MW'].dropna()
        final_logp = final_df['LogP'].dropna()
        if len(final_mw) > 0 and len(final_logp) > 0:
            plt.scatter(final_mw, final_logp, alpha=0.8, s=30, color='steelblue', label='Filtered')
    else:
         print("Warning: 'MW' or 'LogP' not found in final_df. Skipping filtered scatter points.")

    # Add Lipinski boundaries
    plt.axvline(x=500, color='red', linestyle='--', alpha=0.7, label='MW=500')
    plt.axhline(y=5, color='red', linestyle='--', alpha=0.7, label='LogP=5')

    plt.xlabel('Molecular Weight')
    plt.ylabel('LogP')
    plt.title('Drug-likeness Space (MW vs LogP)', fontweight='bold')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    save_and_download(fig4, 'panel_druglikeness_space_with_pfizer.png')

    # 5. NEW: Pfizer Rule visualization
    fig5 = plt.figure(figsize=(8, 6))
    if 'LogP' in original_df_with_properties.columns and 'TPSA' in original_df_with_properties.columns:
        original_logp = original_df_with_properties['LogP'].dropna()
        original_tpsa = original_df_with_properties['TPSA'].dropna()
        if len(original_logp) > 0 and len(original_tpsa) > 0:
            plt.scatter(original_logp, original_tpsa, alpha=0.5, s=20, color='lightcoral', label='Original')

    if 'LogP' in final_df.columns and 'TPSA' in final_df.columns:
        final_logp_pfizer = final_df['LogP'].dropna()
        final_tpsa_pfizer = final_df['TPSA'].dropna()
        if len(final_logp_pfizer) > 0 and len(final_tpsa_pfizer) > 0:
            plt.scatter(final_logp_pfizer, final_tpsa_pfizer, alpha=0.8, s=30, color='steelblue', label='Filtered')

    # Add Pfizer Rule boundaries (toxic region)
    plt.axvline(x=3, color='red', linestyle='--', alpha=0.7, label='LogP=3')
    plt.axhline(y=75, color='red', linestyle='--', alpha=0.7, label='TPSA=75')

    # Highlight toxic region
    plt.fill([3, plt.xlim()[1], plt.xlim()[1], 3], [0, 0, 75, 75],
             color='red', alpha=0.1, label='Pfizer Toxic Zone')

    plt.xlabel('LogP')
    plt.ylabel('TPSA')
    plt.title('Pfizer Rule Space (LogP vs TPSA)', fontweight='bold')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    save_and_download(fig5, 'panel_pfizer_rule_space.png')

    # 6. Solubility vs Permeability
    fig6 = plt.figure(figsize=(8, 6))
    # Check if LogS and TPSA exist before plotting
    if 'LogS' in final_df.columns and 'TPSA' in final_df.columns:
        final_logs = final_df['LogS'].dropna()
        final_tpsa = final_df['TPSA'].dropna()
        if len(final_logs) > 0 and len(final_tpsa) > 0:
            plt.scatter(final_logs, final_tpsa, alpha=0.7, s=30, color='green')

        plt.axvline(x=-4, color='red', linestyle='--', alpha=0.7, label='LogS=-4')
        plt.axhline(y=140, color='red', linestyle='--', alpha=0.7, label='TPSA=140')

        plt.xlabel('LogS (Solubility)')
        plt.ylabel('TPSA (Permeability)')
        plt.title('Solubility vs Permeability', fontweight='bold')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        save_and_download(fig6, 'panel_solubility_vs_permeability_with_pfizer.png')
    else:
        print("Warning: 'LogS' or 'TPSA' not found in final_df. Skipping Solubility vs Permeability plot.")

    # 7. Pie Chart
    fig7 = plt.figure(figsize=(8, 6))
    passed = len(final_df)
    failed = original_count - passed
    plt.pie([passed, failed], labels=['Passed', 'Failed'],
           colors=['lightgreen', 'lightcoral'], autopct='%1.1f%%',
           startangle=90)
    plt.title('Overall Filtering Efficiency (With Pfizer Rule)', fontweight='bold')
    plt.tight_layout()
    save_and_download(fig7, 'panel_filtering_efficiency_pie_with_pfizer.png')

    # 8. NEW: Pfizer Rule impact visualization
    fig8 = plt.figure(figsize=(8, 6))
    if 'Lipinski (Rule of 5)' in filtering_results and 'Pfizer Rule' in filtering_results:
        lipinski_count = filtering_results['Lipinski (Rule of 5)']
        pfizer_count = filtering_results['Pfizer Rule']
        pfizer_removed = lipinski_count - pfizer_count

        categories = ['After Lipinski', 'Pfizer Removed', 'After Pfizer']
        values = [lipinski_count, pfizer_removed, pfizer_count]
        colors = ['lightgreen', 'red', 'darkgreen']

        bars = plt.bar(categories, values, color=colors, alpha=0.7)
        plt.title('Pfizer Rule Impact on Filtering', fontweight='bold')
        plt.ylabel('Number of Compounds')
        plt.xticks(rotation=45)

        # Add value labels
        for bar, value in zip(bars, values):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(values)*0.01,
                    str(value), ha='center', va='bottom', fontweight='bold')

        plt.tight_layout()
        save_and_download(fig8, 'panel_pfizer_rule_impact.png')

    print("🎉 All panels saved as PNGs (including Pfizer Rule visualizations).")



# Original source: Part 3, visualize_molecules
def visualize_molecules(molecules, labels, title, n_cols=3, mol_size=(300, 300),
                        figsize=(12, 8), highlight_atoms=None):
    """
    Visualize a list of molecules in a grid with labels

    Parameters:
        molecules (list): List of RDKit molecules
        labels (list): List of labels for each molecule
        title (str): Title for the visualization
        n_cols (int): Number of columns in the grid
        mol_size (tuple): Size of each molecule image
        figsize (tuple): Figure size
        highlight_atoms (list): List of atom indices to highlight for each molecule
    """
    if not molecules:
        print(f"No molecules to visualize for: {title}")
        return

    n_mols = len(molecules)
    n_rows = (n_mols + n_cols - 1) // n_cols

    # Create figure
    fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize)
    fig.suptitle(title, fontsize=18, fontweight='bold')

    # Ensure axes is always a 2D array
    if n_rows == 1 and n_cols == 1:
        axes = np.array([[axes]])
    elif n_rows == 1 or n_cols == 1:
        axes = axes.reshape(n_rows, n_cols)

    # Draw molecules
    for i in range(n_rows):
        for j in range(n_cols):
            idx = i * n_cols + j
            if idx < n_mols:
                mol = molecules[idx]
                label = labels[idx]

                # Convert mol to image and display
                img = Draw.MolToImage(mol, size=mol_size)
                axes[i, j].imshow(img)
                axes[i, j].set_title(label, fontsize=12)

            # Remove axis ticks
            axes[i, j].set_xticks([])
            axes[i, j].set_yticks([])

            # Hide empty subplots
            if idx >= n_mols:
                axes[i, j].axis('off')

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    return fig



# Original source: Part 3, create_filter_summary_plot
def create_part3_filter_summary_plot(filter_stages, counts, title="Compound Count After Each Filtering Step"):
    """Create a summary plot of filtering steps"""
    fig, ax = plt.subplots(figsize=(12, 7))

    # Create x positions for the plot (0, 1, 2, ...)
    x_positions = np.arange(len(filter_stages))

    # Plot the data
    ax.plot(x_positions, counts, 'bo-', markersize=10, linewidth=2)

    # Add data labels
    for i, (x, y) in enumerate(zip(x_positions, counts)):
        ax.annotate(f"{y}", (x, y), textcoords="offset points",
                   xytext=(0, 10), ha='center', fontsize=12, fontweight='bold')

    # Add percentage labels for reduction
    for i in range(1, len(counts)):
        reduction = counts[i-1] - counts[i]
        percent = (reduction / counts[i-1]) * 100
        midpoint_y = (counts[i-1] + counts[i]) / 2
        # Use x_positions for midpoint calculation instead of filter_stages
        midpoint_x = (x_positions[i-1] + x_positions[i]) / 2
        ax.annotate(f"-{reduction} ({percent:.1f}%)",
                   (midpoint_x, midpoint_y),
                   textcoords="offset points", xytext=(0, -20),
                   ha='center', fontsize=11, fontweight='bold', color='red')

    # Customize the plot
    ax.set_title(title, fontsize=18, fontweight='bold', pad=20)
    ax.set_xlabel('Filtering Step', fontsize=14, fontweight='bold')
    ax.set_ylabel('Number of Compounds', fontsize=14, fontweight='bold')
    ax.grid(True, linestyle='--', alpha=0.7)

    # Set the x-tick positions and labels
    ax.set_xticks(x_positions)
    ax.set_xticklabels(filter_stages, rotation=45, ha='right', fontsize=12, fontweight='bold')
    for tick in ax.get_yticklabels():
        tick.set_fontsize(12)
        tick.set_fontweight('bold')

    # Add a subtle background color
    ax.set_facecolor('#f8f9fa')

    # Add a box around the plot
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color('black')
        spine.set_linewidth(1)

    plt.tight_layout()
    return fig



# Original source: Part 4, create_undesirable_scaffolds
def create_undesirable_scaffolds():
    return {
        'quinone': '[#6]1=[#6][#6](=[O])[#6]=[#6][#6]1=[O]',
        'hydrazine': '[NX3][NX3]',
        'azo_compound': '[#6][N+]=[N+][#6]',
        'nitroso': '[NX2](=[OX1])[#6]',
        'hydroxylamine': '[NX3][OX2H]',
        'alkyl_halide_primary': '[CH2X4][Cl,Br,I]',
        'benzidine': 'c1ccc(cc1)c2ccc(cc2)N',
        'aromatic_nitro': 'c[N+](=O)[O-]',
        'phenol_substituted': 'c1ccc(c(c1)O)[Cl,Br,I,N+]',
        'aniline_substituted': 'c1ccc(c(c1)N)[Cl,Br,I,N+]'
    }



# Original source: Part 4, create_aggregators
def create_aggregators():
    return {
        'rhodanine': '[#16]1[#6](=[O])[#7][#6](=[O])[#6]1',
        'curcumin_like': '[OH]c1ccc(cc1)/C=C/C(=O)CC(=O)/C=C/c2ccc(cc2)[OH]',
        'flavonoid_agg': 'O1[#6]([#6]=[#6][#6]([OH])=[#6]1[OH])',
        'catechol': '[OH]c1c([OH])cccc1',
        'gallic_acid': '[OH]c1cc(cc(c1[OH])[OH])',
        'quinone_aggregator': '[#6]1=[#6][#6](=[O])[#6]=[#6][#6]1=[O]',
        'tannin_like': 'c1(O)c(O)c(O)c(O)c(O)c1O',
        'polyphenol': '[OH]c1ccc(cc1)c2cc(O)c(O)c(O)c2',
        'luteolin_like': 'O=C1C=C(Oc2cc(O)cc(O)c12)c3ccc(O)c(O)c3',
        'metal_binding': '[OH]c1c([OH])c([OH])c([OH])c([OH])c1[OH]'
    }



# Original source: Part 4, create_toxicophores
def create_toxicophores():
    return {
        'aromatic_amine': 'c[NX3H2]',
        'nitroaromatic': 'c[N+](=O)[O-]',
        'aromatic_halogen': 'c[Cl,Br,I]',
        'polycyclic_aromatic': 'c1ccc2c(c1)ccc3c2cccc3',
        'benzidine_deriv': '[NH2]c1ccc(cc1)c2ccc([NH2])cc2',
        'aldehyde_aromatic': 'c[CHO]',
        'epoxide_aromatic': 'c1ccc2c(c1)C3OC3C2',
        'quinone_imine': '[NH]=C1C=CC(=O)C=C1',
        'alpha_beta_unsaturated': '[CX3]=[CX3][CX3](=[OX1])',
        'aromatic_azo': 'c[N+]=[N+]c',
        'thiophene_oxidized': 's1cccc1(=O)',
        'furan_substituted': 'o1cccc1[Cl,Br,I,N+]'
    }



# Original source: Part 4, create_reactive_groups
def create_reactive_groups():
    return {
        'michael_acceptor': '[CX3]=[CX3][CX3](=[OX1])[#6]',
        'alpha_halo_carbonyl': '[F,Cl,Br,I][CX4][CX3](=[OX1])',
        'acyl_chloride': '[CX3](=[OX1])[Cl]',
        'alkyl_iodide': '[CH2,CH3][I]',
        'alkyl_bromide_sec': '[CH][Br][CH3,CH2]',
        'sulfonyl_chloride': '[SX4](=[OX1])(=[OX1])[Cl]',
        'acid_chloride': '[CX3](=[OX1])[Cl]',
        'anhydride': '[CX3](=[OX1])[OX2][CX3](=[OX1])',
        'activated_ester': '[CX3](=[OX1])[OX2][CX4][Cl,Br,I,F]',
        'maleimide': '[CX3](=[OX1])[NX3][CX3](=[OX1])',
        'vinyl_ketone': '[CX3]=[CX3][CX3](=[OX1])',
        'halopyrimidine': 'n1c([Cl,Br,I])nc([Cl,Br,I])nc1'
    }



# Original source: Part 4, create_filtering_cascade_plot
def create_filtering_cascade_plot(all_stats, output_dir):
    steps = []
    compounds_remaining = []
    compounds_removed = []
    step_names = []

    total_start = all_stats[0]['total_input']
    steps.append(0)
    compounds_remaining.append(total_start)
    compounds_removed.append(0)
    step_names.append('Initial\nDataset')

    remaining = total_start
    for i, stats in enumerate(all_stats):
        step_names.append(f"{stats['filter_name']}\nFilter")
        steps.append(i + 1)
        removed = stats['failed_filter']
        remaining = stats['passed_filter']
        compounds_remaining.append(remaining)
        compounds_removed.append(removed)

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 12))

    colors_remaining = plt.cm.Blues(np.linspace(0.4, 0.8, len(steps)))
    bars1 = ax1.bar(step_names, compounds_remaining, color=colors_remaining,
                    edgecolor='black', linewidth=1.5, alpha=0.8)

    ax1.set_ylabel('Compounds Remaining', fontsize=14, fontweight='bold')
    ax1.set_title('Compound Filtering Cascade - Sequential Removal',
                  fontsize=16, fontweight='bold', pad=20)
    ax1.grid(axis='y', alpha=0.3)

    for bar, value in zip(bars1, compounds_remaining):
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width() / 2., height + total_start * 0.01,
                 f'{int(value):,}', ha='center', va='bottom', fontweight='bold')

    colors_removed = plt.cm.Reds(np.linspace(0.4, 0.8, len(steps)))
    bars2 = ax2.bar(step_names[1:], compounds_removed[1:], color=colors_removed[1:],
                    edgecolor='black', linewidth=1.5, alpha=0.8)

    ax2.set_ylabel('Compounds Removed', fontsize=14, fontweight='bold')
    ax2.set_xlabel('Filtering Steps', fontsize=14, fontweight='bold')
    ax2.grid(axis='y', alpha=0.3)

    for bar, value in zip(bars2, compounds_removed[1:]):
        if value > 0:
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width() / 2., height + max(compounds_removed) * 0.01,
                     f'{int(value):,}', ha='center', va='bottom', fontweight='bold')

    for ax in [ax1, ax2]:
        ax.tick_params(axis='x', rotation=45, labelsize=11)

    plt.tight_layout()
    plt.savefig(output_dir / 'filtering_cascade.png', dpi=300, bbox_inches='tight')
    plt.show()

    return fig



# Original source: Part 4, create_filter_summary_plot
def create_filter_summary_plot(all_stats, output_dir):
    filter_names = [stats['filter_name'] for stats in all_stats]
    removal_rates = [stats['filter_rate'] for stats in all_stats]
    compounds_removed = [stats['failed_filter'] for stats in all_stats]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))

    colors = plt.cm.Set3(np.linspace(0, 1, len(filter_names)))
    bars1 = ax1.barh(filter_names, removal_rates, color=colors,
                     edgecolor='black', linewidth=1.5, alpha=0.8)

    ax1.set_xlabel('Removal Rate (%)', fontsize=14, fontweight='bold')
    ax1.set_title('Filter Effectiveness\n(% of Compounds Removed)',
                  fontsize=14, fontweight='bold')
    ax1.grid(axis='x', alpha=0.3)

    for bar, value in zip(bars1, removal_rates):
        width = bar.get_width()
        ax1.text(width + 0.5, bar.get_y() + bar.get_height() / 2.,
                 f'{value:.1f}%', ha='left', va='center', fontweight='bold')

    bars2 = ax2.barh(filter_names, compounds_removed, color=colors,
                     edgecolor='black', linewidth=1.5, alpha=0.8)

    ax2.set_xlabel('Number of Compounds Removed', fontsize=14, fontweight='bold')
    ax2.set_title('Filter Impact\n(Absolute Numbers)',
                  fontsize=14, fontweight='bold')
    ax2.grid(axis='x', alpha=0.3)

    for bar, value in zip(bars2, compounds_removed):
        width = bar.get_width()
        ax2.text(width + max(compounds_removed) * 0.01, bar.get_y() + bar.get_height() / 2.,
                 f'{int(value):,}', ha='left', va='center', fontweight='bold')

    plt.tight_layout()
    plt.savefig(output_dir / 'filter_summary.png', dpi=300, bbox_inches='tight')
    plt.show()

    return fig



# Original source: Part 4, create_pattern_analysis_plot
def create_pattern_analysis_plot(all_matches, output_dir):
    if not all_matches:
        print("No pattern matches to analyze")
        return None

    combined_matches = pd.concat(all_matches, ignore_index=True)

    pattern_counts = combined_matches.groupby(['filter_type', 'pattern_name']).size().reset_index(name='count')

    filter_types = pattern_counts['filter_type'].unique()
    n_filters = len(filter_types)

    fig, axes = plt.subplots(n_filters, 1, figsize=(14, 6 * n_filters))
    if n_filters == 1:
        axes = [axes]

    for i, filter_type in enumerate(filter_types):
        filter_data = pattern_counts[pattern_counts['filter_type'] == filter_type]
        filter_data = filter_data.sort_values('count', ascending=True)

        colors = plt.cm.Set2(np.linspace(0, 1, len(filter_data)))
        bars = axes[i].barh(filter_data['pattern_name'], filter_data['count'],
                           color=colors, edgecolor='black', linewidth=1, alpha=0.8)

        axes[i].set_xlabel('Number of Matches', fontsize=12, fontweight='bold')
        axes[i].set_title(f'{filter_type} - Pattern Match Frequency',
                         fontsize=14, fontweight='bold')
        axes[i].grid(axis='x', alpha=0.3)

        for bar, value in zip(bars, filter_data['count']):
            width = bar.get_width()
            axes[i].text(width + max(filter_data['count']) * 0.01,
                        bar.get_y() + bar.get_height() / 2.,
                        f'{int(value)}', ha='left', va='center', fontweight='bold')

    plt.tight_layout()
    plt.savefig(output_dir / 'pattern_analysis.png', dpi=300, bbox_inches='tight')
    plt.show()

    return fig



# Original source: Part 4, create_final_summary_plot
def create_final_summary_plot(initial_count, final_count, all_stats, output_dir):
    total_removed = initial_count - final_count
    retention_rate = (final_count / initial_count) * 100

    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))

    sizes = [final_count, total_removed]
    labels = [f'Passed All Filters\n({final_count:,} compounds)',
              f'Failed At Least One Filter\n({total_removed:,} compounds)']
    colors = ['#2E8B57', '#DC143C']
    explode = (0.05, 0)

    wedges, texts, autotexts = ax1.pie(sizes, labels=labels, autopct='%1.1f%%',
                                      colors=colors, explode=explode, shadow=True,
                                      textprops={'fontsize': 11, 'fontweight': 'bold'})
    ax1.set_title('Overall Filtering Results', fontsize=14, fontweight='bold')

    steps = ['Initial'] + [stats['filter_name'] for stats in all_stats]
    cumulative_remaining = [initial_count]

    remaining = initial_count
    for stats in all_stats:
        remaining = stats['passed_filter']
        cumulative_remaining.append(remaining)

    ax2.plot(steps, cumulative_remaining, marker='o', linewidth=3,
             markersize=8, color='#1f77b4', markerfacecolor='white',
             markeredgewidth=2, markeredgecolor='#1f77b4')
    ax2.fill_between(steps, cumulative_remaining, alpha=0.3, color='#1f77b4')
    ax2.set_ylabel('Compounds Remaining', fontsize=12, fontweight='bold')
    ax2.set_title('Cumulative Filtering Effect', fontsize=14, fontweight='bold')
    ax2.tick_params(axis='x', rotation=45)
    ax2.grid(True, alpha=0.3)

    filter_names = [stats['filter_name'] for stats in all_stats]
    removal_rates = [stats['filter_rate'] for stats in all_stats]

    colors_bar = plt.cm.plasma(np.linspace(0.2, 0.8, len(filter_names)))
    bars = ax3.bar(filter_names, removal_rates, color=colors_bar,
                   edgecolor='black', linewidth=1.5, alpha=0.8)
    ax3.set_ylabel('Removal Rate (%)', fontsize=12, fontweight='bold')
    ax3.set_title('Individual Filter Stringency', fontsize=14, fontweight='bold')
    ax3.tick_params(axis='x', rotation=45)
    ax3.grid(axis='y', alpha=0.3)

    for bar, value in zip(bars, removal_rates):
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width() / 2., height + max(removal_rates) * 0.01,
                 f'{value:.1f}%', ha='center', va='bottom', fontweight='bold', fontsize=10)

    ax4.axis('tight')
    ax4.axis('off')

    summary_data = [
        ['Initial Compounds', f'{initial_count:,}'],
        ['Final Compounds', f'{final_count:,}'],
        ['Total Removed', f'{total_removed:,}'],
        ['Retention Rate', f'{retention_rate:.1f}%'],
        ['Removal Rate', f'{100 - retention_rate:.1f}%']
    ]

    for stats in all_stats:
        summary_data.append([f"{stats['filter_name']} Removed", f"{stats['failed_filter']:,}"])

    table = ax4.table(cellText=summary_data,
                     colLabels=['Metric', 'Value'],
                     cellLoc='center',
                     loc='center',
                     colWidths=[0.6, 0.4])
    table.auto_set_font_size(False)
    table.set_fontsize(11)
    table.scale(1, 2)

    for i in range(len(summary_data) + 1):
        for j in range(2):
            cell = table[(i, j)]
            if i == 0:
                cell.set_facecolor('#4472C4')
                cell.set_text_props(weight='bold', color='white')
            else:
                cell.set_facecolor('#F2F2F2' if i % 2 == 0 else 'white')
                cell.set_text_props(weight='bold' if j == 0 else 'normal')

    ax4.set_title('Summary Statistics', fontsize=14, fontweight='bold')

    plt.tight_layout()
    plt.savefig(output_dir / 'final_summary.png', dpi=300, bbox_inches='tight')
    plt.show()

    return fig


PLOT_OUTPUT_DIR = None

def save_and_download(fig, filename, dpi=300):
    if PLOT_OUTPUT_DIR is None:
        raise RuntimeError('Set legacy_core.PLOT_OUTPUT_DIR before calling original Part-2 figure function')
    dest=Path(PLOT_OUTPUT_DIR)/filename
    dest.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(dest, dpi=600, bbox_inches='tight')
    plt.close(fig)

# ================== INTEGRATED FOUR-PART SCIENTIFIC ENGINE ==================
"""Four-stage compound-filtering computational engine.
User-supplied algorithms retained where practical by importing verbatim legacy_core classes.
Adaptations: selectable steps, desktop I/O, correct column handoff, output audit, guardrails.
"""
import json, os, sys, time, shutil, zipfile, traceback, hashlib
from collections import OrderedDict
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, Crippen, Lipinski
from rdkit.Chem.FilterCatalog import FilterCatalog, FilterCatalogParams
from rdkit.Chem import Draw
old = sys.modules[__name__]  # original notebook algorithms live in this same notebook namespace

PARTS = OrderedDict([
    (1, ('Preprocessing & Ionization', [
        ('parsing','SMILES parsing'), ('fragment_filter','Single-fragment filter'),
        ('salt_removal','Salt removal'), ('metal_removal','Metal removal'),
        ('normalization','RDKit normalization & canonicalization'),
        ('ionization','Ionization at pH 7.4'), ('duplicate_removal','Duplicate removal')
    ])),
    (2, ('Property-based Filtering', [
        ('lipinski','Lipinski'), ('pfizer','Pfizer Rule'), ('veber','Veber'),
        ('ghose','Ghose'), ('egan','Egan'), ('muegge','Muegge'),
        ('solubility','ESOL solubility'), ('toxicity','Heuristic structural alerts'),
        ('reos','Original REOS-like SMARTS')
    ])),
    (3, ('Brenk, NIH & PAINS', [('brenk','Brenk alerts'),('nih','NIH alerts'),('pains','PAINS alerts')])),
    (4, ('Substructure Screening', [
        ('unwanted','Bundled unwanted substructures'), ('scaffolds','Undesirable scaffolds'),
        ('aggregators','Aggregator-like structures'), ('toxicophores','Toxicophore alerts'),
        ('reactive','Reactive functional groups')
    ]))
])
FOLDER_NAMES={1:'01_Preprocessing',2:'02_Property_Filtering',3:'03_Brenk_NIH_PAINS',4:'04_Substructure_Screening'}
COLOR='#295d9d'

FILTER_CRITERIA = {
    1: {
        'parsing': 'Mandatory: retain non-empty SMILES that RDKit parses successfully.',
        'fragment_filter': 'Retain single-fragment SMILES only; dot-separated multi-fragment records are excluded.',
        'salt_removal': 'Apply RDKit SaltRemover.StripMol; exclude if stripping fails or leaves no atoms.',
        'metal_removal': 'Exclude molecules containing any metal atom in the original Part-1 metal list.',
        'normalization': 'Apply RDKit normalization and canonical tautomer selection; retain canonical SMILES for audit.',
        'ionization': 'Apply the original Dimorphite-DL-based ionization logic at the selected pH (default 7.4), with original validation/fallback steps.',
        'duplicate_removal': 'Group by Part-1 final_smiles and retain the first record in each duplicate group.'
    },
    2: {
        'lipinski': 'Lipinski: MW ≤ 500; LogP ≤ 5; HBD ≤ 5; HBA ≤ 10.',
        'pfizer': 'Pfizer: exclude compounds for which LogP > 3 AND TPSA < 75.',
        'veber': 'Veber: TPSA ≤ 140 Å² and rotatable bonds ≤ 10.',
        'ghose': 'Ghose: 160 ≤ MW ≤ 480; -0.4 ≤ LogP ≤ 5.6; heavy atoms ≤ 50.',
        'egan': 'Egan: TPSA ≤ 131.6 Å² and -1 ≤ LogP ≤ 6.',
        'muegge': 'Muegge: 200 ≤ MW ≤ 600; -2 ≤ LogP ≤ 5; TPSA ≤ 150; rings ≤ 7; HBD ≤ 5; HBA ≤ 10; rotatable bonds ≤ 15.',
        'solubility': 'ESOL-based solubility: retain compounds with calculated LogS > -4.',
        'toxicity': 'Original heuristic toxicity score: eight structural alerts plus MW > 800, LogP > 6 and TPSA > 200; retain score < 2.',
        'reos': 'Original REOS-like SMARTS screen: exclude if any listed pattern matches.'
    },
    3: {
        'brenk': 'RDKit Brenk FilterCatalog: exclude compounds with a Brenk match and record the matched description.',
        'nih': 'RDKit NIH FilterCatalog: exclude compounds with an NIH match and record the matched description.',
        'pains': 'RDKit PAINS FilterCatalog: exclude compounds with a PAINS match and record the matched description.'
    },
    4: {
        'unwanted': 'Screen against the bundled 104-row unwanted-substructure SMARTS library; exclude on the first valid match.',
        'scaffolds': 'Screen against the original undesirable-scaffold SMARTS collection; exclude on match.',
        'aggregators': 'Screen against the original aggregator-associated SMARTS collection; exclude on match.',
        'toxicophores': 'Screen against the original toxicophore SMARTS collection; exclude on match.',
        'reactive': 'Screen against the original reactive-functional-group SMARTS collection; exclude on match.'
    }
}
PART_NOTES = {
    1: 'The original Part-1 order is preserved; notably, the single-fragment filter precedes salt stripping.',
    2: 'Descriptors are calculated before sequential property filtering; rows lacking MW, LogP, HBD or HBA are removed first.',
    3: 'Selected catalog filters are sequential; only survivors advance to the next catalog.',
    4: 'Selected SMARTS groups are sequential; the first detected matching pattern is recorded for excluded compounds.'
}

@dataclass
class RunConfig:
    enabled: dict = field(default_factory=lambda: {str(p): {k: True for k,_ in rows} for p,(_,rows) in PARTS.items()})
    ph: float=7.4
    output_base: str=''
    source_file: str=''
    run_name: str=''
    original_plots: bool=True
    figure_formats: tuple=('png','svg','tiff')
    def selected(self, part, key): return bool(self.enabled.get(str(part),{}).get(key,False))


def get_resources_dir():
    # Generated privately from the dataset included inside this single notebook.
    # No external CSV, project directory, or manually uploaded reference file needed.
    root = Path(tempfile.gettempdir()) / 'compound_filtering_studio_embedded_reference_v1_1'
    root.mkdir(parents=True, exist_ok=True)
    target = root / 'Two_separeted_unwanted_substructures_cleaned.csv'
    expected = hashlib.sha256(STUDIO_SMARTS_CSV.encode('utf-8')).hexdigest()
    if not target.is_file() or file_sha256(target) != expected:
        target.write_text(STUDIO_SMARTS_CSV, encoding='utf-8')
    return root

def curated_csv_path(): return get_resources_dir()/'Two_separeted_unwanted_substructures_cleaned.csv'


def clean_import(df):
    if len(df)==0: raise ValueError('Input CSV contains no compounds.')
    df=df.copy()
    cols=list(df.columns)
    lowered={str(c).strip().lower():c for c in cols}
    smiles_alias=('smiles','original_smiles','input_smiles','smi','isomeric_smiles','canonical_smiles','canonical smiles','final_smiles')
    name_alias=('compound_name','compound name','name','molecule_name','id','compound_id','title')
    smiles=next((lowered[x] for x in smiles_alias if x in lowered),None)
    name=next((lowered[x] for x in name_alias if x in lowered),None)
    if smiles is None: raise ValueError(f'Cannot find a SMILES column. Available: {cols}')
    # Preserve the exact source-column string for compound tracing; only trim the analysis copy.
    if 'original_input_smiles' not in df.columns:
        df['original_input_smiles']=df[smiles].astype('string').fillna('')
    df['smiles']=df[smiles].astype('string').fillna('').str.strip()
    if name is None:
        df['compound_name']=['Compound_'+str(i+1) for i in range(len(df))]
        generated=True
    else:
        df['compound_name']=df[name].astype('string').fillna('')
        generated=False
    if 'source_row_id' not in df.columns: df.insert(0,'source_row_id',range(1,len(df)+1))
    elif df['source_row_id'].isna().any() or df['source_row_id'].duplicated().any():
        df['original_source_row_id']=df['source_row_id']
        df['source_row_id']=range(1,len(df)+1)
    return df,{'smiles_column':str(smiles),'name_column':str(name) if name else None,'names_generated':generated}


def export_df(df,path):
    df=df.copy()
    for col in ('mol_object','ROMol','rdkit_molecule','_studio_mol_original'):
        if col in df.columns: df=df.drop(columns=col)
    if 'ionization_properties' in df.columns:
        df['ionization_properties']=df['ionization_properties'].map(lambda x: json.dumps(x,default=str) if isinstance(x,dict) else str(x))
    df.to_csv(path,index=False)


def report_progress(callback,part,step,detail,percent=None):
    if callback: callback(part,step,detail,percent)


def _step_record(rows,key,before,after, enabled=True, note=''):
    if after>before: raise RuntimeError(f'Filter {key} increased compound count unexpectedly: {before} -> {after}')
    rows.append({'filter':key,'applied':enabled,'before':int(before),'removed':int(before-after),'remaining':int(after),'note':note})


def part_one(df,settings,folder,progress):
    filt=old.SequentialMolecularFilter(batch_size=1000)
    filt.filtering_stats['initial']['passed']=len(df)
    stats=[]; current=df.copy(); current['input_smiles']=current['smiles'].copy()
    # Identity invariant: downstream filtering must use original input SMILES, not final_smiles.
    original_count=len(current)
    stages=[
      ('parsing',lambda x: filt.parse_smiles_filter(x,'smiles')),
      ('fragment_filter',lambda x: filt.fragment_filter(x,'smiles')),
      ('salt_removal',lambda x: filt.salt_removal_filter(x)),
      ('metal_removal',lambda x: filt.metal_removal_filter(x)),
      ('normalization',lambda x: filt.normalization_filter(x)),
      ('ionization',lambda x: filt.enhanced_ionization_filter(x,ph=settings.ph)),
      ('duplicate_removal',lambda x: filt.duplicate_removal_filter(x))
    ]
    rejected={}
    for j,(key,func) in enumerate(stages,1):
        enabled=settings.selected(1,key)
        if key=='parsing' and not enabled:
            raise ValueError('SMILES parsing is mandatory for subsequent molecular filters; enable it.')
        before=len(current)
        report_progress(progress,1,key,f'{key}: {before:,} compounds',int((j-1)/len(stages)*85))
        if not enabled:
            _step_record(stats,key,before,before,False)
            continue
        if not before:
            _step_record(stats,key,0,0,True,'No input compounds remain')
            continue
        if key=='ionization':
            if old.dimorphite_dl is None:
                raise RuntimeError('Ionization is selected but dimorphite_dl is unavailable. Run Notebook setup, or deselect the ionization option and document it.')
            # The original code calls dimorphite_dl.protonate(min_ph=...,max_ph=...).
            # Supported releases may instead expose protonate.run(ph_min=...,ph_max=...).
            # Adapt the PUBLIC call signature while leaving the user's ionization decision rules unchanged.
            target=getattr(old.dimorphite_dl,'protonate',None)
            if not callable(target):
                adapter=target.run if target is not None and callable(getattr(target,'run',None)) else None
                if adapter is None:
                    try:
                        from dimorphite_dl.protonate import run as adapter
                    except (ImportError, AttributeError):
                        adapter=None
                if adapter is None:
                    raise RuntimeError('Installed dimorphite_dl has no supported protonation API. Verify the installed version before enabling ionization.')
                class _Compatible:
                    @staticmethod
                    def protonate(smiles,min_ph,max_ph,max_variants=3,pka_precision=1.0):
                        result=adapter(smiles=smiles,ph_min=min_ph,ph_max=max_ph,max_variants=max_variants,precision=pka_precision)
                        if isinstance(result,str): return [result]
                        if isinstance(result,(list,tuple)): return [str(x) for x in result if x is not None]
                        return []
                old.dimorphite_dl=_Compatible
        if key=='normalization' and 'canonical_smiles' not in current.columns:
            pass
        if key=='ionization' and 'canonical_smiles' not in current.columns:
            current['canonical_smiles']=[Chem.MolToSmiles(m,canonical=True) for m in current['mol_object']]
        if key=='duplicate_removal' and 'final_smiles' not in current.columns:
            current['final_smiles']=current.apply(lambda r: r.get('ionized_smiles') if pd.notna(r.get('ionized_smiles')) else r.get('canonical_smiles',r['smiles']),axis=1)
        result=func(current)
        if key=='duplicate_removal':
            current,rej,groups=result
        else: current,rej=result
        _step_record(stats,key,before,len(current))
        rejected[key]=rej
        if not rej.empty:
            export_df(rej,folder/f'rejected_{key}.csv')
        report_progress(progress,1,key,f'{key}: {len(current):,} retained',int(j/len(stages)*85))
    if len(current):
        if 'final_smiles' not in current.columns:
            current['final_smiles']=current.apply(lambda r: r.get('ionized_smiles') if pd.notna(r.get('ionized_smiles')) else r.get('canonical_smiles',r['smiles']),axis=1)
        # USER-SPECIFIED HANDOFF POLICY: retain the original SMILES throughout Parts 2–4.
        # Part-1 may still create canonical_smiles, ionized_smiles and final_smiles as
        # *additional audit columns*, and may use them for its original duplicate logic.
        # They MUST NOT replace the downstream 'smiles' column.
        current['smiles']=current['input_smiles'].astype('string').fillna('').str.strip()
        if not current['smiles'].eq(current['input_smiles'].astype('string').fillna('').str.strip()).all():
            raise AssertionError('Original-SMILES identity check failed after Part 1.')
    return current,stats,filt


def _progress_interval(total, target_updates=120):
    total=max(1,int(total))
    return max(25, total//max(1,int(target_updates)))


def _live_detail(label, done, total, started):
    elapsed=max(1e-9,time.perf_counter()-started)
    rate=float(done)/elapsed if done else 0.0
    pct=(100.0*done/total) if total else 100.0
    return f'{label} • {done:,}/{total:,} screened • {pct:5.1f}% • {rate:,.0f} cmp/s'


def _ensure_original_mol_cache(df, part, progress, start_pct=0, end_pct=15, label_text='Preparing molecules'):
    """Attach a temporary RDKit Mol cache generated from ORIGINAL downstream SMILES.

    The cache accelerates repeated descriptor/catalog/SMARTS checks only. It does not
    change the original-SMILES handoff policy or any filter threshold.
    """
    if '_studio_mol_original' in df.columns and len(df):
        return df
    current=df.copy()
    total=len(current)
    if not total:
        current['_studio_mol_original']=[]
        return current
    start=time.perf_counter(); interval=_progress_interval(total)
    mols=[]
    for i,smi in enumerate(current['smiles'].astype('string').fillna('').tolist(),1):
        try: mol=Chem.MolFromSmiles(str(smi))
        except Exception: mol=None
        mols.append(mol)
        if i==1 or i==total or i%interval==0:
            pct=start_pct+(end_pct-start_pct)*(i/total)
            report_progress(progress,part,'molecule_cache',_live_detail(label_text,i,total,start),pct)
    current['_studio_mol_original']=mols
    return current


_TOXIC_QUERY_CACHE=None
_REOS_QUERY_CACHE=None
_PATTERN_GROUP_CACHE=None


def _compiled_toxic_queries():
    global _TOXIC_QUERY_CACHE
    if _TOXIC_QUERY_CACHE is None:
        patterns=['[N+](=O)[O-]','[CH]=O','C1OC1','c[NH2]','N-N','[SH]','C=C-C=O','[Cl,Br,I][CH2]']
        _TOXIC_QUERY_CACHE=[Chem.MolFromSmarts(x) for x in patterns]
    return _TOXIC_QUERY_CACHE


def _compiled_reos_queries():
    global _REOS_QUERY_CACHE
    if _REOS_QUERY_CACHE is None:
        patterns=['[#7][#7]','[#6]=[#7][#7]','[#16]=[#16]','[#7]=[#7]','[#6]#[#7]','[#7][#16]','[#16]=[#8]','[#15]','[#9,#17,#35,#53]','[#33,#51,#83]']
        _REOS_QUERY_CACHE=[Chem.MolFromSmarts(x) for x in patterns]
    return _REOS_QUERY_CACHE


def _fast_toxicity_filter(df,progress,part_pct_start,part_pct_end):
    """Equivalent implementation of the supplied toxicity-score rule using cached molecules."""
    if not len(df): return df.copy()
    queries=[q for q in _compiled_toxic_queries() if q is not None]
    total=len(df); start=time.perf_counter(); interval=_progress_interval(total)
    scores=[]
    mols=df['_studio_mol_original'].tolist()
    mws=pd.to_numeric(df['MW'],errors='coerce').to_numpy()
    logps=pd.to_numeric(df['LogP'],errors='coerce').to_numpy()
    tpsa=pd.to_numeric(df['TPSA'],errors='coerce').to_numpy()
    for i,mol in enumerate(mols,1):
        score=0
        if mol is None:
            score=10
        else:
            for q in queries:
                try:
                    if mol.HasSubstructMatch(q): score+=1
                except Exception:
                    pass
            j=i-1
            if np.isfinite(mws[j]) and mws[j]>800: score+=1
            if np.isfinite(logps[j]) and logps[j]>6: score+=1
            if np.isfinite(tpsa[j]) and tpsa[j]>200: score+=1
        scores.append(score)
        if i==1 or i==total or i%interval==0:
            pct=part_pct_start+(part_pct_end-part_pct_start)*(i/total)
            report_progress(progress,2,'toxicity_scan',_live_detail('Toxicity alerts',i,total,start),pct)
    out=df.copy();out['Toxicity_Score']=scores
    return out.loc[out['Toxicity_Score']<2].copy()


def _fast_reos_filter(df,progress,part_pct_start,part_pct_end):
    """Equivalent implementation of the supplied REOS-like SMARTS rule using cached molecules."""
    if not len(df): return df.copy()
    queries=[q for q in _compiled_reos_queries() if q is not None]
    total=len(df); start=time.perf_counter(); interval=_progress_interval(total)
    keep=[]
    for i,mol in enumerate(df['_studio_mol_original'].tolist(),1):
        ok=mol is not None
        if ok:
            for q in queries:
                try:
                    if mol.HasSubstructMatch(q):
                        ok=False;break
                except Exception:
                    continue
        keep.append(ok)
        if i==1 or i==total or i%interval==0:
            pct=part_pct_start+(part_pct_end-part_pct_start)*(i/total)
            report_progress(progress,2,'reos_scan',_live_detail('REOS-like alerts',i,total,start),pct)
    return df.loc[keep].copy()


def _compiled_pattern_groups():
    """Compile Part-4 SMARTS once per application process while preserving source order."""
    global _PATTERN_GROUP_CACHE
    if _PATTERN_GROUP_CACHE is not None:
        return _PATTERN_GROUP_CACHE
    compiled_groups={}
    for key,items in load_pattern_groups().items():
        compiled=[];failures=[]
        for idx,(name,smarts) in enumerate(items):
            try:q=Chem.MolFromSmarts(smarts)
            except Exception:q=None
            if q is None:failures.append({'pattern_row':idx+1,'name':name,'smarts':smarts})
            else:compiled.append((idx,name,smarts,q))
        compiled_groups[key]=(items,compiled,failures)
    _PATTERN_GROUP_CACHE=compiled_groups
    return _PATTERN_GROUP_CACHE

def part_two(df,settings,folder,progress):
    if len(df)==0:return df.copy(),[],None
    analyzer=old.DrugAnalyzerSequential(df)
    analyzer.df=_ensure_original_mol_cache(analyzer.df,2,progress,0,13,'Parsing original SMILES')

    # Descriptor definitions are identical to the supplied Part-2 notebook.
    total=len(analyzer.df);start=time.perf_counter();interval=_progress_interval(total)
    properties=[];mols=analyzer.df['_studio_mol_original'].tolist()
    report_progress(progress,2,'descriptors',f'Calculating descriptors for {total:,} compounds',13)
    for i,mol in enumerate(mols,1):
        if mol is None:
            prop={key:np.nan for key in ['MW','LogP','HBD','HBA','TPSA','RotBonds','Rings','HeavyAtoms','LogS']}
        else:
            try:
                mw=Descriptors.MolWt(mol);logp=Crippen.MolLogP(mol)
                hbd=Lipinski.NumHDonors(mol);hba=Lipinski.NumHAcceptors(mol)
                tpsa=Descriptors.TPSA(mol);rot=Descriptors.NumRotatableBonds(mol)
                rings=rdMolDescriptors.CalcNumRings(mol);heavy=mol.GetNumHeavyAtoms();aromatic=rdMolDescriptors.CalcNumAromaticRings(mol)
                logs=0.16-0.63*logp-0.0062*mw+0.066*rot-0.74*aromatic
                prop={'MW':mw,'LogP':logp,'HBD':hbd,'HBA':hba,'TPSA':tpsa,'RotBonds':rot,'Rings':rings,'HeavyAtoms':heavy,'LogS':logs}
            except Exception:
                prop={key:np.nan for key in ['MW','LogP','HBD','HBA','TPSA','RotBonds','Rings','HeavyAtoms','LogS']}
        properties.append(prop)
        if i==1 or i==total or i%interval==0:
            report_progress(progress,2,'descriptors',_live_detail('Molecular descriptors',i,total,start),13+17*(i/total))
    for key in properties[0]:analyzer.df[key]=[p[key] for p in properties]

    current=analyzer.df.dropna(subset=['MW','LogP','HBD','HBA']).copy();rows=[]
    _step_record(rows,'descriptor_validity',len(df),len(current),True,'Missing core descriptors excluded')
    config=[
        ('lipinski',lambda d:analyzer.apply_rule_filter(d,'Lipinski (Rule of 5)',[d['MW']<=500,d['LogP']<=5,d['HBD']<=5,d['HBA']<=10])),
        ('pfizer',lambda d:analyzer.apply_pfizer_rule_filter(d)),
        ('veber',lambda d:analyzer.apply_rule_filter(d,'Veber',[d['TPSA']<=140,d['RotBonds']<=10])),
        ('ghose',lambda d:analyzer.apply_rule_filter(d,'Ghose',[(d['MW']>=160)&(d['MW']<=480),(d['LogP']>=-.4)&(d['LogP']<=5.6),d['HeavyAtoms']<=50])),
        ('egan',lambda d:analyzer.apply_rule_filter(d,'Egan',[d['TPSA']<=131.6,(d['LogP']>=-1)&(d['LogP']<=6)])),
        ('muegge',lambda d:analyzer.apply_rule_filter(d,'Muegge',[(d['MW']>=200)&(d['MW']<=600),(d['LogP']>=-2)&(d['LogP']<=5),d['TPSA']<=150,d['Rings']<=7,d['HBD']<=5,d['HBA']<=10,d['RotBonds']<=15])),
        ('solubility',lambda d:d.loc[(d['LogS']>-4).fillna(False)].copy()),
        ('toxicity',None),('reos',None),
    ]
    filter_start=30.0;filter_span=55.0/len(config)
    for j,(key,func) in enumerate(config,1):
        before=len(current);enabled=settings.selected(2,key);base=filter_start+(j-1)*filter_span;end=filter_start+j*filter_span
        report_progress(progress,2,key,f'{key.replace("_"," ").title()} • {before:,} compounds entering filter',base)
        if enabled and before:
            if key=='toxicity':current=_fast_toxicity_filter(current,progress,base,end)
            elif key=='reos':current=_fast_reos_filter(current,progress,base,end)
            else:current=func(current)
        _step_record(rows,key,before,len(current),enabled)
        report_progress(progress,2,key,f'{key.replace("_"," ").title()} complete • {len(current):,} retained',end)
    return current,rows,analyzer

def _catalog(name):
    p=FilterCatalogParams(); p.AddCatalog(getattr(FilterCatalogParams.FilterCatalogs,name.upper()))
    return FilterCatalog(p)


def part_three(df,settings,folder,progress):
    current=_ensure_original_mol_cache(df.copy(),3,progress,0,5,'Preparing medicinal-chemistry molecules')
    rows=[];catalognames=('brenk','nih','pains')
    for j,key in enumerate(catalognames,1):
        enabled=settings.selected(3,key);before=len(current);base=5+(j-1)*(80/3);end=5+j*(80/3)
        pretty={'brenk':'BRENK','nih':'NIH','pains':'PAINS'}[key]
        report_progress(progress,3,key,f'{pretty} catalog • {before:,} compounds to screen',base)
        if enabled and before:
            catalog=_catalog(key);records=[];total=len(current);started=time.perf_counter();interval=_progress_interval(total);bad_ids=set()
            ids=current['source_row_id'].to_numpy();names=current['compound_name'].astype(str).to_numpy();smis=current['smiles'].astype(str).to_numpy();mols=current['_studio_mol_original'].tolist()
            for pos,(sid,name,smi,mol) in enumerate(zip(ids,names,smis,mols),1):
                if mol is None:
                    records.append({'source_row_id':sid,'compound_name':name,'smiles':smi,'filter':key,'description':'Invalid SMILES'});bad_ids.add(sid)
                else:
                    entry=catalog.GetFirstMatch(mol)
                    if entry:
                        records.append({'source_row_id':sid,'compound_name':name,'smiles':smi,'filter':key,'description':entry.GetDescription()});bad_ids.add(sid)
                if pos==1 or pos==total or pos%interval==0:
                    report_progress(progress,3,key,_live_detail(f'{pretty} alerts',pos,total,started),base+(end-base)*(pos/total))
            if records:pd.DataFrame(records).to_csv(folder/f'{key}_matches.csv',index=False)
            current=current.loc[~current['source_row_id'].isin(bad_ids)].copy()
        _step_record(rows,key,before,len(current),enabled);report_progress(progress,3,key,f'{pretty} complete • {len(current):,} retained',end)
    return current,rows,None

def load_pattern_groups():
    ref=curated_csv_path()
    if not ref.is_file(): raise FileNotFoundError(f'Bundled SMARTS reference was not found: {ref}')
    raw=pd.read_csv(ref, dtype=str)
    if not {'name','smarts'}.issubset(raw.columns): raise ValueError('The bundled reference CSV must contain name and smarts columns.')
    groups={
       'unwanted': [(str(r['name']),str(r['smarts'])) for _,r in raw.iterrows()],
       'scaffolds':list(old.create_undesirable_scaffolds().items()),
       'aggregators':list(old.create_aggregators().items()),
       'toxicophores':list(old.create_toxicophores().items()),
       'reactive':list(old.create_reactive_groups().items())
    }
    return groups


def part_four(df,settings,folder,progress):
    current=_ensure_original_mol_cache(df.copy(),4,progress,0,4,'Preparing structural-screen molecules')
    rows=[];group_items=list(_compiled_pattern_groups().items())
    for j,(key,payload) in enumerate(group_items,1):
        items,compiled,failures=payload;enabled=settings.selected(4,key);before=len(current);base=4+(j-1)*(81/len(group_items));end=4+j*(81/len(group_items));pretty=key.replace('_',' ').title()
        report_progress(progress,4,key,f'{pretty} • {len(items):,} SMARTS • {before:,} compounds',base)
        if enabled and before:
            if failures:pd.DataFrame(failures).to_csv(folder/f'invalid_{key}_patterns.csv',index=False)
            matches=[];kept=[];total=len(current);started=time.perf_counter();interval=_progress_interval(total)
            ids=current['source_row_id'].to_numpy();names=current['compound_name'].astype(str).to_numpy();smis=current['smiles'].astype(str).to_numpy();mols=current['_studio_mol_original'].tolist()
            for pos,(sid,name,smi,mol) in enumerate(zip(ids,names,smis,mols),1):
                if mol is None:
                    matches.append({'source_row_id':sid,'compound_name':name,'smiles':smi,'pattern_name':'Invalid SMILES','pattern_smarts':'','pattern_row':'','filter':key})
                else:
                    hit=None
                    for i,n,s,q in compiled:
                        if mol.HasSubstructMatch(q):hit=(i,n,s);break
                    if hit:
                        i,n,s=hit;matches.append({'source_row_id':sid,'compound_name':name,'smiles':smi,'pattern_name':n,'pattern_smarts':s,'pattern_row':i+1,'filter':key})
                    else:kept.append(sid)
                if pos==1 or pos==total or pos%interval==0:
                    report_progress(progress,4,key,_live_detail(pretty,pos,total,started),base+(end-base)*(pos/total))
            if matches:pd.DataFrame(matches).to_csv(folder/f'{key}_matches.csv',index=False)
            current=current[current.source_row_id.isin(kept)].copy()
        _step_record(rows,key,before,len(current),enabled,f'{len(items)} original patterns; duplicate names retained' if key=='unwanted' else '')
        report_progress(progress,4,key,f'{pretty} complete • {len(current):,} retained',end)
    return current,rows,None

def publication_style(ax,title=None,xlabel=None,ylabel=None):
    if title: ax.set_title(title,fontsize=15,fontweight='bold',pad=13)
    if xlabel: ax.set_xlabel(xlabel,fontsize=13,fontweight='bold',labelpad=9)
    if ylabel: ax.set_ylabel(ylabel,fontsize=13,fontweight='bold',labelpad=9)
    ax.tick_params(axis='both', labelsize=11, width=1.25)
    for t in list(ax.get_xticklabels())+list(ax.get_yticklabels()):
        t.set_fontweight('bold'); t.set_fontsize(11)
    for t in ax.get_legend().get_texts() if ax.get_legend() else []: t.set_fontweight('bold')
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',alpha=.16)


def save_figure(fig,stem,folder,formats=('png','svg','tiff')):
    folder=Path(folder); folder.mkdir(parents=True,exist_ok=True)
    for fmt in formats:
        kw={'bbox_inches':'tight','facecolor':'white'}
        if fmt in ('png','tiff'): kw['dpi']=600
        if fmt=='tiff': kw['pil_kwargs']={'compression':'tiff_lzw'}
        fig.savefig(folder/f'{stem}.{fmt}',**kw)
    plt.close(fig)


def plot_stage(rows,stage,figures,formats,pre=None,post=None):
    rows=[r for r in rows if r['applied']]
    if not rows: return
    labels=[str(x['filter']).replace('_',' ').title() for x in rows]
    first=rows[0]['before']; remain=[first]+[r['remaining'] for r in rows]
    fig,axs=plt.subplots(2,1,figsize=(12.5,9.4),gridspec_kw={'height_ratios':[1.12,1]})
    xs=np.arange(len(rows)+1)
    axs[0].plot(xs,remain,'o-',linewidth=2.6,markersize=8,color='#245c9c')
    axs[0].set_xticks(xs, ['Input']+labels,rotation=25,ha='right')
    for i,y in enumerate(remain): axs[0].annotate(f'{y:,}',(i,y),xytext=(0,9),textcoords='offset points',ha='center',fontsize=10,fontweight='bold')
    publication_style(axs[0],f'Part {stage} | Sequential Compound Retention','Filtering Steps','Compounds Retained')
    axs[1].bar(np.arange(len(rows)),[r['removed'] for r in rows],color='#3b78ba',alpha=.86)
    axs[1].set_xticks(np.arange(len(rows)),labels,rotation=25,ha='right')
    publication_style(axs[1],'Compounds Excluded at Each Step','Filtering Steps','Compounds Removed')
    fig.tight_layout(pad=2.4)
    save_figure(fig,'Filtering_Cascade',figures,formats)
    fig,ax=plt.subplots(figsize=(10,5.6))
    removals=[r['removed'] for r in rows]
    colors=['#d4dce6' if not r['applied'] else '#2c659d' for r in rows]
    bars=ax.barh(labels,removals,color=colors)
    ax.invert_yaxis()
    for b,v in zip(bars,removals): ax.text(b.get_width()+max(1,max(removals,default=0)*.02),b.get_y()+b.get_height()/2,str(v),va='center',fontweight='bold',fontsize=10)
    ax.set_xlim(0,max(1,max(removals,default=0)*1.22))
    publication_style(ax,f'Part {stage} | Filter Impact','Excluded Compounds','Filtering Steps')
    fig.tight_layout();save_figure(fig,'Filter_Impact',figures,formats)
    fig,ax=plt.subplots(figsize=(8.5,5.5))
    end=remain[-1]; removed=first-end
    ax.bar(['Retained','Excluded'],[end,removed],color=['#19836a','#be5c5c'],width=.55)
    for i,v in enumerate([end,removed]): ax.text(i,v+max(1,first*.01),f'{v:,}',ha='center',fontweight='bold')
    ax.set_ylim(0,max(1,max(first,end,removed)*1.16))
    publication_style(ax,f'Part {stage} | Outcome Summary','Outcome','Compounds')
    fig.tight_layout();save_figure(fig,'Outcome_Summary',figures,formats)
    if stage==2 and pre is not None and post is not None and len(pre)>1:
        for col in ('MW','LogP','TPSA','LogS'):
            if col not in pre.columns: continue
            fig,ax=plt.subplots(figsize=(9,5.5))
            a=pd.to_numeric(pre[col],errors='coerce').dropna(); b=pd.to_numeric(post[col],errors='coerce').dropna() if len(post) else pd.Series(dtype=float)
            if len(a): ax.hist(a,bins=min(24,max(5,int(np.sqrt(len(a))))),alpha=.55,label='Before',color='#458cca',density=True)
            if len(b): ax.hist(b,bins=min(24,max(5,int(np.sqrt(len(b))))),alpha=.55,label='After',color='#14836d',density=True)
            ax.legend()
            publication_style(ax,f'{col} | Descriptor Distribution',col,'Density')
            fig.tight_layout();save_figure(fig,f'Descriptor_{col}',figures,formats)


def _plot_hit_summary(folder,figures,formats,part):
    rows=[]
    for csv in folder.glob('*_matches.csv'):
        try:
            df=pd.read_csv(csv)
        except (pd.errors.EmptyDataError, OSError): continue
        if df.empty: continue
        key='description' if 'description' in df.columns else 'pattern_name'
        if key not in df.columns:continue
        for k,v in df[key].astype(str).value_counts().head(15).items():rows.append((csv.stem.replace('_matches',''),k,int(v)))
    if not rows:return
    summary=pd.DataFrame(rows,columns=['Filter','Alert','Count']).sort_values('Count',ascending=False).head(15)
    fig,ax=plt.subplots(figsize=(12,6.2))
    bars=ax.barh([f'{str(r.Filter).upper()}: {str(r.Alert)[:58]}' for r in summary.itertuples()],summary.Count,color='#2e6ea9')
    ax.invert_yaxis()
    publication_style(ax,f'Part {part} | Most Frequent Alerts','Matched Compound Count','Alert / Filter Description')
    for tick in ax.get_yticklabels(): tick.set_fontweight('bold'); tick.set_fontsize(11.5)
    for b,v in zip(bars,summary.Count): ax.text(b.get_width()+max(0.3,float(summary.Count.max())*.015),b.get_y()+b.get_height()/2,f'{int(v):,}',va='center',fontsize=10.5,fontweight='bold')
    fig.tight_layout();save_figure(fig,'Top_Alerts',figures,formats)


from contextlib import contextmanager

@contextmanager
def original_plot_bold_labels(stage):
    """Only typography adjustment for original Parts 1,2,4; Part 3 is untouched.

    Apply bold axis labels/ticks before saving, without changing original color,
    chart geometry, filtering data or rendering code.
    """
    if stage==3:
        yield
        return
    from matplotlib.figure import Figure
    saved_figure=Figure.savefig
    def save_bold(fig,*args,**kwargs):
        for ax in fig.axes:
            for label_obj in (ax.xaxis.label,ax.yaxis.label):
                label_obj.set_fontweight('bold')
            for tick in ax.get_xticklabels()+ax.get_yticklabels():
                tick.set_fontweight('bold')
        return saved_figure(fig,*args,**kwargs)
    Figure.savefig=save_bold
    try:
        yield
    finally:
        Figure.savefig=saved_figure

class _WorkDir:
    def __init__(self,path): self.path=Path(path); self.old=None
    def __enter__(self):
        self.old=Path.cwd(); os.chdir(self.path); return self.path
    def __exit__(self,*exc): os.chdir(self.old)

def add_original_plots(stage,original_obj,part2_orig,post,stats,folder,errors):
    """Generate the principal figures from the four supplied original notebooks.

    Original figures are saved separately from the Studio figures so both sets
    remain available for visual inspection and manuscript preparation.
    """
    stats=[r for r in stats if r['applied']]
    if not stats: return
    plot_dir=folder/'figures'/'original_notebook_figures'
    plot_dir.mkdir(parents=True,exist_ok=True)
    old.plt.close('all')


    try:
        with original_plot_bold_labels(stage):
            _run_original_plots_for_stage(stage,original_obj,part2_orig,post,stats,folder,plot_dir)
    except Exception as e:
        errors.append(f'Original Part-{stage} plotting function could not run: {type(e).__name__}: {e}')
    finally:
        old.plt.close('all')

def _run_original_plots_for_stage(stage,original_obj,part2_orig,post,stats,folder,plot_dir):
        if stage==1 and original_obj is not None:
            # Presentation-only view of the original filter results: omit SKIPPED.
            import copy as _copy
            view=_copy.copy(original_obj)
            keys=['initial']+[r['filter'] for r in stats if r['filter'] in original_obj.step_descriptions]
            view.step_descriptions=OrderedDict((k,original_obj.step_descriptions[k]) for k in keys)
            view.filtering_stats=OrderedDict((k,original_obj.filtering_stats[k]) for k in keys)
            old.generate_sequential_filtering_visualizations(view,str(plot_dir))

        elif stage==2 and part2_orig is not None and post is not None:
            key_map={
                'descriptor_validity':'Initial',
                'lipinski':'Lipinski (Rule of 5)',
                'pfizer':'Pfizer Rule',
                'veber':'Veber',
                'ghose':'Ghose',
                'egan':'Egan',
                'muegge':'Muegge',
                'solubility':'Soluble (LogS > -4)',
                'toxicity':'Non-Toxic',
                'reos':'REOS'
            }
            filtering_results={'Initial':int(len(part2_orig.df))}
            for r in stats:
                filtering_results[key_map.get(r['filter'],r['filter'])]=int(r['remaining'])
            filtering_results={'Initial':filtering_results.pop('Initial',int(len(part2_orig.df))), **{k:v for k,v in filtering_results.items() if k != 'Initial'}}
            old.PLOT_OUTPUT_DIR=plot_dir
            with _WorkDir(plot_dir):
                old.generate_and_save_all_visualizations(
                    part2_orig.df,post,filtering_results,
                    original_count=int(len(part2_orig.df))
                )
                if not any(r['filter']=='pfizer' for r in stats):
                    for figure in plot_dir.glob('*pfizer*'):
                        figure.unlink(missing_ok=True)

        elif stage==3 and stats:
            counts=[int(stats[0]['before'])]+[int(q['remaining']) for q in stats]
            names=['Original']+[q['filter'].upper() for q in stats]
            fig=old.create_part3_filter_summary_plot(
                names,counts,'Compound Count After Medicinal Chemistry Filters'
            )
            if fig is not None:
                fig.savefig(plot_dir/'med_chem_filters_summary.png',
                            dpi=300,bbox_inches='tight')
                old.plt.close(fig)

            filtered_counts={}
            specs=[
                ('brenk','Top 10 Brenk Filter Hits',
                 'brenk_filter_hits.png','brenk_filtered_examples.png'),
                ('nih','Top 10 NIH Filter Hits',
                 'nih_filter_hits.png','nih_filtered_examples.png'),
                ('pains','Top 10 PAINS Patterns',
                 'pains_patterns.png','pains_examples.png')
            ]
            for key,title,bar_name,mol_name in specs:
                source=folder/f'{key}_matches.csv'
                if not source.is_file(): continue
                try: hits=pd.read_csv(source)
                except (pd.errors.EmptyDataError,OSError): continue
                if hits.empty: continue
                filtered_counts[key.upper() if key!='pains' else 'PAINS']=len(hits)
                desc='description' if 'description' in hits.columns else (
                    'pains' if 'pains' in hits.columns else 'pattern_name')
                top=hits[desc].astype(str).value_counts().head(10)
                fig,ax=old.plt.subplots(figsize=(12,6))
                try:
                    old.sns.barplot(x=top.index,y=top.values,ax=ax)
                except Exception:
                    ax.bar(range(len(top)),top.values)
                    ax.set_xticks(range(len(top)),top.index)
                ax.set_title(title,fontsize=16,fontweight='bold')
                ax.set_xlabel('PAINS Pattern' if key=='pains'
                              else 'Filter Description',fontsize=14,fontweight='bold')
                ax.set_ylabel('Count',fontsize=14,fontweight='bold')
                ax.tick_params(axis='x',rotation=45,labelsize=11)
                ax.tick_params(axis='y',labelsize=11)
                for tick in ax.get_xticklabels()+ax.get_yticklabels(): tick.set_fontweight('bold')
                for i,v in enumerate(top.values):
                    ax.text(i,float(v)+0.1,str(int(v)),ha='center',
                            fontsize=10,fontweight='bold')
                fig.tight_layout()
                fig.savefig(plot_dir/bar_name,dpi=300,bbox_inches='tight')
                old.plt.close(fig)

                molecules=[]; labels=[]
                for _,row in hits.head(6).iterrows():
                    mol=Chem.MolFromSmiles(str(row.get('smiles','')))
                    if mol is not None:
                        molecules.append(mol)
                        labels.append(
                            f"{str(row.get('compound_name','Compound'))[:22]}: "
                            f"{str(row.get(desc,''))[:36]}"
                        )
                if molecules:
                    fig=old.visualize_molecules(
                        molecules,labels,
                        ('Examples of PAINS Compounds' if key=='pains'
                         else f'Examples of Compounds Filtered by {key.upper()}'),
                        n_cols=3
                    )
                    if fig is not None:
                        fig.savefig(plot_dir/mol_name,dpi=300,bbox_inches='tight')
                        old.plt.close(fig)

            filtered_counts['Passed All Filters']=int(len(post))
            if filtered_counts:
                fig,ax=old.plt.subplots(figsize=(10,8))
                ax.pie(list(filtered_counts.values()),
                       labels=list(filtered_counts.keys()),
                       autopct='%1.1f%%',startangle=90,shadow=True,
                       explode=[0.05]*len(filtered_counts),
                       textprops={'fontsize':14,'fontweight':'bold'})
                ax.axis('equal')
                ax.set_title(
                    'Distribution of Compounds After Medicinal Chemistry Filters',
                    fontsize=16,fontweight='bold',pad=20
                )
                fig.savefig(plot_dir/'med_chem_filters_distribution.png',
                            dpi=300,bbox_inches='tight')
                old.plt.close(fig)

            molecules=[]; labels=[]
            for _,row in post.head(6).iterrows():
                mol=Chem.MolFromSmiles(str(row.get('smiles','')))
                if mol is not None:
                    molecules.append(mol)
                    labels.append(str(row.get('compound_name','Compound')))
            if molecules:
                fig=old.visualize_molecules(
                    molecules,labels,
                    'Examples of Compounds Passing Medicinal Chemistry Filters',
                    n_cols=3
                )
                if fig is not None:
                    fig.savefig(plot_dir/'example_compounds.png',
                                dpi=300,bbox_inches='tight')
                    old.plt.close(fig)

        elif stage==4 and stats:
            astats=[{
                'filter_name':r['filter'].replace('_',' ').title(),
                'total_input':r['before'],
                'failed_filter':r['removed'],
                'passed_filter':r['remaining'],
                'filter_rate':100*r['removed']/r['before'] if r['before'] else 0
            } for r in stats]
            old.create_filtering_cascade_plot(astats,plot_dir)
            old.create_filter_summary_plot(astats,plot_dir)
            matches=[]
            for src in folder.glob('*_matches.csv'):
                try: d=pd.read_csv(src)
                except (pd.errors.EmptyDataError,OSError): continue
                if len(d):
                    d['filter_type']=src.stem.replace('_matches','')
                    matches.append(d)
            if matches: old.create_pattern_analysis_plot(matches,plot_dir)
            if astats and astats[0]['total_input']:
                old.create_final_summary_plot(
                    astats[0]['total_input'],astats[-1]['passed_filter'],
                    astats,plot_dir
                )


def render_overall_chart(counts_file, summary_dir, formats=('png','svg','tiff'), options=None):
    """Re-render applied-filter counts; chart options adapted from user's Cheminformatics Pipeline Visualizer.

    Scientific input is the saved applied-only counts CSV. Editing colors, sizes or fonts
    never reruns screening or changes underlying statistics.
    """
    from matplotlib.colors import to_rgb
    import colorsys
    defaults = dict(color='#BD5C19', chart_type='Vertical orange bars',
                    width=14.0, height=8.2, title_size=17, axis_size=15,
                    tick_size=11, value_size=11, bar_width=0.73,
                    rotation=58, dpi=600, background='#FFFFFF',
                    title='Compound Filtering by Cheminformatics Pipeline')
    opt = {**defaults, **(options or {})}
    data = pd.read_csv(counts_file)
    if not {'Filtering Step','Compounds Retained'}.issubset(data.columns):
        raise ValueError('Overall figure CSV must contain Filtering Step and Compounds Retained.')
    labels = data['Filtering Step'].astype(str).tolist()
    counts = pd.to_numeric(data['Compounds Retained'], errors='raise').astype(int).tolist()
    if not labels:
        raise ValueError('No applied filters to plot.')
    color = str(opt['color'])
    to_rgb(color)  # validate user-selected color
    typ = str(opt['chart_type'])
    width = max(7.0, min(40.0, float(opt['width'])))
    height = max(4.5, min(25.0, float(opt['height'])))
    fig, ax = plt.subplots(figsize=(width,height))
    fig.patch.set_facecolor(opt['background'])
    ax.set_facecolor('#FAFAFA')
    x = np.arange(len(labels))
    bar_w = max(.25,min(.95,float(opt['bar_width'])))
    if typ == 'Gradient bars':
        r,g,b = to_rgb(color)
        h,sv,v = colorsys.rgb_to_hsv(r,g,b)
        colors = [colorsys.hsv_to_rgb(h,sv,v*(.6+.4*i/max(len(x)-1,1))) for i in range(len(x))]
    else:
        colors = [color]*len(x)
    if typ == 'Horizontal bars':
        bars = ax.barh(x,counts,height=bar_w,color=colors,edgecolor='#7F3D13',linewidth=1.2)
        ax.set_yticks(x, labels)
        ax.invert_yaxis()
        ax.set_xlabel('Number of Compounds',fontsize=opt['axis_size'],fontweight='bold')
        ax.set_ylabel('Filtering Step',fontsize=opt['axis_size'],fontweight='bold')
        ax.set_xlim(0,max(1,max(counts)*1.20))
        for rect,n in zip(bars,counts):
            ax.annotate(f'{n:,}', (rect.get_width(),rect.get_y()+rect.get_height()/2),
                        xytext=(4,0),textcoords='offset points',va='center',ha='left',
                        fontsize=opt['value_size'],fontweight='bold')
        ax.grid(axis='x',alpha=.12)
    else:
        bars = ax.bar(x,counts,width=bar_w,color=colors,edgecolor='#7F3D13',linewidth=1.2)
        ax.set_xticks(x,labels,rotation=int(opt['rotation']),ha='right' if int(opt['rotation']) else 'center')
        ax.set_ylim(0,max(1,max(counts)*1.17))
        ax.set_ylabel('Number of Compounds',fontsize=opt['axis_size'],fontweight='bold',labelpad=8)
        ax.set_xlabel('Filtering Step',fontsize=opt['axis_size'],fontweight='bold',labelpad=8)
        for rect,n in zip(bars,counts):
            ax.annotate(f'{n:,}',(rect.get_x()+rect.get_width()/2,rect.get_height()),
                        xytext=(0,5),textcoords='offset points',ha='center',va='bottom',
                        rotation=90,fontsize=opt['value_size'],fontweight='bold',color='#191919')
        ax.grid(axis='y',alpha=.12)
    ax.set_title(str(opt['title']),fontsize=opt['title_size'],fontweight='bold',pad=17,loc='center')
    for tick in ax.get_xticklabels()+ax.get_yticklabels():
        tick.set_fontweight('bold')
        tick.set_fontsize(opt['tick_size'])
    ax.spines[['top','right']].set_visible(False)
    ax.set_axisbelow(True)
    fig.tight_layout(pad=2.2)
    out=Path(summary_dir)/'figures'
    out.mkdir(parents=True,exist_ok=True)
    stem='Overall_Applied_Filtering_Cascade'
    for fmt in formats:
        kw={'bbox_inches':'tight','facecolor':opt['background']}
        if fmt in ('png','tiff'):kw['dpi']=int(opt['dpi'])
        if fmt=='tiff':kw['pil_kwargs']={'compression':'tiff_lzw'}
        fig.savefig(out/f'{stem}.{fmt}',**kw)
    plt.close(fig)
    return out/(stem+'.png')


def plot_overall_applied_filters(stages,summary_dir,formats=('png','svg','tiff')):
    """Across completed Parts only; never display SKIPPED or NOT RUN steps."""
    executed=[]
    for stage in stages:
        for r in stage.get('steps',[]):
            if r.get('applied') and r.get('filter')!='descriptor_validity':
                executed.append((int(stage['part']),r))
    if not executed:return None
    labels=['Initial Library']
    counts=[int(stages[0]['input'])]
    for part,r in executed:
        labels.append(str(r['filter']).replace('_',' ').title())
        counts.append(int(r['remaining']))
    dest=Path(summary_dir)/'overall_applied_filter_counts.csv'
    pd.DataFrame({'Filtering Step':labels,'Compounds Retained':counts}).to_csv(dest,index=False)
    render_overall_chart(dest,summary_dir,formats)
    return Path(summary_dir)/'figures'


def file_sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for blk in iter(lambda:f.read(4*1024*1024),b''):h.update(blk)
    return h.hexdigest()


def prepare_run_dir(config):
    base=Path(config.output_base or (Path.cwd()/'Compound_Filtering_Results')).resolve()
    base.mkdir(parents=True,exist_ok=True)
    stem=config.run_name.strip().replace('/','_').replace('\\','_') or datetime.now().strftime('Compound_Screening_%Y%m%d_%H%M%S')
    target=base/stem
    j=1
    while target.exists():
        target=base/f'{stem}_{j:02d}';j+=1
    target.mkdir(parents=True)
    for n in FOLDER_NAMES.values(): (target/n/'figures').mkdir(parents=True)
    (target/'05_Combined_Summary').mkdir()
    return target


def analyze(source,config,progress=None,upto=4,existing_data=None,existing_dir=None,previous_manifest=None,start_part=1):
    """Process the specified starting Part through upto.
    A fresh CSV supplied to Part 2/3/4 is assumed to already be appropriate
    for that Part; earlier Parts are NOT run or claimed as completed.
    """
    if not (1 <= int(start_part) <= int(upto) <= 4):
        raise ValueError('Part range must be 1 <= start_part <= upto <= 4')
    started=time.time()
    if existing_data is None:
        df,meta=clean_import(pd.read_csv(source,low_memory=False))
        run=prepare_run_dir(config)
        if source:
            meta['input_sha256']=file_sha256(source)
            meta['input_filename']=Path(source).name
    else:
        df=existing_data.copy();meta=(previous_manifest or {}).get('source',{'input_filename':'previous stage output'})
        # Confirm the invariant whenever an individual next Part is launched.
        if 'input_smiles' in df.columns and not df['smiles'].astype(str).equals(df['input_smiles'].astype(str)):
            raise ValueError('The previous stage changed original SMILES; refusing to propagate final_smiles.')
        run=Path(existing_dir)
    settings={k:dict(v) for k,v in config.enabled.items()}
    steps=list((previous_manifest or {}).get('stages',[])); errors=list((previous_manifest or {}).get('warnings',[])); initial=int((previous_manifest or {}).get('total_input',len(df)))
    functions={1:part_one,2:part_two,3:part_three,4:part_four}
    first=start_part if existing_data is None else upto
    output=input_df=df
    for part in range(first,upto+1):
        part_started=time.perf_counter()
        name=PARTS[part][0]
        folder=run/FOLDER_NAMES[part]
        report_progress(progress,part,'start',f'Starting Part {part}: {name}',0)
        output,records,obj=functions[part](output,config,folder,progress)
        # Prevent accidental SMILES replacement in any stage; retain original compounds.
        if 'input_smiles' in output.columns and len(output):
            original=output['input_smiles'].astype('string').fillna('').str.strip()
            if not output['smiles'].astype('string').fillna('').str.strip().equals(original):
                raise AssertionError(f'Part {part} changed original SMILES in the handoff column.')
        export_df(output,folder/f'part{part}_filtered_compounds.csv')
        pd.DataFrame(records).to_csv(folder/'filter_statistics.csv',index=False)
        report_progress(progress,part,'figures',f'Creating Part {part} Studio figures and publication exports...',88)
        try:
            if records:
                plot_stage(records,part,folder/'figures',config.figure_formats,pre=obj.df if part==2 and obj is not None else None,post=output)
                if part in (3,4): _plot_hit_summary(folder,folder/'figures',config.figure_formats,part)
        except Exception as e:
            errors.append(f'Part {part} standard plot error: {type(e).__name__}: {e}')
        if True:
            report_progress(progress,part,'original_figures',f'Creating Part {part} original-notebook figures...',94)
            add_original_plots(part,obj if part==1 else None,obj if part==2 else None,output,records,folder,errors)
        record={'part':part,'name':name,'input':int(records[0]['before']) if records else int(len(output)),'output':int(len(output)),'removed':int(records[0]['before']-len(output)) if records else 0,'steps':records,'seconds_elapsed':round(time.perf_counter()-part_started,2)}
        steps.append(record)
        report_progress(progress,part,'done',f'Part {part} completed — {len(output):,} compounds retained',100)
    # Summaries
    summary=run/'05_Combined_Summary'
    export_df(output,summary/'final_filtered_compounds.csv')
    try:
        plot_overall_applied_filters(steps,summary,config.figure_formats)
    except Exception as e:
        errors.append(f'Overall applied-filter figure error: {type(e).__name__}: {e}')
    selected={str(p):[k for k,_ in items if config.selected(p,k)] for p,(_,items) in PARTS.items()}
    manifest={'application':'Four-Stage Compound Filtering Studio','version':'1.0 original-SMILES research candidate',
              'smiles_handoff_policy':'Original input SMILES retained unchanged as analysis smiles throughout Parts 1-4; final_smiles is a separate provenance field, not downstream input',
              'started_at':datetime.now().isoformat(timespec='seconds'),'start_part':int(steps[0]['part']) if steps else int(start_part),'completed_parts':[int(s['part']) for s in steps],'total_input':int(initial),
              'total_output':int(len(output)),'total_excluded':int(initial-len(output)),
              'retention_percent':round(100*len(output)/initial,3) if initial else 0,
              'source':meta,'selected_filters':selected,'ph':config.ph,
              'stages':steps,'warnings':errors,'packages':{'rdkit':rdBase.rdkitVersion,'pandas':pd.__version__,'numpy':np.__version__,'matplotlib':matplotlib.__version__},
              'reference_patterns':{'file':curated_csv_path().name,'sha256':file_sha256(curated_csv_path()),'records':104}}
    (summary/'analysis_manifest.json').write_text(json.dumps(manifest,indent=2,default=str),encoding='utf-8')
    pd.DataFrame([{'part':x['part'],'stage':x['name'],'input':x['input'],'removed':x['removed'],'output':x['output']} for x in steps]).to_csv(summary/'overall_filtering_summary.csv',index=False)
    if steps:
        chain='; '.join(f"Part {item['part']} ({item['name']}) retained {item['output']:,}" for item in steps)
        paragraph=(f"An initial library comprising {initial:,} compound records was subjected to a "
                   f"sequential computational screening workflow with user-selected filters. "
                   f"{chain}. Following the {len(steps)} completed stage(s), {len(output):,} compounds "
                   f"({manifest['retention_percent']:.2f}% of the input) remained, corresponding to "
                   f"{initial-len(output):,} exclusions. These figures indicate computational filter retention "
                   f"only and do not establish experimental toxicity, efficacy, or clinical safety.")
    else: paragraph='No screening stages were completed.'
    description=['FOUR-STAGE COMPOUND FILTERING — COMPUTATIONAL RESULTS','',
                 'SMILES IDENTITY: Original input SMILES are used for Parts 2, 3 and 4. Standardized/ionized final_smiles is retained as an auxiliary Part-1 column only.','',
                 f"RUN STARTED AT PART {manifest['start_part']}: Earlier stages were NOT executed in this run when start_part > 1.",'',
                 'MANUSCRIPT RESULTS DRAFT (verify all selections before publication):','',
                 paragraph,'',
                 'These counts are descriptive only; this is not experimental ADMET or toxicity validation.','',
                 f'Input: {initial:,} compounds','']
    for s in steps:
        description.append(f"Part {s['part']} ({s['name']}): {s['input']:,} -> {s['output']:,}; excluded {s['removed']:,}; elapsed {s.get('seconds_elapsed',0):.1f} s.")
        for q in s['steps']:
            description.append(f"   {q['filter']}: {'APPLIED' if q['applied'] else 'SKIPPED'}; removed {q['removed']:,}; remaining {q['remaining']:,}")
    description += ['',f'Final retained: {len(output):,} ({manifest["retention_percent"]:.2f}% of starting library).',
                    'Molecular and substructure alerts are screening heuristics, not proof of toxicity or aggregation.',
                    'IMPORTANT: Review selected filter thresholds, duplicate handling and protonation before publication.',
                    '']
    description+=['WARNINGS:']+([f' - {e}' for e in errors] if errors else [' - None recorded'])
    (summary/'paper_ready_results_summary.txt').write_text('\n'.join(description),encoding='utf-8')
    markdown=['# Computational Screening Results (Draft)','',paragraph,'',
              '## Stage-wise compound counts','',
              '| Stage | Input | Excluded | Retained |',
              '|---|---:|---:|---:|']
    for item in steps:
        markdown.append(f"| Part {item['part']}: {item['name']} | {item['input']:,} | {item['removed']:,} | {item['output']:,} |")
    markdown += ['', '## Filter decisions', '']
    for item in steps:
        markdown += [f"### Part {item['part']} — {item['name']}",'',
                     '| Filter | Applied | Excluded | Retained |', '|---|---|---:|---:|']
        for q in item['steps']:
            markdown.append(f"| {q['filter']} | {'Yes' if q['applied'] else 'No (skipped)'} | {q['removed']:,} | {q['remaining']:,} |")
        markdown.append('')
    markdown += ['## Interpretation limits','',
                 'These substructure and descriptor filters are exploratory heuristics, not experimental demonstrations of toxicity, aggregation, safety or efficacy.',
                 'Confirm the filtering settings and molecular-state preparation before using this draft in a manuscript.','']
    (summary/'paper_ready_results_summary.md').write_text('\n'.join(markdown),encoding='utf-8')
    # Include curated SMARTS source and its provenance
    shutil.copy2(curated_csv_path(),summary/curated_csv_path().name)
    zip_file=run.with_suffix('.zip')
    with zipfile.ZipFile(zip_file,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(run.rglob('*')):
            if f.is_file(): z.write(f, f.relative_to(run.parent))
    manifest['zip_file']=str(zip_file)
    manifest['project_dir']=str(run)
    manifest['seconds_elapsed']=round(time.time()-started,2)
    return manifest,output

def _criteria_rows_from_config(config):
    rows=[]
    for part,(part_name,items) in PARTS.items():
        for key,label_text in items:
            rows.append({
                'part':part,'part_name':part_name,'filter_key':key,
                'filter_name':label_text,
                'selected':bool(config.selected(part,key)),
                'criterion':FILTER_CRITERIA.get(part,{}).get(key,'')
            })
    return rows


def _write_documentation_bundle(manifest, output, config):
    """Create exactly two manuscript-support TXT files for executed filters only.

    Stage CSVs, molecular match files, selected figures and the ZIP are
    scientific outputs, not additional manuscript reports. Files generated by
    older versions of the studio are removed from this new run directory.
    """
    root = Path(manifest['project_dir'])
    summary = root / '05_Combined_Summary'
    summary.mkdir(parents=True, exist_ok=True)

    executed = manifest.get('stages', [])
    p_input = int(manifest.get('total_input', 0))
    p_output = int(manifest.get('total_output', 0))
    percent = float(manifest.get('retention_percent', 0))
    input_label = manifest.get('source', {}).get('input_filename', 'input CSV')

    methods = [
        'COMPUTATIONAL METHODS — SELECTED AND EXECUTED FILTERS ONLY',
        '=' * 76,
        f'Input dataset: {input_label}',
        f'Analysis started at Part {manifest.get("start_part", 1)}.',
        'Only the Parts actually executed in this analysis are described.',
        'Original input SMILES were retained for molecular analysis and compound',
        'identification; normalized/ionized SMILES remained auxiliary fields.',
        '',
    ]
    results = [
        'COMPUTATIONAL RESULTS — SELECTED AND EXECUTED FILTERS ONLY',
        '=' * 76,
        f'Input compounds: {p_input:,}',
        f'Retained compounds: {p_output:,}',
        f'Excluded compounds: {p_input-p_output:,}',
        f'Overall retention: {percent:.2f}%',
        '',
    ]
    report_part_names = {1:'Molecular Preparation', 2:'Property-Based Screening',
                         3:'Medicinal Chemistry Screening', 4:'Structural Screening'}
    report_part_names = {1:'Molecular Preparation', 2:'Property-Based Screening',
                         3:'Medicinal Chemistry Screening', 4:'Structural Screening'}
    total_applied = 0
    for stage in executed:
        p = int(stage['part'])
        rows = [r for r in stage.get('steps', []) if r.get('applied')]
        methods.append(f'PART {p}: {report_part_names.get(p, "Screening")}')
        results.append(f'PART {p}: {report_part_names.get(p, "Screening")}')
        results.append(f'  Compounds: {int(stage["input"]):,} -> {int(stage["output"]):,}')
        results.append(f'  Removed in this Part: {int(stage["removed"]):,}')
        if p == 2:
            methods.append('  Prerequisite: molecular descriptors were computed from original SMILES.')
            prereqs = [r for r in stage.get('steps', [])
                       if r.get('filter') == 'descriptor_validity']
            for pr in prereqs:
                results.append(f'  Prerequisite descriptor validation: {int(pr["removed"]):,} removed.')
        if p == 1:
            methods.append('  Molecular preparation followed the selected original notebook rules.')
        if not rows:
            methods.append('  No selectable filtering rule was applied in this Part.')
            results.append('  No optional filtering rule was applied in this Part.')
        for r in rows:
            key = str(r['filter'])
            # A non-selectable descriptor prerequisite is documented above, not
            # incorrectly represented as a user-selected filtering criterion.
            if key == 'descriptor_validity':
                continue
            display = next((title for item_key, title in PARTS[p][1] if item_key == key),
                           key.replace('_', ' ').title())
            criterion = FILTER_CRITERIA.get(p, {}).get(key, '')
            methods.append(f'  - {display}: {criterion}')
            results.append(
                f'  - {display}: {int(r["before"]):,} tested; '
                f'{int(r["removed"]):,} excluded; {int(r["remaining"]):,} retained.'
            )
            total_applied += 1
        methods.append('')
        results.append('')

    methods.extend([
        f'Total user-selected filters actually executed: {total_applied}.',
        '',
        'Interpretation: calculated drug-likeness and substructure alerts are',
        'screening criteria, not experimental evidence of toxicity, safety,',
        'aggregation, clinical efficacy or biological activity.',
    ])
    results.extend([
        f'Total user-selected filters actually executed: {total_applied}.',
        'These counts are computational filtering outcomes only; they do not',
        'establish safety, toxicity, pharmacological efficacy or bioavailability.',
    ])
    (summary / 'Methods.txt').write_text('\n'.join(methods) + '\n', encoding='utf-8')
    (summary / 'Results.txt').write_text('\n'.join(results) + '\n', encoding='utf-8')

    # The previous release made overlapping manuscript files. Keep only two
    # TXT reports. Core compound and figure CSVs are kept for downstream work.
    for old_name in (
        'analysis_log.txt', 'paper_ready_results_summary.txt',
        'paper_ready_results_summary.md', 'paper_ready_methods_support.txt',
        'paper_ready_results_support.txt', 'methods_results_support.json',
        'criteria_settings.csv', 'overall_filtering_summary.csv',
        'analysis_manifest.json', 'Two_separeted_unwanted_substructures_cleaned.csv',
    ):
        (summary / old_name).unlink(missing_ok=True)

    archive = Path(manifest['zip_file'])
    archive.unlink(missing_ok=True)
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for item in sorted(root.rglob('*')):
            if item.is_file():
                z.write(item, item.relative_to(root.parent))


def analyze_documented(source,config,progress=None,upto=4,
                       existing_data=None,existing_dir=None,previous_manifest=None,start_part=1):
    manifest,output=analyze(
        source,config,progress=progress,upto=upto,
        existing_data=existing_data,existing_dir=existing_dir,
        previous_manifest=previous_manifest,start_part=start_part
    )
    _write_documentation_bundle(manifest,output,config)
    return manifest,output

# Updated manual text for the PySide6 integrated release.
STUDIO_MANUAL_MD = r"""
# Compound Filtering & Screening Studio — User Guide

**Interface:** PySide6 Scientific Filtering Studio  
**Developer:** Md Fazlay Rabbi  
**Department:** Department of Zoology, University of Rajshahi, Bangladesh  
**Email:** rabbi.ms244@gmail.com

## 1. Purpose
This application integrates the four supplied compound-filtering notebooks into a single guided desktop workflow while retaining the original filter definitions and original-notebook figure set. The original figures remain available alongside curated Studio figures for publication reporting.

## 2. Workflow
1. Choose a CSV containing compound names and SMILES.
2. Choose the results directory.
3. Review each Part page. A filter card marked **APPLIED** will run; a card marked **SKIPPED** will not run.
4. Run the complete 1 → 2 → 3 → 4 workflow, or run any Part from a selected CSV, continuing sequentially when desired.
5. On Results & Reports view the combined original-style orange bar chart showing only applied filters. Skipped and unrun filters are absent from the chart. Follow the **Process Monitor** at the bottom. Long molecular scans report the exact number screened, percentage, throughput and elapsed time.
6. Review exactly two manuscript-support text reports: `Methods.txt` and `Results.txt`. Only executed Parts and applied filters are listed.

## 3. Parts and criteria
### Part 1 — Molecular Preparation
Uses the original parsing, fragment handling, salt removal, metal exclusion, RDKit normalization, pH-dependent ionization and duplicate-removal logic. SMILES parsing is mandatory. The default ionization pH is 7.4.

### Part 2 — Property-based Filtering
Descriptors are calculated from the retained compounds' **original input SMILES**. The original Lipinski, Pfizer, Veber, Ghose, Egan, Muegge, ESOL LogS, toxicity-score and REOS-like criteria are retained. The optimized runtime caches the RDKit molecule once and compiles repeated SMARTS once; this changes execution speed, not the rule thresholds.

### Part 3 — Brenk / NIH / PAINS
The RDKit Brenk, NIH and PAINS FilterCatalogs are applied sequentially. During each catalog scan, the Process Monitor shows `screened / total`, percentage and compounds per second. Match descriptions are exported and the alert labels in publication plots are bold for small supplementary figures.

### Part 4 — Structural Screening
The bundled 104-row unwanted-SMARTS reference plus the original undesirable-scaffold, aggregator-like, toxicophore and reactive-group definitions are applied. SMARTS are compiled once per application session to avoid repeated compilation overhead.

## 4. Why large libraries can take time
For tens of thousands of molecules, RDKit must parse structures, calculate descriptors and perform many substructure/catalog comparisons. Part 3 can require three catalog scans, while Part 4 may compare each retained molecule against many SMARTS patterns. Original-notebook figure generation and 600-DPI Studio exports also add time after filtering. The optimized runtime removes avoidable repeated SMILES parsing and SMARTS compilation and continuously reports progress so the application does not appear frozen.

## 5. Figures
Each Part keeps both:
- **ORIGINAL** — original notebook figure styles; skipped filter labels are omitted.
- **STUDIO** — publication-focused retention, filter-impact, descriptor and alert-summary figures; only applied filters are plotted.
- **OVERALL** — a combined orange applied-only filtering cascade in `05_Combined_Summary/figures`, showing all completed Parts. In Results & Reports, use the Figure Designer to change bar color, width, figure dimensions and font sizes without rerunning the filtering. Charts are exported as PNG, SVG and TIFF and added to the ZIP.

Only applied filtering steps are shown on any filter-cascade chart; skipped steps remain in CSV/audit logs only. If the Pfizer Rule is disabled, legacy figures explicitly dedicated to Pfizer are omitted. The combined orange summary chart in Results & Reports covers only applied filters from completed stages. Studio figures are exported as PNG and TIFF at 600 DPI plus SVG. Figure titles, axes, tick labels, numerical labels and Brenk/NIH/PAINS alert labels use bold typography for readability after resizing.

## 6. Outputs and manuscript support
The `05_Combined_Summary` folder contains only two manuscript-support TXT reports:
- **`Methods.txt`** — criteria of the filters actually applied in Parts executed during this run.
- **`Results.txt`** — stage counts and before/removed/retained values for applied filters only.
Skipped and unrun filters never appear in these reports. Stage-wise molecular CSV outputs, essential internal chart data, original figures, the final compound CSV and combined ZIP continue to be produced for analysis and reproducibility; these are not extra manuscript reports.

## 7. Interpretation limits
Descriptor thresholds and substructure alerts are computational screening heuristics. Passing a filter does not experimentally establish safety, efficacy, bioavailability or absence of aggregation/toxicity. Report the selected settings and relevant limitations.

## 8. Contact
**Md Fazlay Rabbi**  
Department of Zoology, University of Rajshahi, Bangladesh  
**rabbi.ms244@gmail.com**
"""


# ================== PyQt5 NAVIGATION, FOUR ANALYSIS PAGES, MANUAL, ABOUT ==================
"""Compound Filtering Studio — PyQt5 desktop GUI; launch directly or from VS Code Jupyter.
Developed by Md Fazlay Rabbi.
"""
import sys, os, traceback, json
from pathlib import Path
from functools import partial
# The GUI is an independent process; choose the requested Qt binding here.
# PySide6 is used as a fallback on Windows if PyQt5 cannot start.
_QT_CHOICE = 'PySide6' if getattr(sys, 'frozen', False) else os.environ.get('STUDIO_QT_BINDING','PySide6').strip()
if _QT_CHOICE == 'PySide6':
    from PySide6.QtCore import Qt, QSize, QThread, Signal as pyqtSignal, QUrl, QTimer
    from PySide6.QtGui import QFont, QPixmap, QDesktopServices, QIcon, QColor
    from PySide6.QtWidgets import (
     QApplication, QWidget, QMainWindow, QDialog, QLabel, QPushButton, QHBoxLayout, QVBoxLayout,
     QGridLayout, QGroupBox, QFrame, QFileDialog, QLineEdit, QCheckBox, QDoubleSpinBox,
     QStackedWidget, QListWidget, QListWidgetItem, QPlainTextEdit, QProgressBar,
     QMessageBox, QScrollArea, QTextBrowser, QTableWidget, QTableWidgetItem,
     QHeaderView, QSizePolicy, QSplitter, QAbstractItemView, QComboBox, QSpinBox, QColorDialog
    )
else:
    from PyQt5.QtCore import Qt, QSize, QThread, pyqtSignal, QUrl, QTimer
    from PyQt5.QtGui import QFont, QPixmap, QDesktopServices, QIcon, QColor
    from PyQt5.QtWidgets import (
     QApplication, QWidget, QMainWindow, QDialog, QLabel, QPushButton, QHBoxLayout, QVBoxLayout,
     QGridLayout, QGroupBox, QFrame, QFileDialog, QLineEdit, QCheckBox, QDoubleSpinBox,
     QStackedWidget, QListWidget, QListWidgetItem, QPlainTextEdit, QProgressBar,
     QMessageBox, QScrollArea, QTextBrowser, QTableWidget, QTableWidgetItem,
     QHeaderView, QSizePolicy, QSplitter, QAbstractItemView, QComboBox, QSpinBox, QColorDialog
    )
# Engine functions and configuration classes are defined above, in this same cell.
import pandas as pd

APP_NAME='Compound Filtering & Screening Studio (FR)'
VERSION='1.0'

def studio_fr_asset(filename):
    """Look up bundled assets in development or frozen Windows executable."""
    from pathlib import Path
    import sys
    base = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
    return base / 'Assets' / filename

def studio_fr_icon():
    candidate = studio_fr_asset('FR_Studio.ico')
    return QIcon(str(candidate)) if candidate.is_file() else QIcon()

APP_STYLE='''
QMainWindow { background:#e8edf3; }
QWidget { color:#183149; font-family:"Segoe UI"; font-size:13px; }
QWidget#Body {background:#eef2f6;}
QFrame#Header {background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #17395d,stop:0.58 #1f5488,stop:1 #2d6cab);border:1px solid #315f8c;border-radius:10px;}
QFrame#ToolbarBand {background:#f8fafc;border:1px solid #d1dae5;border-radius:8px;}
QFrame#Sidebar {background:#203a58;border:1px solid #274868;border-radius:9px;}
QFrame#Card {background:#ffffff;border:1px solid #d1dae5;border-radius:9px;}
QFrame#SoftCard {background:#f8fafc;border:1px solid #d5dee9;border-radius:8px;}
QFrame#InfoBand {background:#e9f2fb;border:1px solid #b9cfe4;border-radius:8px;}
QFrame#ProcessMonitor {background:#f8fafc;border:1px solid #c8d4e1;border-radius:9px;}
QLabel#HeaderTitle {color:white;font-size:23px;font-weight:800;background:transparent;}
QLabel#HeaderSubtitle {color:#dceaf7;font-size:12px;font-weight:600;background:transparent;}
QLabel#HeaderCredit {color:#eaf2fa;font-size:11px;font-weight:600;background:transparent;}
QLabel#Headline {font-size:23px;font-weight:800;color:#17395d;}
QLabel#Section {font-size:16px;font-weight:800;color:#17395d;}
QLabel#SubSection {font-size:13px;font-weight:800;color:#275981;}
QLabel#Muted {color:#667d92;font-size:12px;}
QLabel#Criteria {color:#536b81;font-size:11.5px;background:transparent;}
QLabel#Value {font-size:21px;font-weight:800;color:#23649e;}
QLabel#SidebarTitle {color:#ffffff;font-size:13px;font-weight:900;background:transparent;}
QLabel#StatusPill {background:#e8f2fb;color:#1d5d91;border:1px solid #bdd4e8;border-radius:10px;padding:4px 9px;font-weight:800;font-size:10px;}
QLabel#StatusPill[state="done"] {background:#e7f6ef;color:#0d7252;border:1px solid #9fd5c1;}
QLabel#StatusPill[state="running"] {background:#fff4db;color:#8d6200;border:1px solid #e6c66f;}
QLineEdit,QPlainTextEdit,QTextBrowser,QTableWidget,QListWidget {background:#ffffff;border:1px solid #cbd6e2;border-radius:6px;padding:7px;selection-background-color:#2f6fae;selection-color:white;}
QLineEdit:focus,QPlainTextEdit:focus,QTextBrowser:focus,QTableWidget:focus,QListWidget:focus {border:1px solid #2f6fae;}
QTextBrowser {padding:14px;}
QPushButton {background:#2f6fae;color:white;border:1px solid #285f95;border-radius:6px;padding:9px 14px;font-weight:800;font-size:12px;}
QPushButton:hover {background:#255f98;}
QPushButton:pressed {background:#1b4d7f;}
QPushButton:disabled {background:#ccd6df;color:#7d8d9c;border-color:#c2ccd6;}
QPushButton#Success {background:#0f7c5c;border-color:#0b684d;}
QPushButton#Success:hover {background:#0a684c;}
QPushButton#Purple {background:#5b4a97;border-color:#4d3d82;}
QPushButton#Grey {background:#566d84;border-color:#485d71;}
QPushButton#HeaderGuide {background:#285f9a;color:#ffffff;font-weight:800;font-size:11px;border:1px solid #ffffff;border-radius:7px;min-width:80px;min-height:28px;padding:5px 8px;}
QPushButton#HeaderGuide:hover {background:#174874;color:#ffffff;}
QPushButton#HeaderAbout {background:#285f9a;color:#ffffff;font-weight:800;font-size:11px;border:1px solid #ffffff;border-radius:7px;min-width:70px;min-height:28px;padding:5px 8px;}
QPushButton#HeaderAbout:hover {background:#174874;color:#ffffff;}
QPushButton#Nav {background:transparent;border:1px solid transparent;text-align:left;color:#ffffff;border-radius:6px;padding:13px 12px;font-size:15px;font-weight:800;}
QPushButton#Nav:hover {background:#294d73;border-color:#365b80;}
QPushButton#Nav[active="true"] {background:#3475b8;color:#ffffff;border-color:#4586c7;}
QPushButton#FilterSwitch {background:#e7edf3;color:#536b81;border:1px solid #c9d4df;border-radius:12px;padding:5px 11px;min-width:86px;font-size:10.5px;font-weight:900;}
QPushButton#FilterSwitch:checked {background:#1f75b6;color:white;border-color:#1a649c;}
QPushButton#FilterSwitch:disabled {background:#dcecf8;color:#155b8d;border-color:#a9c7df;}
QFrame#FilterToggle {background:#fbfcfe;border:1px solid #d3dde7;border-radius:8px;}
QFrame#FilterToggle[selected="true"] {background:#eef6fd;border:2px solid #3a7fbb;}
QFrame#FilterToggle[selected="false"] {background:#f8f9fb;border:1px solid #d8e0e8;}
QLabel#FilterTitle {font-size:13px;font-weight:800;color:#183d61;background:transparent;}
QProgressBar {background:#dbe3ec;border:1px solid #bfcbd8;border-radius:8px;color:#143550;text-align:center;font-weight:900;font-size:11px;min-height:25px;}
QProgressBar::chunk {background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #2f6fae,stop:.55 #20a0b5,stop:1 #0f8064);border-radius:7px;}
QScrollArea {border:0;background:transparent;}
QTableWidget {gridline-color:#e2e7ed;alternate-background-color:#f7f9fb;}
QTableWidget::item {padding:6px;}
QHeaderView::section {background:#e7edf4;color:#173e63;font-weight:900;padding:8px;border:0;border-bottom:1px solid #c7d3df;}
QListWidget::item {padding:7px;border-bottom:1px solid #edf1f5;}
QListWidget::item:selected {background:#dfeefb;color:#17395d;border-left:3px solid #2f6fae;}
QSplitter::handle {background:#d8e0e8;width:2px;}
QDoubleSpinBox {background:#ffffff;color:#101820;border:2px solid #728ea9;border-radius:5px;padding:6px 5px;font-size:14px;font-weight:800;min-height:27px;}
QDoubleSpinBox QLineEdit {background:#ffffff;color:#101820;selection-background-color:#b2d5fa;selection-color:#101820;}
QDoubleSpinBox::up-button,QDoubleSpinBox::down-button {background:#dce8f4;width:17px;border-left:1px solid #adc3da;}
QTextBrowser a {color:#101820;}

/* Keep designer fields legible even when Windows is in Dark mode. */
QComboBox, QSpinBox, QDoubleSpinBox {
  background-color:#ffffff; color:#12263d; border:2px solid #839db7;
  border-radius:6px; min-height:33px; padding:4px 8px;
  font-family:"Segoe UI"; font-size:14px; font-weight:800;
  selection-background-color:#cbe5fd; selection-color:#12263d;
}
QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover {border:2px solid #3477b4;}
QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {border:2px solid #215e97;}
QComboBox QAbstractItemView, QAbstractItemView {
  background:#ffffff; color:#172d45; border:1px solid #849cb3;
  selection-background-color:#dceeff; selection-color:#112b45;
  font-size:13px; font-weight:700; outline:none;
}
QComboBox::drop-down { background:#e5eef7; border-left:1px solid #9bb2c8; width:23px; }
QComboBox::down-arrow { width:0px; height:0px; border-left:5px solid transparent;
                         border-right:5px solid transparent; border-top:6px solid #214b74; }
QSpinBox QLineEdit, QDoubleSpinBox QLineEdit {
  background:#ffffff; color:#12263d; border:0px; font-size:14px; font-weight:800;
  selection-background-color:#cbe5fd; selection-color:#12263d;
}
QSpinBox::up-button, QSpinBox::down-button,
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {
  background:#e5eef7; border-left:1px solid #9bb2c8; width:20px;
}
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow {
  width:0px;height:0px;border-left:5px solid transparent;
  border-right:5px solid transparent;border-bottom:6px solid #214b74;
}
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow {
  width:0px;height:0px;border-left:5px solid transparent;
  border-right:5px solid transparent;border-top:6px solid #214b74;
}


'''


# -----------------------------------------------------------------------------
# ACCESSIBLE, THEME-INDEPENDENT APPLICATION NOTIFICATIONS
# The Windows dark palette may style a native QMessageBox almost black while
# APP_STYLE gives its labels dark-blue text.  We intentionally use an explicitly
# styled Qt QDialog for every confirmation, warning, success and error message.
# This is intentionally separate from the scientific filtering algorithms.
# -----------------------------------------------------------------------------
_NOTICE_QSS = """
QDialog#StudioNotice { background-color:#f8fafc; color:#183149;
                       border:1px solid #d1dbe7; }
QLabel#NoticeHeading { color:#142d48; background:transparent;
                       font-family:'Segoe UI'; font-size:18px; font-weight:800; }
QLabel#NoticeBody { color:#23384d; background:transparent;
                    font-family:'Segoe UI'; font-size:14px; font-weight:500; }
QLabel#NoticeIcon { color:#ffffff; font-family:'Segoe UI'; font-size:22px;
                    font-weight:900; border-radius:21px; }
QPlainTextEdit#NoticeDetails { background-color:#ffffff; color:#142638;
                border:1px solid #b9cbdd; border-radius:7px;
                font:12px 'Consolas'; padding:9px;
                selection-background-color:#c5e1fa; selection-color:#142638; }
QPushButton#NoticePrimary { color:#ffffff; background-color:#245f9d;
                border:1px solid #1c507f; border-radius:7px; padding:9px 20px;
                font-family:'Segoe UI'; font-size:13px; font-weight:800;
                min-height:24px; min-width:94px; }
QPushButton#NoticePrimary:hover { background-color:#1b4f84; }
QPushButton#NoticePrimary:focus { border:2px solid #102f52; }
QPushButton#NoticeSecondary { background-color:#ffffff; color:#17395d;
                border:1px solid #8da8c0; border-radius:7px; padding:9px 20px;
                font-family:'Segoe UI'; font-size:13px; font-weight:800;
                min-height:24px; min-width:94px; }
QPushButton#NoticeSecondary:hover { background-color:#e8f2fb; }
QPushButton#NoticeSecondary:focus { border:2px solid #245f9d; }
"""

class StudioNotice(QDialog):
    """Accessible modal dialog with consistent light background and dark text."""
    def __init__(self, parent, title, message, kind='information'):
        super().__init__(parent)
        self.setObjectName('StudioNotice')
        self.setWindowTitle(str(title))
        self.setModal(True)
        self.setMinimumWidth(540)
        self.setMaximumWidth(740)
        self.setStyleSheet(_NOTICE_QSS)
        self.setAttribute(Qt.WA_StyledBackground, True)
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 21, 24, 20)
        root.setSpacing(16)

        icon_bg = {'question':'#256eb1', 'warning':'#b37b16',
                   'critical':'#b54248', 'information':'#16816c'}
        icon_txt = {'question':'?', 'warning':'!',
                    'critical':'!', 'information':'i'}
        heading = QHBoxLayout()
        heading.setSpacing(14)
        icon = QLabel(icon_txt.get(kind,'i'))
        icon.setObjectName('NoticeIcon')
        icon.setAlignment(Qt.AlignCenter)
        icon.setFixedSize(42, 42)
        icon.setStyleSheet('QLabel#NoticeIcon { background-color:%s; color:#ffffff; '
                           'font-size:22px; font-weight:900; border-radius:21px; }'
                           % icon_bg.get(kind,'#256eb1'))
        heading.addWidget(icon)
        name = QLabel(str(title))
        name.setObjectName('NoticeHeading')
        name.setWordWrap(True)
        heading.addWidget(name, 1)
        root.addLayout(heading)

        text = str(message)
        if len(text) > 360 or text.count('\n') > 6:
            summary = QLabel('Details are shown below. You can scroll and copy the full message.')
            summary.setObjectName('NoticeBody')
            summary.setWordWrap(True)
            root.addWidget(summary)
            details = QPlainTextEdit()
            details.setObjectName('NoticeDetails')
            details.setReadOnly(True)
            details.setPlainText(text)
            details.setFixedHeight(180)
            root.addWidget(details)
        else:
            body = QLabel(text)
            body.setObjectName('NoticeBody')
            body.setWordWrap(True)
            body.setTextFormat(Qt.PlainText)
            body.setMinimumWidth(440)
            root.addWidget(body)

        actions = QHBoxLayout()
        actions.setSpacing(10)
        if kind == 'critical' or len(text) > 360:
            copy_btn = QPushButton('Copy details')
            copy_btn.setObjectName('NoticeSecondary')
            copy_btn.clicked.connect(lambda: QApplication.clipboard().setText(text))
            actions.addWidget(copy_btn)
        actions.addStretch(1)
        if kind == 'question':
            cancel = QPushButton('Cancel')
            cancel.setObjectName('NoticeSecondary')
            cancel.clicked.connect(self.reject)
            cancel.setDefault(True)  # Never accidentally begin filtering with Enter.
            actions.addWidget(cancel)
            proceed = QPushButton('Continue')
            proceed.setObjectName('NoticePrimary')
            proceed.setAutoDefault(False)
            proceed.clicked.connect(self.accept)
            actions.addWidget(proceed)
            cancel.setFocus()
        else:
            ok = QPushButton('OK')
            ok.setObjectName('NoticePrimary')
            ok.clicked.connect(self.accept)
            ok.setDefault(True)
            actions.addWidget(ok)
            ok.setFocus()
        root.addLayout(actions)

    def ask(self):
        runner = self.exec if hasattr(self, 'exec') else self.exec_
        return runner() == QDialog.Accepted


def studio_question(parent, title, message):
    return StudioNotice(parent, title, message, 'question').ask()


def studio_warning(parent, title, message):
    StudioNotice(parent, title, message, 'warning').ask()


def studio_information(parent, title, message):
    StudioNotice(parent, title, message, 'information').ask()


def studio_error(parent, title, message):
    StudioNotice(parent, title, message, 'critical').ask()



def label(text,kind=None,wrap=False):
    w=QLabel(str(text));w.setWordWrap(wrap)
    if kind:w.setObjectName(kind)
    return w


def card(layout=None,object_name='Card'):
    frame=QFrame();frame.setObjectName(object_name);lay=QVBoxLayout(frame);lay.setContentsMargins(16,14,16,14);lay.setSpacing(9)
    if layout:lay.addLayout(layout)
    return frame,lay


def vertical_page():
    wrap=QScrollArea();wrap.setWidgetResizable(True);wrap.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    inner=QWidget();inner.setObjectName('Body');lay=QVBoxLayout(inner);lay.setContentsMargins(14,14,14,16);lay.setSpacing(13);wrap.setWidget(inner)
    return wrap,lay


class FilterToggle(QFrame):
    def __init__(self,title,criterion,checked=True,locked=False,parent=None):
        super().__init__(parent);self.setObjectName('FilterToggle');self._locked=locked
        lay=QVBoxLayout(self);lay.setContentsMargins(11,9,11,9);lay.setSpacing(6)
        top=QHBoxLayout();top.setSpacing(8);top.addWidget(label(title,'FilterTitle',True),1)
        self.switch=QPushButton();self.switch.setObjectName('FilterSwitch');self.switch.setCheckable(True);self.switch.setChecked(bool(checked));self.switch.setEnabled(not locked);self.switch.toggled.connect(self._sync);top.addWidget(self.switch);lay.addLayout(top)
        self.criteria=label(criterion,'Criteria',True);lay.addWidget(self.criteria);self.setToolTip(('Mandatory. ' if locked else '')+criterion);self._sync(self.switch.isChecked())
    def _sync(self,checked):
        self.setProperty('selected','true' if checked else 'false');self.switch.setText('✓  APPLIED' if checked else '—  SKIPPED');self.style().unpolish(self);self.style().polish(self)
    def isChecked(self):return bool(self.switch.isChecked())
    def setChecked(self,value):self.switch.setChecked(bool(value))
    def setEnabled(self,value):self.switch.setEnabled(False if self._locked else bool(value))
    def setToolTip(self,text):
        super().setToolTip(text)
        if hasattr(self,'switch'):self.switch.setToolTip(text)


class Worker(QThread):
    progress=pyqtSignal(int,str,str,object);finished_ok=pyqtSignal(object,object);error=pyqtSignal(str)
    def __init__(self,source,config,upto,previous_df=None,previous_manifest=None,parent=None,start_part=1):
        super().__init__(parent);self.source=source;self.config=config;self.upto=upto;self.previous_df=previous_df;self.previous_manifest=previous_manifest;self.start_part=start_part
    def run(self):
        try:
            manifest,df=analyze_documented(self.source,self.config,progress=lambda p,s,d,percent:self.progress.emit(p,str(s),str(d),percent),upto=self.upto,existing_data=self.previous_df,existing_dir=(self.previous_manifest or {}).get('project_dir'),previous_manifest=self.previous_manifest,start_part=self.start_part);self.finished_ok.emit(manifest,df)
        except Exception:self.error.emit(traceback.format_exc())


class StagePage(QWidget):
    def __init__(self,number,parent=None):
        super().__init__(parent);self.number=number;self.controls={};self.summary=label('Not run yet.','Muted');self.stats=QTableWidget(0,4);self.project_dir=None
        main=QVBoxLayout(self);main.setContentsMargins(0,0,0,0);scroll,lay=vertical_page();main.addWidget(scroll);title,opts=PARTS[number]
        hero,hl=card(object_name='ToolbarBand');top=QHBoxLayout();top.addWidget(label(f'PART {number:02d}','StatusPill'));top.addWidget(label(title,'Headline'),1);self.stage_state=label('READY','StatusPill');top.addWidget(self.stage_state);hl.addLayout(top)
        texts={1:'Prepare and standardize the input library using the supplied molecular-processing sequence.',2:'Calculate molecular descriptors from original input SMILES and apply the selected property-based rules.',3:'Screen retained structures through RDKit BRENK, NIH and PAINS medicinal-chemistry catalogs.',4:'Apply the bundled unwanted SMARTS list and the supplied scaffold, aggregation, toxicophore and reactive-group screens.'};hl.addWidget(label(texts[number],'Muted',True));lay.addWidget(hero)
        f,fl=card();hdr=QHBoxLayout();hdr.addWidget(label('Screening criteria','Section'));hdr.addStretch();hdr.addWidget(label('Click APPLIED / SKIPPED to change a criterion','Muted'));fl.addLayout(hdr)
        grid=QGridLayout();grid.setHorizontalSpacing(11);grid.setVerticalSpacing(10)
        for i,(key,text_) in enumerate(opts):
            criterion=FILTER_CRITERIA.get(number,{}).get(key,'');toggle=FilterToggle(text_,criterion,True,number==1 and key=='parsing');grid.addWidget(toggle,i//2,i%2);self.controls[key]=toggle
        fl.addLayout(grid)
        if number==1:
            row=QHBoxLayout();row.addWidget(label('Target ionization pH','SubSection'));self.ph=QDoubleSpinBox();self.ph.setRange(0,14);self.ph.setDecimals(1);self.ph.setSingleStep(.1);self.ph.setValue(7.4);self.ph.setFixedWidth(110);self.ph.setStyleSheet('QDoubleSpinBox{background-color:white;color:black;font-weight:900;font-size:15px;border:2px solid #6086a8;border-radius:5px;padding:5px;} QDoubleSpinBox QLineEdit{background:white;color:black;}');row.addWidget(self.ph);row.addWidget(label('Used only when pH-dependent ionization is APPLIED.','Muted'));row.addStretch();fl.addLayout(row)
        if number==4:fl.addWidget(label(f'Bundled reference: {curated_csv_path().name} • 104 SMARTS rows','Muted'))
        lay.addWidget(f)
        runband,rb=card(object_name='InfoBand');row=QHBoxLayout();self.run_button=QPushButton(f'Run Part {number}');self.run_button.setObjectName('Success');row.addWidget(self.run_button);row.addWidget(self.summary,1);rb.addLayout(row);lay.addWidget(runband)
        box,body=card();h=QHBoxLayout();h.addWidget(label('Filter-level results','Section'));h.addStretch();h.addWidget(label('Exact before / excluded / retained counts','Muted'));body.addLayout(h);self.stats.setHorizontalHeaderLabels(['Filter','Status','Excluded','Retained']);self.stats.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);self.stats.setEditTriggers(QAbstractItemView.NoEditTriggers);self.stats.setAlternatingRowColors(True);self.stats.setMinimumHeight(190);body.addWidget(self.stats);lay.addWidget(box)
        gallery,gb=card();h=QHBoxLayout();h.addWidget(label('Publication Figure Browser','Section'));h.addStretch();h.addWidget(label('ORIGINAL + STUDIO sets','Muted'));self.recommended_only=QCheckBox('Show recommended figures only')
        self.recommended_only.setChecked(True)
        self.recommended_only.toggled.connect(self._refresh_gallery)
        h.addWidget(self.recommended_only)
        gb.addLayout(h);split=QSplitter(Qt.Horizontal);self.gallery=QListWidget();self.gallery.setMaximumWidth(300);self.gallery.setMinimumWidth(220);self.viewer=QLabel('Figures will appear here after this Part finishes.');self.viewer.setAlignment(Qt.AlignCenter);self.viewer.setWordWrap(True);self.viewer.setStyleSheet('background:#f7f9fc;border:1px solid #d1dbe5;border-radius:8px;color:#687e91;padding:10px;');self.viewer.setMinimumHeight(320);self.viewer.setMaximumHeight(500);split.addWidget(self.gallery);split.addWidget(self.viewer);split.setStretchFactor(1,1);gb.addWidget(split);lay.addWidget(gallery);self.gallery.currentTextChanged.connect(self.preview);lay.addStretch()
    def selected_filters(self):return {k:v.isChecked() for k,v in self.controls.items()}
    def populate(self,stage,root):
        self.project_dir=Path(root);self.stage_state.setText('COMPLETE');self.stage_state.setProperty('state','done');self.stage_state.style().unpolish(self.stage_state);self.stage_state.style().polish(self.stage_state);self.summary.setText(f"{stage['input']:,} input → {stage['output']:,} retained • {stage['removed']:,} excluded • {stage.get('seconds_elapsed',0):.1f} s")
        rows=stage['steps'];self.stats.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,value in enumerate((r['filter'].replace('_',' ').title(),'APPLIED' if r['applied'] else 'SKIPPED',f"{r['removed']:,}",f"{r['remaining']:,}")):
                item=QTableWidgetItem(value)
                if j==1:item.setForeground(QColor('#0f7657') if r['applied'] else QColor('#8a6a28'));fnt=item.font();fnt.setBold(True);item.setFont(fnt)
                self.stats.setItem(i,j,item)
        self._refresh_gallery()
    def _refresh_gallery(self):
        self.gallery.clear()
        if self.project_dir is None:return
        plots=sorted((self.project_dir/FOLDER_NAMES[self.number]/'figures').rglob('*.png'))
        recommended={
            1:('01_enhanced_filtering_funnel','02_step_analysis','05_comprehensive_dashboard','filtering_cascade'),
            2:('panel_filtering_cascade','panel_hist_MW','panel_hist_LogP','panel_druglikeness_space','panel_pfizer_rule_space','filtering_cascade'),
            3:(),  # Brenk/NIH/PAINS: keep all original figures unchanged
            4:('filtering_cascade','filter_summary','final_summary','pattern_analysis'),
        }
        for p in plots:
            is_original='original_notebook_figures' in p.parts
            if self.recommended_only.isChecked() and self.number!=3:
                if not is_original:continue
                if not any(p.stem.lower().startswith(k.lower()) for k in recommended[self.number]):continue
            prefix='ORIGINAL' if is_original else 'STUDIO'
            item=QListWidgetItem(prefix+'  |  '+p.stem.replace('_',' ').title())
            item.setForeground(QColor('#0f7657') if is_original else QColor('#245f9f'))
            item.setData(Qt.UserRole,str(p));self.gallery.addItem(item)
        if self.gallery.count():self.gallery.setCurrentRow(0)

    def preview(self,unused=''):
        item=self.gallery.currentItem()
        if item is None:return
        img=QPixmap(item.data(Qt.UserRole))
        if img.isNull():self.viewer.setText('Unable to preview figure.');return
        self.viewer.setPixmap(img.scaled(QSize(830,460),Qt.KeepAspectRatio,Qt.SmoothTransformation))


class Studio(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle(f'{APP_NAME} — {VERSION}');self.setWindowIcon(studio_fr_icon());self.resize(1480,930);self.setMinimumSize(1120,760);self.manifest=None;self.last_output=None;self.worker=None;self._run_started=None;self._elapsed_timer=QTimer(self);self._elapsed_timer.timeout.connect(self._update_elapsed);self._setup()
    def _setup(self):
        central=QWidget();self.setCentralWidget(central);root=QVBoxLayout(central);root.setContentsMargins(10,10,10,8);root.setSpacing(9)
        top=QFrame();top.setObjectName('Header')
        tl=QGridLayout(top);tl.setContentsMargins(15,11,15,9);tl.setHorizontalSpacing(6)
        actions=QWidget();actions.setStyleSheet('background:transparent;')
        ar=QHBoxLayout(actions);ar.setContentsMargins(0,0,0,0);ar.setSpacing(7)
        guide_btn=QPushButton('USER GUIDE');guide_btn.setObjectName('HeaderGuide');guide_btn.setFixedHeight(34)
        guide_btn.clicked.connect(lambda:self.navigate(6))
        about_btn=QPushButton('ABOUT US');about_btn.setObjectName('HeaderAbout');about_btn.setFixedHeight(34)
        about_btn.clicked.connect(lambda:self.navigate(7))
        ar.addWidget(guide_btn);ar.addWidget(about_btn)
        actions.setFixedWidth(218)
        left_spacer=QWidget();left_spacer.setFixedWidth(218);left_spacer.setStyleSheet('background:transparent;')
        fr_logo_layout=QHBoxLayout(left_spacer);fr_logo_layout.setContentsMargins(6,0,0,0)
        fr_logo=QLabel();fr_logo.setStyleSheet('background:transparent; border:0px;')
        fr_logo_path=studio_fr_asset('FR_Studio_Logo.png')
        if fr_logo_path.is_file():
            fr_pix=QPixmap(str(fr_logo_path))
            fr_logo.setPixmap(fr_pix.scaled(QSize(78,78),Qt.KeepAspectRatio,Qt.SmoothTransformation))
        fr_logo_layout.addWidget(fr_logo);fr_logo_layout.addStretch()
        main_title=QWidget();main_title.setStyleSheet('background:transparent;')
        title_layout=QVBoxLayout(main_title);title_layout.setContentsMargins(0,1,0,1);title_layout.setSpacing(3)
        title_lbl=label('COMPOUND FILTERING & SCREENING STUDIO','HeaderTitle')
        title_lbl.setAlignment(Qt.AlignCenter)
        subtitle_lbl=label('Molecular preparation  •  property filtering  •  medicinal chemistry  •  structural screening','HeaderSubtitle')
        subtitle_lbl.setAlignment(Qt.AlignCenter)
        title_layout.addWidget(title_lbl);title_layout.addWidget(subtitle_lbl)
        tl.addWidget(left_spacer,0,0);tl.addWidget(main_title,0,1);tl.addWidget(actions,0,2)
        credit=label('Developed by FR (Md Fazlay Rabbi)  |  Department of Zoology, University of Rajshahi  |  rabbi.ms244@gmail.com','HeaderCredit')
        credit.setAlignment(Qt.AlignCenter)
        tl.addWidget(credit,1,0,1,3);tl.setColumnStretch(1,1)
        root.addWidget(top)
        contents=QHBoxLayout();contents.setSpacing(9);root.addLayout(contents,1);side=QFrame();side.setObjectName('Sidebar');side.setFixedWidth(235);snav=QVBoxLayout(side);snav.setContentsMargins(11,14,11,12);snav.setSpacing(4);snav.addWidget(label('WORKFLOW EXPLORER','SidebarTitle'));self.stack=QStackedWidget();self.nav=[];names=['Project Workspace','01  Molecular Preparation','02  Property Filtering','03  BRENK / NIH / PAINS','04  Structural Screening','Results & Reports']
        for i,name in enumerate(names):
            btn=QPushButton(name);btn.setObjectName('Nav');btn.setProperty('active',i==0);btn.clicked.connect(partial(self.navigate,i));snav.addWidget(btn);self.nav.append(btn)
        snav.addStretch();contents.addWidget(side);contents.addWidget(self.stack,1)
        self.stack.addWidget(self._overview());self.stage_pages={}
        for p in range(1,5):
            page=StagePage(p);page.run_button.clicked.connect(partial(self.run_stage,p));self.stage_pages[p]=page;self.stack.addWidget(page)
        self.summary_page=self._summary();self.stack.addWidget(self.summary_page);self.stack.addWidget(self._manual());self.stack.addWidget(self._about())
        footer=QFrame();footer.setObjectName('ProcessMonitor');fr=QVBoxLayout(footer);fr.setContentsMargins(11,7,11,7);fr.setSpacing(5);upper=QHBoxLayout();upper.addWidget(label('PROCESS MONITOR','SidebarTitle'));self.status=label('Ready — select a compound CSV and review the screening criteria.','Muted');upper.addWidget(self.status,1);self.counter=label('0 / 0','SubSection');upper.addWidget(self.counter);self.speed=label('— cmp/s','Muted');upper.addWidget(self.speed);self.elapsed=label('Elapsed 00:00','Muted');upper.addWidget(self.elapsed);fr.addLayout(upper);self.progress=QProgressBar();self.progress.setRange(0,100);self.progress.setValue(0);self.progress.setFormat('0%  •  Ready');fr.addWidget(self.progress);root.addWidget(footer);self.navigate(0)
    def _overview(self):
        page,lay=vertical_page();hero,hl=card(object_name='ToolbarBand');hl.addWidget(label('Project Workspace','Headline'));hl.addWidget(label('Configure one compound library, review all screening criteria, then run the complete four-stage workflow.','Muted',True));lay.addWidget(hero)
        grid=QGridLayout();grid.setHorizontalSpacing(10);box,b=card();b.addWidget(label('1. Input Compound Library','Section'));r=QHBoxLayout();self.input_file=QLineEdit();self.input_file.setPlaceholderText('CSV containing SMILES and compound names');self.input_file.textChanged.connect(lambda t:self._show_input_preview(t));choose=QPushButton('Browse CSV');choose.clicked.connect(self.choose_csv);r.addWidget(self.input_file,1);r.addWidget(choose);b.addLayout(r);self.input_info=label('No input file loaded.','Muted',True);b.addWidget(self.input_info);grid.addWidget(box,0,0)
        outbox,ob=card();ob.addWidget(label('2. Results & Report Location','Section'));r=QHBoxLayout();self.output_file=QLineEdit(str(Path.home()/'Documents'/'Compound_Studio_Results'));ch=QPushButton('Browse Folder');ch.setObjectName('Grey');ch.clicked.connect(self.choose_output);r.addWidget(self.output_file,1);r.addWidget(ch);ob.addLayout(r);ob.addWidget(label('A timestamped project folder and ZIP archive will be created automatically.','Muted',True));grid.addWidget(outbox,0,1);lay.addLayout(grid)
        info,ib=card(object_name='InfoBand');line=QHBoxLayout();line.addWidget(label('Publication output','SubSection'));line.addWidget(label('Original figures, selected-filter plots and two manuscript reports (Methods.txt and Results.txt).','Muted',True),1);ib.addLayout(line);lay.addWidget(info)
        actions,ab=card();row=QHBoxLayout();self.run_all=QPushButton('Run Complete Pipeline   1 → 2 → 3 → 4');self.run_all.setObjectName('Success');self.run_all.clicked.connect(self.run_everything);self.export_zip=QPushButton('Open Result ZIP');self.export_zip.setObjectName('Purple');self.export_zip.clicked.connect(self.open_zip);self.export_zip.setEnabled(False);row.addWidget(self.run_all);row.addWidget(self.export_zip);row.addStretch();ab.addLayout(row);lay.addWidget(actions)
        panels,pl=card();pl.addWidget(label('Workflow Map','Section'));cards=QGridLayout();cards.setHorizontalSpacing(10);cards.setVerticalSpacing(10);subtitles={1:'Parse • prepare • ionize • deduplicate',2:'Descriptors • drug-likeness • REOS',3:'BRENK • NIH • PAINS catalogs',4:'SMARTS • scaffolds • alerts'}
        for idx,(key,(name,opts)) in enumerate(PARTS.items()):
            w=QFrame();w.setObjectName('SoftCard');v=QVBoxLayout(w);v.setContentsMargins(13,11,13,11);head=QHBoxLayout();head.addWidget(label(f'PART {key:02d}','StatusPill'));head.addStretch();head.addWidget(label('READY','Muted'));v.addLayout(head);v.addWidget(label(name,'Section',True));v.addWidget(label(subtitles[key],'Muted',True));v.addWidget(label(f'{len(opts)} selectable criteria','Muted'));cards.addWidget(w,idx//2,idx%2)
        pl.addLayout(cards);lay.addWidget(panels);logs,lb=card();h=QHBoxLayout();h.addWidget(label('Live Analysis Log','Section'));h.addStretch();h.addWidget(label('Milestones, saved files and warnings','Muted'));lb.addLayout(h);self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.setMinimumHeight(150);self.log.setMaximumHeight(230);lb.addWidget(self.log);lay.addWidget(logs);lay.addStretch();return page
    def _summary(self):
        page,lay=vertical_page();hero,hl=card(object_name='ToolbarBand');hl.addWidget(label('Results & Reports','Headline'));hl.addWidget(label('Filter counts, run timing and manuscript-support outputs from the completed analysis.','Muted',True));lay.addWidget(hero);f,fl=card();self.final_card=label('No analysis completed yet.','Section',True);fl.addWidget(self.final_card);self.final_table=QTableWidget(0,6);self.final_table.setHorizontalHeaderLabels(['Part','Analysis','Input','Excluded','Retained','Time (s)']);self.final_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);self.final_table.setAlternatingRowColors(True);fl.addWidget(self.final_table);buttons=QHBoxLayout();open_proj=QPushButton('Open Output Folder');open_proj.clicked.connect(self.open_folder);get_zip=QPushButton('Open Combined ZIP');get_zip.setObjectName('Purple');get_zip.clicked.connect(self.open_zip);buttons.addWidget(open_proj);buttons.addWidget(get_zip);buttons.addStretch();fl.addLayout(buttons);lay.addWidget(f);f2,b=card();b.addWidget(label('Results — Applied Filters Only','Section'));self.summary_text=QPlainTextEdit();self.summary_text.setReadOnly(True);self.summary_text.setMinimumHeight(300);b.addWidget(self.summary_text);lay.addWidget(f2);overall_card,overall_layout=card()
        overall_layout.addWidget(label('Overall Applied-Filter Cascade','Section'))
        overall_layout.addWidget(label('Editable orange figure • colors, dimensions, font sizes and bar width adapted from the supplied Cheminformatics Visualizer. Only applied filters are shown.','Muted',True))
        controls=QGridLayout();controls.setSpacing(8)
        self.chart_type=QComboBox();self.chart_type.addItems(['Vertical orange bars','Gradient bars','Horizontal bars'])
        self.chart_color=QLineEdit('#BD5C19');self.chart_color.setFixedWidth(105)
        choose_color=QPushButton('Choose Color');choose_color.clicked.connect(self.choose_chart_color)
        self.chart_width=QDoubleSpinBox();self.chart_width.setRange(7,40);self.chart_width.setDecimals(1);self.chart_width.setValue(14.0);self.chart_width.setSuffix(' in')
        self.chart_height=QDoubleSpinBox();self.chart_height.setRange(4.5,25);self.chart_height.setDecimals(1);self.chart_height.setValue(8.2);self.chart_height.setSuffix(' in')
        self.chart_bar_width=QDoubleSpinBox();self.chart_bar_width.setRange(.25,.95);self.chart_bar_width.setSingleStep(.05);self.chart_bar_width.setValue(.73)
        self.chart_title_fs=QSpinBox();self.chart_title_fs.setRange(10,32);self.chart_title_fs.setValue(17)
        self.chart_axis_fs=QSpinBox();self.chart_axis_fs.setRange(9,30);self.chart_axis_fs.setValue(15)
        self.chart_tick_fs=QSpinBox();self.chart_tick_fs.setRange(7,25);self.chart_tick_fs.setValue(11)
        self.chart_value_fs=QSpinBox();self.chart_value_fs.setRange(7,25);self.chart_value_fs.setValue(11)
        self.chart_rotation=QSpinBox();self.chart_rotation.setRange(0,90);self.chart_rotation.setValue(58)
        # Explicit editor and popup palettes prevent black-on-dark text in Windows Dark mode.
        self.chart_type.setStyleSheet(
            'QComboBox {background:#ffffff; color:#12263d; border:2px solid #839db7;'
            'border-radius:6px; min-height:34px; padding:4px 9px; font-weight:800;}'
            'QComboBox::drop-down {background:#e5eef7; border-left:1px solid #9bb2c8; width:24px;}'
            'QComboBox QAbstractItemView {background:#ffffff; color:#12263d;'
            'selection-background-color:#dceeff; selection-color:#12263d;}'
        )
        self.chart_type.setMinimumWidth(205)
        self.chart_type.view().setStyleSheet(
            'QListView {background:#ffffff;color:#12263d;'
            'selection-background-color:#dceeff;selection-color:#12263d;font-weight:700;}'
        )
        self.chart_color.setStyleSheet(
            'QLineEdit {background:#ffffff;color:#12263d;'
            'border:2px solid #839db7;border-radius:6px;min-height:34px;font-weight:800;}'
        )
        for w in (self.chart_width,self.chart_height,self.chart_bar_width,
                  self.chart_title_fs,self.chart_axis_fs,self.chart_tick_fs,
                  self.chart_value_fs,self.chart_rotation):
            w.setStyleSheet(
                'QSpinBox,QDoubleSpinBox {background:#ffffff;color:#12263d;'
                'border:2px solid #839db7;border-radius:6px;min-height:34px;'
                'font-weight:800;font-size:14px;}'
                'QSpinBox QLineEdit,QDoubleSpinBox QLineEdit {'
                'background:#ffffff;color:#12263d;border:0px;font-weight:800;}'
                'QSpinBox::up-button,QSpinBox::down-button,'
                'QDoubleSpinBox::up-button,QDoubleSpinBox::down-button {'
                'background:#e5eef7;border-left:1px solid #9bb2c8;width:19px;}'
            )
            editor=w.findChild(QLineEdit)
            if editor is not None:
                editor.setStyleSheet(
                    'QLineEdit {background:#ffffff;color:#12263d;'
                    'border:0px;font-size:14px;font-weight:800;'
                    'selection-background-color:#cbe5fd;selection-color:#12263d;}'
                )
        controls.addWidget(label('Chart type','SubSection'),0,0);controls.addWidget(self.chart_type,0,1)
        controls.addWidget(label('Bar color','SubSection'),0,2);cl=QHBoxLayout();cl.addWidget(self.chart_color);cl.addWidget(choose_color);controls.addLayout(cl,0,3)
        controls.addWidget(label('Figure width','SubSection'),1,0);controls.addWidget(self.chart_width,1,1)
        controls.addWidget(label('Figure height','SubSection'),1,2);controls.addWidget(self.chart_height,1,3)
        controls.addWidget(label('Title font','SubSection'),2,0);controls.addWidget(self.chart_title_fs,2,1)
        controls.addWidget(label('Axis font','SubSection'),2,2);controls.addWidget(self.chart_axis_fs,2,3)
        controls.addWidget(label('Tick font','SubSection'),3,0);controls.addWidget(self.chart_tick_fs,3,1)
        controls.addWidget(label('Value font','SubSection'),3,2);controls.addWidget(self.chart_value_fs,3,3)
        controls.addWidget(label('Bar width','SubSection'),4,0);controls.addWidget(self.chart_bar_width,4,1)
        controls.addWidget(label('X label angle','SubSection'),4,2);controls.addWidget(self.chart_rotation,4,3)
        overall_layout.addLayout(controls)
        apply_btn=QPushButton('Apply Figure Design & Update ZIP');apply_btn.setObjectName('Success');apply_btn.clicked.connect(self.update_overall_chart)
        overall_layout.addWidget(apply_btn)
        self.overall_figure=QLabel('The overall applied-only figure will appear after analysis.')
        self.overall_figure.setAlignment(Qt.AlignCenter);self.overall_figure.setMinimumHeight(320)
        overall_layout.addWidget(self.overall_figure)
        lay.addWidget(overall_card);lay.addStretch();return page
    def _manual(self):
        page,lay=vertical_page();hero,hl=card(object_name='ToolbarBand');hl.addWidget(label('User Guide','Headline'));hl.addWidget(label('Step-by-step workflow, criteria interpretation, performance notes and reporting outputs.','Muted'));lay.addWidget(hero);reader=QTextBrowser();reader.setOpenExternalLinks(True);reader.setMarkdown(STUDIO_MANUAL_MD)
        reader.setStyleSheet('QTextBrowser {background:#ffffff;color:#122233;font-size:15px;}')
        cursor=reader.document().find('rabbi.ms244@gmail.com')
        if not cursor.isNull():
            formatting=cursor.charFormat()
            formatting.setForeground(QColor('#000000'))
            formatting.setFontWeight(QFont.Bold)
            formatting.setFontUnderline(True)
            cursor.mergeCharFormat(formatting)
        reader.setMinimumHeight(720);lay.addWidget(reader);lay.addStretch();return page
    def _about(self):
        page,lay=vertical_page();hero,hl=card(object_name='ToolbarBand');hl.addWidget(label('About','Headline'));hl.addWidget(label('Application identity, developer and scientific scope.','Muted'));lay.addWidget(hero);f,b=card();text=QTextBrowser();text.setOpenExternalLinks(True);text.setHtml('''<div style="font-family:Segoe UI;color:#183149"><h1 style="color:#17395d">Compound Filtering &amp; Screening Studio</h1><p style="font-size:15px"><b>Version 2.4</b></p><hr style="border:0;border-top:1px solid #d4dee8"><h2 style="color:#275981">Developer</h2><p><b>Md Fazlay Rabbi</b><br>Department of Zoology<br>University of Rajshahi, Bangladesh</p><p><b>Email:</b> <a style="color:#000000;text-decoration:underline;font-weight:800" href="mailto:rabbi.ms244@gmail.com">rabbi.ms244@gmail.com</a></p><h2 style="color:#275981">Purpose</h2><p>This application integrates four compound-screening notebooks into a guided, auditable workflow with selectable criteria, publication figures, performance monitoring and manuscript-support reports.</p><h2 style="color:#275981">Scientific scope</h2><p>Descriptor thresholds and structural alerts are computational screening tools. They do not by themselves establish experimental toxicity, safety, efficacy, aggregation or clinical suitability.</p></div>''');text.setStyleSheet('QTextBrowser {color:#111111; background:#ffffff;font-size:15px;}');text.setMinimumHeight(540);b.addWidget(text);lay.addWidget(f);lay.addStretch();return page
    def navigate(self,index):
        self.stack.setCurrentIndex(index)
        for i,btn in enumerate(self.nav):btn.setProperty('active',i==index);btn.style().unpolish(btn);btn.style().polish(btn)
    def choose_csv(self):
        f,_=QFileDialog.getOpenFileName(self,'Choose compound CSV',str(Path.home()),'CSV Files (*.csv);;All Files (*)')
        if f:self.input_file.setText(f)
    def choose_output(self):
        p=QFileDialog.getExistingDirectory(self,'Choose results directory',self.output_file.text())
        if p:self.output_file.setText(p)
    def _show_input_preview(self,path):
        if not Path(path).is_file():self.input_info.setText('No valid CSV selected yet.');return
        try:
            d=pd.read_csv(path,nrows=5);d,meta=clean_import(d);total=sum(1 for _ in open(path,'rb'))-1 if Path(path).stat().st_size<250_000_000 else None;count_txt=f' • approximately {total:,} data rows' if total is not None and total>=0 else '';self.input_info.setText(f"Detected SMILES: {meta['smiles_column']} • Compound name: {meta['name_column'] or 'generated'}{count_txt}")
        except Exception as e:self.input_info.setText(f'Input preview: {e}')
    def settings(self):
        c=RunConfig(output_base=self.output_file.text().strip(),source_file=self.input_file.text().strip());c.enabled={str(p):w.selected_filters() for p,w in self.stage_pages.items()};c.ph=self.stage_pages[1].ph.value();c.original_plots=True;return c
    def run_everything(self):self._start(4,fresh=True,full_pipeline=True)
    def run_stage(self,num):
        # Continue from the previous stage when it matches. Otherwise treat the
        # currently chosen CSV as the starting input for the selected Part.
        last=(self.manifest or {}).get('stages',[])
        if last and last[-1]['part']+1==num and self.last_output is not None:
            self._start(num,fresh=False)
        else:
            if num>1:
                approved=studio_question(self,'Start directly at Part '+str(num),
                    f'The selected CSV will be used directly as Part {num} input.\n'
                    'Earlier Parts will NOT be run or assumed to have passed.\n\n'
                    'Continue with this CSV?')
                if not approved:return
            self._start(num,fresh=True)
    def _start(self,num,fresh,full_pipeline=False):
        if self.worker is not None and self.worker.isRunning():return
        source=self.input_file.text().strip()
        if not Path(source).is_file() and fresh:studio_warning(self,'Input required','Choose a valid compound CSV on Project Workspace.');self.navigate(0);return
        if not self.output_file.text().strip():studio_warning(self,'Output required','Choose a results directory.');self.navigate(0);return
        config=self.settings()
        if (full_pipeline or num==1) and not config.selected(1,'parsing'):
            studio_warning(self,'Parsing required','SMILES parsing is mandatory for Part 1.');return
        self.run_all.setEnabled(False)
        for s in self.stage_pages.values():s.run_button.setEnabled(False)
        self.progress.setRange(0,100);self.progress.setValue(0);self.progress.setFormat('0%  •  Initializing');self.status.setText('Initializing molecular-screening workflow…');self.counter.setText('0 / 0');self.speed.setText('— cmp/s');self._current_start_part=(1 if full_pipeline else num) if fresh else ((self.manifest or {}).get('start_part',1));self._run_started=time.perf_counter();self._elapsed_timer.start(500);self.log.appendPlainText(f'\nSTART {"COMPLETE PIPELINE" if full_pipeline else f"PART {num}"}: {source}')
        if fresh:self.manifest=None;self.last_output=None
        self.worker=Worker(source,config,num,None if fresh else self.last_output,None if fresh else self.manifest,start_part=(1 if full_pipeline else num) if fresh else num);self.worker.progress.connect(self._update_progress);self.worker.finished_ok.connect(self._finished);self.worker.error.connect(self._failure);self.worker.start()
    def _update_elapsed(self):
        if self._run_started is None:return
        sec=max(0,int(time.perf_counter()-self._run_started));self.elapsed.setText(f'Elapsed {sec//60:02d}:{sec%60:02d}')
    def _update_progress(self,part,step,detail,pct):
        if pct is None:self.progress.setRange(0,0);overall=None
        else:self.progress.setRange(0,100);inner=max(0.0,min(100.0,float(pct)));first_part=(self.manifest or {}).get('start_part', 1) if self.manifest else getattr(self,'_current_start_part',1);scale=max(1,5-first_part);overall=max(0,min(100,round(((part-first_part)*100+inner)/scale)));self.progress.setValue(overall)
        self.status.setText(f'Part {part} • {detail}');import re as _re;m=_re.search(r'([\d,]+)\s*/\s*([\d,]+)',detail);sp=_re.search(r'([\d,.]+)\s*cmp/s',detail)
        if m:
            done,total=m.group(1),m.group(2);self.counter.setText(f'{done} / {total}');self.progress.setFormat(f'{overall if overall is not None else 0}% overall   •   {done} / {total}')
        elif overall is not None:self.progress.setFormat(f'{overall}% overall   •   Part {part}')
        if sp:self.speed.setText(f'{sp.group(1)} cmp/s')
        elif step in ('start','figures','original_figures'):self.speed.setText('— cmp/s')
        colors={1:'#3478b7',2:'#2b88a8',3:'#1b8a70',4:'#6675b8'};self.progress.setStyleSheet(f'QProgressBar::chunk{{background:{colors.get(part,"#2f6fae")};border-radius:7px;}}')
        if step in ('done','start','figures','original_figures') or 'complete' in detail.lower() or 'retained' in detail.lower():self.log.appendPlainText(detail)
        if part in self.stage_pages:
            state=self.stage_pages[part].stage_state;state.setText('RUNNING');state.setProperty('state','running');state.style().unpolish(state);state.style().polish(state)
    def _finished(self,manifest,frame):
        self._elapsed_timer.stop();self.manifest=manifest;self.last_output=frame;self.status.setText(f"Complete — {manifest['total_output']:,} of {manifest['total_input']:,} compounds retained");self.log.appendPlainText(f"SAVED: {manifest['project_dir']}\nARCHIVE: {manifest['zip_file']}\nTOTAL TIME: {manifest.get('seconds_elapsed',0):.1f} s");self.progress.setRange(0,100);self.progress.setValue(100);self.progress.setFormat(f"100%  •  {manifest['total_output']:,} retained");self.counter.setText(f"{manifest['total_output']:,} / {manifest['total_input']:,}");self.speed.setText('Complete');self.run_all.setEnabled(True);self.export_zip.setEnabled(True)
        for s in self.stage_pages.values():s.run_button.setEnabled(True)
        for stage in manifest['stages']:self.stage_pages[stage['part']].populate(stage,manifest['project_dir'])
        self.final_card.setText(f"Input {manifest['total_input']:,} → Retained {manifest['total_output']:,} • Overall retention {manifest['retention_percent']:.2f}% • Total time {manifest.get('seconds_elapsed',0):.1f} s");self.final_table.setRowCount(len(manifest['stages']))
        for i,s in enumerate(manifest['stages']):
            for j,v in enumerate((str(s['part']),s['name'],f"{s['input']:,}",f"{s['removed']:,}",f"{s['output']:,}",f"{s.get('seconds_elapsed',0):.1f}")):self.final_table.setItem(i,j,QTableWidgetItem(str(v)))
        summary_file=Path(manifest['project_dir'])/'05_Combined_Summary'/'Results.txt'
        if summary_file.is_file():self.summary_text.setPlainText(summary_file.read_text(encoding='utf-8'))
        overall_fig=Path(manifest['project_dir'])/'05_Combined_Summary'/'figures'/'Overall_Applied_Filtering_Cascade.png'
        if overall_fig.is_file():self._show_overall_chart(overall_fig)
        self.navigate(5)
        if manifest.get('warnings'):studio_warning(self,'Completed with warnings','\n'.join(manifest['warnings'][:4]))
    def _failure(self,details):
        self._elapsed_timer.stop();self.progress.setRange(0,100);self.progress.setValue(0);self.progress.setFormat('Failed');self.run_all.setEnabled(True)
        for s in self.stage_pages.values():s.run_button.setEnabled(True)
        self.status.setText('Analysis failed — review the Live Analysis Log');self.log.appendPlainText('\nERROR:\n'+details);studio_error(self,'Analysis failed',details[-2600:]);self.navigate(0)
    def choose_chart_color(self):
        chosen=QColorDialog.getColor(QColor(self.chart_color.text()),self,'Select filtering-chart color')
        if chosen.isValid():self.chart_color.setText(chosen.name().upper())
    def update_overall_chart(self):
        if not self.manifest:
            studio_information(self,'Run an analysis','Run at least one selected filter before editing the overall figure.');return
        summary=Path(self.manifest['project_dir'])/'05_Combined_Summary'
        counts=summary/'overall_applied_filter_counts.csv'
        if not counts.is_file():
            studio_information(self,'No applied filters','No executed filters are available for a chart.');return
        options=dict(chart_type=self.chart_type.currentText(),color=self.chart_color.text().strip(),
                     width=self.chart_width.value(),height=self.chart_height.value(),
                     bar_width=self.chart_bar_width.value(),title_size=self.chart_title_fs.value(),
                     axis_size=self.chart_axis_fs.value(),tick_size=self.chart_tick_fs.value(),
                     value_size=self.chart_value_fs.value(),rotation=self.chart_rotation.value(),dpi=600)
        try:
            preview_path=render_overall_chart(counts,summary,('png','svg','tiff'),options)
            self._show_overall_chart(preview_path)
            # The combined ZIP is a snapshot; rebuild it to contain the new design files.
            run_dir=Path(self.manifest['project_dir'])
            archive=Path(self.manifest['zip_file'])
            temporary=archive.with_suffix('.updated.zip')
            with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
                for item in sorted(run_dir.rglob('*')):
                    if item.is_file():z.write(item,item.relative_to(run_dir.parent))
            os.replace(temporary,archive)
            self.log.appendPlainText(f'Figure updated: {preview_path} (ZIP refreshed)')
            studio_information(self,'Figure exported','The overall chart was updated as PNG, SVG and TIFF (600 DPI raster); the combined ZIP was refreshed.')
        except Exception as exc:
            studio_error(self,'Figure designer error',str(exc))
    def _show_overall_chart(self,path):
        pix=QPixmap(str(path))
        if pix.isNull():return
        self.overall_figure.setPixmap(pix.scaled(QSize(1040,430),Qt.KeepAspectRatio,Qt.SmoothTransformation))

    def open_zip(self):
        if self.manifest and Path(self.manifest['zip_file']).exists():QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(self.manifest['zip_file']))))
        else:studio_information(self,'No archive','Complete at least one stage first.')
    def open_folder(self):
        if self.manifest:QDesktopServices.openUrl(QUrl.fromLocalFile(self.manifest['project_dir']))
        else:studio_information(self,'No analysis','No results folder yet.')

_OUR_WINDOW=None

def launch_studio():
    global _OUR_WINDOW
    app=QApplication.instance()
    if app is None:app=QApplication(sys.argv)
    app.setStyle('Fusion');app.setStyleSheet(APP_STYLE);app.setWindowIcon(studio_fr_icon())
    if _OUR_WINDOW is not None:
        try:_OUR_WINDOW.close()
        except RuntimeError:pass
    _OUR_WINDOW=Studio();_OUR_WINDOW.show()
    return _OUR_WINDOW


# --------------------- VERIFIED GUI LIFECYCLE: STANDALONE QT EVENT LOOP ---------------------
if __name__ == '__main__':
    import traceback as _tb
    import os as _os
    import json as _json
    from pathlib import Path as _Path
    def _notify_start_error(message):
        # Print for the notebook parent and additionally display on Windows.
        print(message, file=sys.stderr, flush=True)
        if _os.name == 'nt':
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, str(message)[-3800:],
                    'Compound Filtering Studio - startup error', 0x10)
            except Exception:
                pass
    try:
        print('BOOT: loading studio with Qt binding:', _QT_CHOICE, flush=True)
        COMPOUND_STUDIO_WINDOW = launch_studio()
        _studio_qapp = QApplication.instance()
        if _studio_qapp is None:
            raise RuntimeError('QApplication did not initialize.')
        # Adjust to the active monitor, rather than an offscreen saved window position.
        try:
            screen = _studio_qapp.primaryScreen()
            if screen is not None:
                available = screen.availableGeometry()
                width = min(1410, max(900, available.width() - 24))
                height = min(900, max(650, available.height() - 40))
                COMPOUND_STUDIO_WINDOW.setMinimumSize(min(900,width),min(620,height))
                COMPOUND_STUDIO_WINDOW.resize(width,height)
                COMPOUND_STUDIO_WINDOW.move(available.x()+max(0,(available.width()-width)//2),
                                            available.y()+max(0,(available.height()-height)//2))
        except Exception:
            _tb.print_exc()
        COMPOUND_STUDIO_WINDOW.show()
        COMPOUND_STUDIO_WINDOW.raise_()
        COMPOUND_STUDIO_WINDOW.activateWindow()
        def _focus_and_signal():
            if not COMPOUND_STUDIO_WINDOW.isVisible():
                raise RuntimeError('The Qt main window was created but is not visible.')
            COMPOUND_STUDIO_WINDOW.show()
            COMPOUND_STUDIO_WINDOW.raise_()
            COMPOUND_STUDIO_WINDOW.activateWindow()
            readyfile = _os.environ.get('STUDIO_GUI_READY_FILE','')
            if readyfile:
                _Path(readyfile).write_text(_json.dumps({
                    'status':'visible','binding':_QT_CHOICE,'pid':_os.getpid(),
                    'window_title':COMPOUND_STUDIO_WINDOW.windowTitle(),
                    'window_visible':COMPOUND_STUDIO_WINDOW.isVisible(),
                    'window_size':[COMPOUND_STUDIO_WINDOW.width(),COMPOUND_STUDIO_WINDOW.height()],
                }),encoding='utf-8')
            print('GUI_READY: window visible; Qt event loop active; binding=' + _QT_CHOICE,flush=True)
        QTimer.singleShot(750,_focus_and_signal)
        print('BOOT: GUI instantiated; entering Qt event loop',flush=True)
        _exit = (_studio_qapp.exec if hasattr(_studio_qapp,'exec') else _studio_qapp.exec_)()
        print('GUI_CLOSED: Qt event loop returned:',_exit,flush=True)
        sys.exit(_exit)
    except Exception:
        _notify_start_error('Unable to start the GUI:\n'+_tb.format_exc())
        sys.exit(2)
