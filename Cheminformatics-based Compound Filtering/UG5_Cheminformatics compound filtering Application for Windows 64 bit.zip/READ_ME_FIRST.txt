FR Studio - Windows EXE Quick Launcher (Python 3.13 selection fixed)

YOUR ERROR
The previous CMD selected MGLTools-1.5.7\python.exe (Python 2.7.11). This is NOT compatible with the studio. Your existing local Python 3.13 should be selected instead.

WHAT TO DO
1. Extract this entire ZIP into a NEW folder (not the older version).
2. Double-click Open_FR_Studio.cmd. It verifies a 64-bit Python 3.10-3.13 interpreter, prioritizing %LOCALAPPDATA%\Programs\Python\Python313\python.exe. It ignores MGLTools Python 2.7.
3. The first launch builds the EXE with PyInstaller ON YOUR WINDOWS COMPUTER; this may take several minutes and may need internet to install missing packages. Existing compatible packages are reused.
4. On subsequent launches use Open_FR_Studio.cmd again or directly open dist\Compound_Filtering_Studio_FR\Compound_Filtering_Studio_FR.exe. There are no package checks/downloads after a successful build.
5. When sharing the EXE, copy the WHOLE dist\Compound_Filtering_Studio_FR folder including _internal (not only the single .exe).

If auto-discovery still fails, double-click Build_Using_Python313.cmd, which uses the exact path to your user-installed Python 3.13.

IMPORTANT: This ZIP is a builder, NOT a compiled Windows .exe. Compilation for Windows requires Windows or a Windows cloud runner. This Linux-hosted environment cannot generate a tested Windows binary.

LOGS
Build failure: build_logs\setup.log and build_logs\pyinstaller_build.log.
If EXE opens then closes: Run_Source_Debug.cmd and attach build_logs\application_debug.log.

Software: FR Studio; original compound filtering calculations unchanged.
Developer: FR (Md Fazlay Rabbi) | rabbi.ms244@gmail.com

FAST WITHOUT EXE: Double-click Run_GUI_Now_Python313.cmd. It launches the original GUI source directly using your installed Python 3.13 and cached packages; no build/install. If a package is missing, use Open_FR_Studio.cmd first.
