@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_313=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not exist "%PYTHON_313%" (
  echo [ERROR] Python 3.13 not found at: %PYTHON_313%
  pause
  exit /b 1
)
"%PYTHON_313%" -c "import sys; print(sys.version); assert sys.maxsize>2**32"
if errorlevel 1 (
  echo [ERROR] Python 3.13 is not x64.
  pause
  exit /b 1
)
"%PYTHON_313%" "%~dp0setup_and_build.py"
if errorlevel 1 (
  echo [ERROR] Build failure. See build_logs.
  pause
  exit /b 1
)
call "%~dp0Launch_Fast.cmd"
